"""
Pydantic schemas for validation and anomaly detection results
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone
from enum import Enum



class ValidationSeverity(str, Enum):
    """Severity levels for validation issues"""
    CRITICAL = "critical"  # Blocks processing
    WARNING = "warning"    # Needs review
    INFO = "info"          # FYI only


class ValidationCategory(str, Enum):
    """Categories of validation issues"""
    SCHEMA = "schema"                    # Missing/invalid fields
    FORMAT = "format"                    # Wrong format (date, email, etc)
    BUSINESS_RULE = "business_rule"      # Violates business logic
    ARITHMETIC = "arithmetic"            # Math doesn't add up
    MISSING_DATA = "missing_data"        # Required field empty
    LOGIC = "logic"                      # Logical inconsistency
    CLASSIFICATION = "classification"     # Wrong document type


class ValidationStatus(str, Enum):
    """Overall validation status"""
    PASSED = "passed"          # All checks passed
    WARNING = "warning"        # Has warnings but acceptable
    FAILED = "failed"          # Critical issues found
    ERROR = "error"            # Validation process error


class AnomalyType(str, Enum):
    """Types of anomalies"""
    OUTLIER = "outlier"              # Statistical outlier
    DUPLICATE = "duplicate"          # Duplicate transaction
    FRAUD_PATTERN = "fraud_pattern"  # Fraud indicator
    SUSPICIOUS = "suspicious"        # Unusual pattern
    UNUSUAL_AMOUNT = "unusual_amount" # Amount anomaly


class ValidationIssue(BaseModel):
    """Single validation issue"""
    severity: ValidationSeverity
    category: ValidationCategory
    field: str
    message: str
    expected: Optional[Any] = None
    actual: Optional[Any] = None
    suggestion: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "severity": "critical",
                "category": "format",
                "field": "invoice_number",
                "message": "Invoice number contains OCR error text",
                "expected": "Valid alphanumeric invoice number",
                "actual": "erred",
                "suggestion": "Manual review required"
            }
        }


class AnomalyResult(BaseModel):
    """Single anomaly detection result"""
    type: AnomalyType
    severity: ValidationSeverity
    field: str
    value: Any
    reason: str
    anomaly_score: float = Field(ge=0.0, le=1.0)
    context: Optional[Dict[str, Any]] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "type": "outlier",
                "severity": "warning",
                "field": "total_amount",
                "value": 182000,
                "reason": "Amount is 3.2x higher than average for this vendor",
                "anomaly_score": 0.85,
                "context": {"vendor_avg": 56000, "std_dev": 15000}
            }
        }


class ArithmeticCheck(BaseModel):
    """Result of arithmetic validation"""
    check_name: str
    passed: bool
    expected: Optional[float] = None
    actual: Optional[float] = None
    difference: Optional[float] = None
    message: Optional[str] = None


class ValidationReport(BaseModel):
    """Complete validation report for a document"""
    
    # Metadata
    document_id: str
    validation_id: str = Field(default_factory=lambda: f"val_{datetime.now(timezone.utc).timestamp()}")
    validation_status: ValidationStatus
    
    # Scores
    overall_score: float = Field(ge=0.0, le=1.0, description="0=failed, 1=perfect")
    confidence_score: float = Field(ge=0.0, le=1.0)
    
    # Checks summary
    checks_performed: int = 0
    checks_passed: int = 0
    checks_failed: int = 0
    checks_warning: int = 0
    
    # Issues found
    issues: List[ValidationIssue] = []
    anomalies: List[AnomalyResult] = []
    fraud_indicators: List[str] = []
    
    # Arithmetic validation
    arithmetic_checks: Dict[str, ArithmeticCheck] = {}
    
    # Recommendations
    recommendation: str
    requires_manual_review: bool = False
    risk_level: str = "low"  # low, medium, high, critical
    
    # Additional context
    validated_by: str = "agent_2_validator"
    validated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    processing_time: Optional[float] = None
    
    # Summary
    summary: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "document_id": "doc_123",
                "validation_status": "warning",
                "overall_score": 0.72,
                "confidence_score": 0.85,
                "checks_performed": 15,
                "checks_passed": 11,
                "checks_failed": 2,
                "checks_warning": 2,
                "issues": [
                    {
                        "severity": "warning",
                        "category": "missing_data",
                        "field": "vendor_email",
                        "message": "Vendor email not found"
                    }
                ],
                "anomalies": [],
                "fraud_indicators": [],
                "recommendation": "Review missing vendor contact information",
                "requires_manual_review": True,
                "risk_level": "low"
            }
        }


class ValidationRequest(BaseModel):
    """Request to validate a document"""
    document_id: str
    extracted_data: Dict[str, Any]
    strict_mode: bool = False  # If True, fail on any warning


class ValidationResponse(BaseModel):
    """Response from validation endpoint"""
    status: str
    validation_report: Optional[ValidationReport] = None
    error_message: Optional[str] = None


class BatchValidationRequest(BaseModel):
    """Request to validate multiple documents"""
    document_ids: List[str]
    strict_mode: bool = False


class BatchValidationResponse(BaseModel):
    """Response for batch validation"""
    total_documents: int
    validated: int
    failed_validation: int
    errors: int
    reports: List[ValidationReport]


class ReportFormat(str, Enum):
    """Supported report formats"""
    PDF = "pdf"
    WORD = "word"
    BOTH = "both"

class ReportRequest(BaseModel):
    """Request to generate audit report"""
    document_id: str
    format: ReportFormat = ReportFormat.BOTH
    include_charts: bool = True
    include_raw_data: bool = False

class ReportResponse(BaseModel):
    """Response for report generation"""
    status: str
    document_id: str
    pdf_path: Optional[str] = None
    word_path: Optional[str] = None
    generation_time: Optional[float] = None
    error_message: Optional[str] = None