"""
 Pydantic Schemas for data validation and serialization.
"""

from pydantic import BaseModel, Field, validator
from typing import List, Optional, Dict, Any 
from datetime import datetime
from enum import Enum 


class DocumentType(str, Enum):
    """Supported document types."""
    INVOICE = "invoice"
    RECEIPT = "receipt"
    BANK_STATEMENT = "bank_statement"
    FINANCIAL_REPORT = "financial_report"
    PURCHASE_ORDER = "purchase_order"
    CREDIT_NOTE = "credit_note"
    UNKNOWN = "unknown"

class ExtractionStatus(str, Enum):
    """Status of the extraction process."""
    PENDING = "pending"
    PROCESSING = "processing"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"

class LineItem(BaseModel):
    """Schema for line items in financial documents."""
    description: Optional[str] = None 
    quantity: Optional[float] = None
    unit_price: Optional[float] = None
    total: Optional[float] = None
    tax: Optional[float] = None 

class ExtractedData(BaseModel): 
    """Structured data extracted from financial documents."""

    # Document metadata
    document_id: str 
    document_type: DocumentType = DocumentType.UNKNOWN
    file_name: str 

    # Extracted entities
    vendor: Optional[str] = None 
    vendor_address: Optional[str] = None
    vendor_phone: Optional[str] = None 
    vendor_email: Optional[str] = None
    
    customer: Optional[str] = None
    customer_address: Optional[str] = None
    customer_phone: Optional[str] = None

    # Document identifiers 
    invoice_number: Optional[str] = None
    receipt_number: Optional[str] = None
    account_number: Optional[str] = None

    # Dates 
    document_date: Optional[str] = None # ISO format 
    due_date: Optional[str] = None


    # Financial amounts 
    subtotal: Optional[float] = None
    tax_amount: Optional[float] = None
    tax_rate: Optional[float] = None
    discount: Optional[float] = None
    total_amount: Optional[float] = None
    amount_paid: Optional[float] = None
    balance_due: Optional[float] = None

    # Currency 
    currency: Optional[str] = None  # ISO 4217 currency code

    # Line items
    line_items: List[LineItem] = []

    # Transaction details 
    transaction_description: Optional[str] = None
    payment_method: Optional[str] = None

    # Confidence Scores
    extraction_confidence: float = Field(ge=0.0, le=1.0, default=0.0)
    ocr_confidence: float = Field(ge=0.0, le=1.0, default=0.0)

    # Raw OCR text 
    raw_text: Optional[str] = None

    # Timestamps
    extracted_at: datetime = Field(default_factory=datetime.utcnow) 

class Config:
    json_schema_extra = {
        "example": {
            "document_id": "doc_123456",
            "document_type": "invoice",
            "file_name": "invoice_2024.pdf",
            "vendor": "ABC Supplies",
            "invoice_number": "INV-1001",
            "document_date": "2024-01-15",
            "total_amount": 1500.00,
            "extraction_confidence": 0.95
        }
    }

class ExtractionRequest(BaseModel):
    """Request model for document extraction."""
    document_id: str 
    file_path: str
    document_type: Optional[DocumentType] = None

class ExtractionResponse(BaseModel):
    """Response model for document extraction."""
    document_id: str 
    status: ExtractionStatus
    extracted_data: Optional[ExtractedData] = None
    error_message: Optional[str] = None
    processing_time: Optional[float] = None  # in seconds

class UploadResponse(BaseModel):
    """Response for document upload."""
    document_id: str 
    file_name: str 
    file_size: int  
    upload_status: str 
    message: str


class BatchExtractionRequest(BaseModel):
    """Request model for batch document extraction."""
    document_ids: List[str]

class BatchExtractionResponse(BaseModel):
    """Response for batch document extraction."""
    total_documents: int
    successful: int 
    failed: int
    results: List[ExtractionResponse]