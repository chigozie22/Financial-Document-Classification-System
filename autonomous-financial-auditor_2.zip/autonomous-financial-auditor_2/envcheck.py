"""
Debug settings loading - run from project root
"""
import sys
import os

sys.path.insert(0, os.path.abspath('.'))

print("=" * 70)
print("🐛 DEBUGGING SETTINGS LOADING")
print("=" * 70)

# Step 1: Check .env file
print("\n1. Checking .env file:")
env_path = ".env"
if os.path.exists(env_path):
    print(f"   ✅ .env exists at: {os.path.abspath(env_path)}")
    with open(env_path, 'r') as f:
        for line in f:
            if 'GOOGLE' in line and 'API' in line and not line.strip().startswith('#'):
                key = line.split('=')[0].strip()
                val = line.split('=')[1].strip()[:15] if '=' in line else ''
                print(f"   Found: {key}={val}...")
else:
    print(f"   ❌ .env NOT found")

# Step 2: Import Settings class
print("\n2. Importing Settings class:")
try:
    from backend.app.core.config import Settings
    print(f"   ✅ Settings class imported")
except Exception as e:
    print(f"   ❌ Failed to import Settings: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Step 3: Check Settings class attributes
print("\n3. Checking Settings class attributes:")
import inspect
source = inspect.getsource(Settings)

has_google_api_key = "GOOGLE_API_KEY" in source
has_google_gemini_api_key = "GOOGLE_GEMINI_API_KEY" in source
has_property = "@property" in source and "GEMINI_API_KEY" in source

print(f"   GOOGLE_API_KEY defined: {has_google_api_key}")
print(f"   GOOGLE_GEMINI_API_KEY defined: {has_google_gemini_api_key}")
print(f"   GEMINI_API_KEY @property: {has_property}")

# Step 4: Create Settings instance
print("\n4. Creating Settings instance:")
try:
    from backend.app.core.config import settings
    print(f"   ✅ Settings instance created")
except Exception as e:
    print(f"   ❌ Failed to create instance: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Step 5: Check loaded values
print("\n5. Checking loaded values:")
print(f"   settings.GOOGLE_API_KEY: {settings.GOOGLE_API_KEY[:15] if settings.GOOGLE_API_KEY else 'None'}...")
print(f"   settings.GOOGLE_GEMINI_API_KEY: {settings.GOOGLE_GEMINI_API_KEY[:15] if settings.GOOGLE_GEMINI_API_KEY else 'None'}...")

# Step 6: Check property
print("\n6. Checking GEMINI_API_KEY property:")
if hasattr(settings, 'GEMINI_API_KEY'):
    try:
        api_key = settings.GEMINI_API_KEY
        if api_key:
            print(f"   ✅ settings.GEMINI_API_KEY: {api_key[:15]}...{api_key[-4:]}")
            print(f"   ✅ PROPERTY WORKS!")
        else:
            print(f"   ❌ Property returned None")
            print(f"   This means both GOOGLE_API_KEY and GOOGLE_GEMINI_API_KEY are None")
    except Exception as e:
        print(f"   ❌ Property exists but failed: {e}")
else:
    print(f"   ❌ Property does NOT exist")
    print(f"   Add this to your Settings class:")
    print(f"""
    @property
    def GEMINI_API_KEY(self) -> Optional[str]:
        return self.GOOGLE_GEMINI_API_KEY or self.GOOGLE_API_KEY
    """)

# Step 7: Check Config class
print("\n7. Checking Settings.Config:")
if hasattr(Settings, 'Config'):
    config_source = inspect.getsource(Settings.Config)
    if 'env_file' in config_source:
        print(f"   ✅ env_file configured in Config")
    else:
        print(f"   ⚠️  env_file NOT found in Config")
        print(f"   Add: env_file = '.env' to Config class")
else:
    print(f"   ❌ Config class not found")

print("\n" + "=" * 70)
print("✅ DEBUG COMPLETE")
print("=" * 70)

# Final verdict
print("\n📋 SUMMARY:")
if hasattr(settings, 'GEMINI_API_KEY') and settings.GEMINI_API_KEY:
    print("✅ Everything is working! You can use settings.GEMINI_API_KEY")
else:
    print("❌ Settings are NOT loading correctly")
    print("\nFIX:")
    print("1. Make sure .env is in project root")
    print("2. Make sure config.py has GOOGLE_GEMINI_API_KEY: Optional[str] = None")
    print("3. Make sure config.py has the @property GEMINI_API_KEY")
    print("4. Make sure Settings.Config has env_file = '.env'")