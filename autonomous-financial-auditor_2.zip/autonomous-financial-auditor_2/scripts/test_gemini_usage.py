"""
Test if Gemini is actually being called and generating content
"""
import sys
import os

sys.path.insert(0, os.path.abspath('.'))

from backend.app.utils.gemini_client import GeminiClient
from backend.app.core.config import settings
import json

print("=" * 70)
print("🧪 TESTING GEMINI API USAGE")
print("=" * 70)

# Step 1: Check API Key
print("\n1. Checking API Key:")
api_key = settings.GEMINI_API_KEY
if api_key:
    print(f"   ✅ API Key loaded: {api_key[:15]}...{api_key[-4:]}")
else:
    print(f"   ❌ No API key found!")
    sys.exit(1)

# Step 2: Initialize Client
print("\n2. Initializing Gemini Client:")
try:
    client = GeminiClient(
        api_key=api_key,
        model_name=settings.LLM_MODEL,
        temperature=settings.LLM_TEMPERATURE,
        max_tokens=settings.LLM_MAX_TOKENS
    )
    print(f"   ✅ Client initialized")
    print(f"   Model: {settings.LLM_MODEL}")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    sys.exit(1)

# Step 3: Test Simple Text Generation
print("\n3. Testing Simple Text Generation:")
print("   Prompt: 'Say exactly: GEMINI IS WORKING'")
try:
    response = client.generate_text("Say exactly: GEMINI IS WORKING")
    print(f"   Response: {response}")
    if response and "GEMINI" in response.upper():
        print(f"   ✅ Gemini responded!")
    else:
        print(f"   ⚠️  Unexpected response")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    import traceback
    traceback.print_exc()

# Step 4: Test JSON Generation
print("\n4. Testing JSON Generation:")
prompt = """
Return ONLY this JSON (no markdown, no backticks):
{
  "test": "success",
  "model": "gemini",
  "message": "JSON generation works"
}
"""

try:
    json_response = client.generate_json(
        prompt=prompt,
        system_instruction="Return only valid JSON, no markdown"
    )
    print(f"   Response: {json.dumps(json_response, indent=2)}")
    if json_response and json_response.get("test") == "success":
        print(f"   ✅ JSON generation works!")
    else:
        print(f"   ⚠️  Unexpected JSON response")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    import traceback
    traceback.print_exc()

# Step 5: Test Executive Summary Generation (Like Agent 3)
print("\n5. Testing Executive Summary Generation (Agent 3 Use Case):")
summary_prompt = """
Generate a brief executive summary (2 sentences) for this audit:
- Document: Invoice from Acme Corp
- Total: $10,000
- Status: Failed validation
- Issues: 2 critical errors found

Return only the summary text, no formatting.
"""

try:
    summary = client.generate_text(
        prompt=summary_prompt,
        system_instruction="You are a financial auditor. Write concise summaries."
    )
    print(f"   Response: {summary}")
    if summary and len(summary) > 20:
        print(f"   ✅ Summary generation works! ({len(summary)} chars)")
    else:
        print(f"   ⚠️  Summary too short or empty")
except Exception as e:
    print(f"   ❌ Failed: {e}")
    import traceback
    traceback.print_exc()

# Step 6: Check if Agents are Using LLM
print("\n6. Checking Agent Configurations:")

# Check Agent 2
try:
    from backend.app.services.agent2_service import agent2_service
    agent2_status = agent2_service.get_agent_status()
    llm_enabled_2 = agent2_status.get("llm_enabled", False)
    print(f"   Agent 2 LLM Enabled: {'✅ YES' if llm_enabled_2 else '❌ NO'}")
except Exception as e:
    print(f"   ⚠️  Could not check Agent 2: {e}")

# Check Agent 3
try:
    from backend.app.services.agent3_service import agent3_service
    agent3_status = agent3_service.get_agent_status()
    llm_enabled_3 = agent3_status.get("llm_enabled", False)
    print(f"   Agent 3 LLM Enabled: {'✅ YES' if llm_enabled_3 else '❌ NO'}")
except Exception as e:
    print(f"   ⚠️  Could not check Agent 3: {e}")

print("\n" + "=" * 70)
print("✅ TEST COMPLETE")
print("=" * 70)

print("\n📋 SUMMARY:")
print("If all tests passed:")
print("  - ✅ Gemini API is working")
print("  - ✅ Your API key is valid")
print("  - ✅ Text and JSON generation work")
print("\nIf usage is still flat in Google AI Studio:")
print("  1. Wait 5-10 minutes for usage to update")
print("  2. Check if agents are actually using LLM (Agent 2/3 status above)")
print("  3. Verify API key is the same in .env and AI Studio")
print("  4. Check AI Studio > Gemini API > Usage page for your project")