"""
Prompts for LLM-based report summary generation
"""

EXECUTIVE_SUMMARY_SYSTEM_PROMPT = """You are a senior financial auditor preparing executive summaries for audit reports.

Your summaries should be:
- Professional and concise (2-3 paragraphs)
- Highlight key findings
- State clear recommendations
- Use appropriate business language
- Focus on actionable insights

Write for executives who need quick, clear information."""


EXECUTIVE_SUMMARY_PROMPT = """Generate an executive summary for this financial document audit:

**Document Information:**
- Document ID: {document_id}
- Document Type: {document_type}
- Vendor: {vendor}
- Total Amount: ${total_amount}
- Document Date: {document_date}

**Validation Results:**
- Overall Score: {overall_score}%
- Validation Status: {validation_status}
- Critical Issues: {critical_issues}
- Warnings: {warnings}
- Anomalies Detected: {anomalies_count}
- Fraud Indicators: {fraud_count}

**Key Issues:**
{key_issues}

**Recommendation:**
{recommendation}

Generate a professional executive summary (2-3 paragraphs) that:
1. Summarizes the document and audit process
2. Highlights the most important findings
3. States the recommendation clearly
4. Mentions any critical concerns

Return only the executive summary text, no formatting or markdown."""


RECOMMENDATIONS_PROMPT = """Based on this audit, provide detailed recommendations:

**Validation Status:** {validation_status}
**Overall Score:** {overall_score}%
**Risk Level:** {risk_level}

**Issues Found:**
{issues_summary}

**Anomalies:**
{anomalies_summary}

Provide 3-5 specific, actionable recommendations for:
1. What to do with this document (approve/reject/review)
2. What fields need manual verification
3. Any red flags to investigate
4. Process improvements if applicable

Return recommendations as a numbered list, each 1-2 sentences."""


def format_executive_summary_prompt(extracted_data: dict, validation_report: dict) -> str:
    """Format executive summary prompt with actual data"""
    
    # Extract key information
    document_id = extracted_data.get("document_id", "N/A")
    document_type = extracted_data.get("document_type", "unknown")
    vendor = extracted_data.get("vendor", "N/A")
    total_amount = extracted_data.get("total_amount", 0)
    document_date = extracted_data.get("document_date", "N/A")
    
    overall_score = validation_report.get("overall_score", 0) * 100
    validation_status = validation_report.get("validation_status", "unknown")
    
    # Count issues
    issues = validation_report.get("issues", [])
    critical_issues = sum(1 for i in issues if i.get("severity") == "critical")
    warnings = sum(1 for i in issues if i.get("severity") == "warning")
    
    anomalies_count = len(validation_report.get("anomalies", []))
    fraud_count = len(validation_report.get("fraud_indicators", []))
    
    # Format key issues
    key_issues_list = [
        f"- {issue.get('field')}: {issue.get('message')}" 
        for issue in issues[:5]  # Top 5 issues
    ]
    key_issues = "\n".join(key_issues_list) if key_issues_list else "None"
    
    recommendation = validation_report.get("recommendation", "Review required")
    
    return EXECUTIVE_SUMMARY_PROMPT.format(
        document_id=document_id,
        document_type=document_type,
        vendor=vendor,
        total_amount=total_amount,
        document_date=document_date,
        overall_score=overall_score,
        validation_status=validation_status,
        critical_issues=critical_issues,
        warnings=warnings,
        anomalies_count=anomalies_count,
        fraud_count=fraud_count,
        key_issues=key_issues,
        recommendation=recommendation
    )


def format_recommendations_prompt(validation_report: dict) -> str:
    """Format recommendations prompt"""
    
    validation_status = validation_report.get("validation_status", "unknown")
    overall_score = validation_report.get("overall_score", 0) * 100
    risk_level = validation_report.get("risk_level", "unknown")
    
    # Format issues
    issues = validation_report.get("issues", [])
    issues_list = [
        f"- [{i.get('severity')}] {i.get('field')}: {i.get('message')}"
        for i in issues[:10]
    ]
    issues_summary = "\n".join(issues_list) if issues_list else "No issues found"
    
    # Format anomalies
    anomalies = validation_report.get("anomalies", [])
    anomalies_list = [
        f"- [{a.get('type')}] {a.get('field')}: {a.get('reason')}"
        for a in anomalies[:5]
    ]
    anomalies_summary = "\n".join(anomalies_list) if anomalies_list else "No anomalies detected"
    
    return RECOMMENDATIONS_PROMPT.format(
        validation_status=validation_status,
        overall_score=overall_score,
        risk_level=risk_level,
        issues_summary=issues_summary,
        anomalies_summary=anomalies_summary
    )