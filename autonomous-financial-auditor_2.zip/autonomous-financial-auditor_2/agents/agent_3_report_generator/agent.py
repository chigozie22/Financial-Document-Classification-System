"""
Agent 3: Audit Report Generator
Orchestrates PDF/Word generation, charts, and LLM summaries
"""
import os
import sys
import logging
from typing import Dict, Any, Optional
from datetime import datetime

# Add parent directories to path
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from agents.agent_3_report_generator.tools.pdf_generator import PDFGenerator
from agents.agent_3_report_generator.tools.word_generator import WordGenerator
from agents.agent_3_report_generator.tools.chart_generator import ChartGenerator
from agents.agent_3_report_generator.prompts.report_prompts import (
    EXECUTIVE_SUMMARY_SYSTEM_PROMPT,
    format_executive_summary_prompt,
    format_recommendations_prompt
)
from backend.app.utils.gemini_client import GeminiClient

logger = logging.getLogger(__name__)


class Agent3ReportGenerator:
    """
    Agent 3: Audit Report Generator
    
    Pipeline:
    1. Generate charts (Matplotlib)
    2. Generate LLM summaries (Gemini)
    3. Generate PDF report (ReportLab)
    4. Generate Word report (python-docx)
    5. Return report paths
    """
    
    def __init__(self,
                 pdf_generator: PDFGenerator,
                 word_generator: WordGenerator,
                 chart_generator: ChartGenerator,
                 gemini_client: Optional[GeminiClient] = None,
                 use_llm: bool = True):
        """
        Initialize Agent 3
        
        Args:
            pdf_generator: PDF report generator
            word_generator: Word document generator
            chart_generator: Chart visualization generator
            gemini_client: Gemini client for summaries
            use_llm: Whether to use LLM for summaries
        """
        self.pdf_generator = pdf_generator
        self.word_generator = word_generator
        self.chart_generator = chart_generator
        self.gemini_client = gemini_client
        self.use_llm = use_llm and gemini_client is not None
        
        logger.info("Agent 3 (Report Generator) initialized")
    
    def generate_audit_report(self,
                             extracted_data: Dict[str, Any],
                             validation_report: Dict[str, Any],
                             format: str = "both") -> Dict[str, str]:
        """
        Main report generation pipeline
        
        Args:
            extracted_data: Output from Agent 1
            validation_report: Output from Agent 2
            format: "pdf", "word", or "both"
            
        Returns:
            Dict with report paths
        """
        start_time = datetime.now()
        document_id = extracted_data.get("document_id", "unknown")
        
        logger.info(f"Starting report generation for document: {document_id}")
        
        try:
            # Step 1: Generate charts
            logger.info("Step 1: Generating charts...")
            charts = self.chart_generator.generate_all_charts(
                validation_report, 
                document_id
            )
            logger.info(f"Generated {len([c for c in charts.values() if c])} charts")
            
            # Step 2: Generate LLM summaries
            logger.info("Step 2: Generating LLM summaries...")
            executive_summary, recommendations = self._generate_llm_content(
                extracted_data, 
                validation_report
            )
            
            # Step 3: Generate reports
            report_paths = {}
            
            if format in ["pdf", "both"]:
                logger.info("Step 3a: Generating PDF report...")
                pdf_path = self.pdf_generator.generate_report(
                    extracted_data=extracted_data,
                    validation_report=validation_report,
                    executive_summary=executive_summary,
                    recommendations=recommendations,
                    charts=charts,
                    document_id=document_id
                )
                report_paths["pdf"] = pdf_path
                logger.info(f"PDF report saved: {pdf_path}")
            
            if format in ["word", "both"]:
                logger.info("Step 3b: Generating Word report...")
                word_path = self.word_generator.generate_report(
                    extracted_data=extracted_data,
                    validation_report=validation_report,
                    executive_summary=executive_summary,
                    recommendations=recommendations,
                    charts=charts,
                    document_id=document_id
                )
                report_paths["word"] = word_path
                logger.info(f"Word report saved: {word_path}")
            
            # Calculate processing time
            processing_time = (datetime.now() - start_time).total_seconds()
            report_paths["processing_time"] = processing_time
            
            logger.info(f"Report generation completed in {processing_time:.2f}s")
            
            return report_paths
            
        except Exception as e:
            logger.error(f"Error during report generation: {e}", exc_info=True)
            raise
    
    def _generate_llm_content(self,
                             extracted_data: Dict[str, Any],
                             validation_report: Dict[str, Any]) -> tuple:
        """
        Generate LLM-based summaries and recommendations
        
        Args:
            extracted_data: Extracted data from Agent 1
            validation_report: Validation report from Agent 2
            
        Returns:
            Tuple of (executive_summary, recommendations)
        """
        executive_summary = ""
        recommendations = ""
        
        if not self.use_llm:
            logger.info("LLM summaries disabled, using fallback")
            executive_summary = self._generate_fallback_summary(
                extracted_data, 
                validation_report
            )
            recommendations = self._generate_fallback_recommendations(
                validation_report
            )
            return executive_summary, recommendations
        
        try:
            # Generate executive summary
            logger.info("Generating executive summary with LLM...")
            summary_prompt = format_executive_summary_prompt(
                extracted_data, 
                validation_report
            )
            
            executive_summary = self.gemini_client.generate_text(
                prompt=summary_prompt,
                system_instruction=EXECUTIVE_SUMMARY_SYSTEM_PROMPT
            )
            
            if not executive_summary:
                logger.warning("LLM returned empty summary, using fallback")
                executive_summary = self._generate_fallback_summary(
                    extracted_data, 
                    validation_report
                )
            
            # Generate recommendations
            logger.info("Generating recommendations with LLM...")
            recommendations_prompt = format_recommendations_prompt(
                validation_report
            )
            
            recommendations = self.gemini_client.generate_text(
                prompt=recommendations_prompt,
                system_instruction="You are a financial auditor providing actionable recommendations."
            )
            
            if not recommendations:
                logger.warning("LLM returned empty recommendations, using fallback")
                recommendations = self._generate_fallback_recommendations(
                    validation_report
                )
            
        except Exception as e:
            logger.error(f"LLM content generation failed: {e}")
            logger.info("Falling back to template-based content")
            executive_summary = self._generate_fallback_summary(
                extracted_data, 
                validation_report
            )
            recommendations = self._generate_fallback_recommendations(
                validation_report
            )
        
        return executive_summary, recommendations
    
    def _generate_fallback_summary(self,
                                   extracted_data: Dict[str, Any],
                                   validation_report: Dict[str, Any]) -> str:
        """
        Generate template-based executive summary (fallback)
        
        Args:
            extracted_data: Extracted data
            validation_report: Validation report
            
        Returns:
            Executive summary text
        """
        document_type = extracted_data.get('document_type', 'unknown')
        vendor = extracted_data.get('vendor', 'Unknown Vendor')
        total_amount = extracted_data.get('total_amount') or 0
        
        status = validation_report.get('validation_status', 'unknown')
        score = validation_report.get('overall_score', 0) * 100
        risk_level = validation_report.get('risk_level', 'unknown')
        
        critical_issues = sum(
            1 for i in validation_report.get('issues', []) 
            if i.get('severity') == 'critical'
        )
        anomalies_count = len(validation_report.get('anomalies', []))
        
        summary = f"""This audit report covers a {document_type} document from {vendor} """
        if total_amount and total_amount > 0:
            summary += f"""with a total amount of ${total_amount:,.2f}. """
        else:
            summary += """with an unspecified total amount. """
        
        summary += f"""The automated validation process completed with a score of {score:.1f}% """
        summary += f"""and a status of {status.upper()}. """
        
        if critical_issues > 0:
            summary += f"""The system identified {critical_issues} critical issue(s) """
            summary += f"""that require immediate attention. """
        
        if anomalies_count > 0:
            summary += f"""{anomalies_count} anomaly/anomalies were detected during """
            summary += f"""the automated analysis. """
        
        summary += f"""The overall risk level has been assessed as {risk_level.upper()}. """
        
        recommendation = validation_report.get('recommendation', '')
        if recommendation:
            summary += f"""Based on the validation results, the recommendation is: {recommendation}"""
        
        return summary
    
    def _generate_fallback_recommendations(self,
                                          validation_report: Dict[str, Any]) -> str:
        """
        Generate template-based recommendations (fallback)
        
        Args:
            validation_report: Validation report
            
        Returns:
            Recommendations text
        """
        recommendations = []
        
        status = validation_report.get('validation_status', 'unknown')
        critical_issues = sum(
            1 for i in validation_report.get('issues', []) 
            if i.get('severity') == 'critical'
        )
        warnings = sum(
            1 for i in validation_report.get('issues', []) 
            if i.get('severity') == 'warning'
        )
        
        # Recommendation based on status
        if status == 'failed':
            recommendations.append(
                "1. REJECT this document - Critical validation failures detected. "
                "Manual review is required before processing."
            )
        elif status == 'warning':
            recommendations.append(
                "1. REVIEW REQUIRED - Document has warnings that should be "
                "addressed before approval."
            )
        else:
            recommendations.append(
                "1. APPROVE - All validation checks passed. Document appears valid."
            )
        
        # Field-specific recommendations
        if critical_issues > 0:
            recommendations.append(
                f"2. Address {critical_issues} critical issue(s) identified in the "
                "Issues section before proceeding."
            )
        
        if warnings > 0:
            recommendations.append(
                f"3. Review {warnings} warning(s) to ensure data accuracy and completeness."
            )
        
        # Anomaly recommendations
        anomalies = validation_report.get('anomalies', [])
        if anomalies:
            recommendations.append(
                f"4. Investigate {len(anomalies)} anomaly/anomalies detected. "
                "Pay special attention to any fraud indicators."
            )
        
        # Manual review recommendation
        if validation_report.get('requires_manual_review'):
            recommendations.append(
                "5. Manual review is strongly recommended due to low confidence "
                "scores or critical validation failures."
            )
        
        # General recommendation
        if not recommendations:
            recommendations.append(
                "1. No specific actions required. Document passed all validation checks."
            )
        
        return "\n".join(recommendations)
    
    def get_report_status(self, document_id: str) -> Optional[Dict[str, Any]]:
        """
        Check if reports exist for a document
        
        Args:
            document_id: Document ID
            
        Returns:
            Dict with report status or None
        """
        try:
            pdf_path = os.path.join(
                self.pdf_generator.output_dir, 
                f"{document_id}_audit_report.pdf"
            )
            word_path = os.path.join(
                self.word_generator.output_dir, 
                f"{document_id}_audit_report.docx"
            )
            
            status = {
                "document_id": document_id,
                "pdf_exists": os.path.exists(pdf_path),
                "word_exists": os.path.exists(word_path),
                "pdf_path": pdf_path if os.path.exists(pdf_path) else None,
                "word_path": word_path if os.path.exists(word_path) else None
            }
            
            return status
            
        except Exception as e:
            logger.error(f"Error checking report status: {e}")
            return None