"""
Chart generation for audit reports using Matplotlib
"""
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Rectangle
import numpy as np
import os
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class ChartGenerator:
    """Generate charts and visualizations for audit reports"""
    
    def __init__(self, output_dir: str = "data/reports/charts"):
        """
        Initialize chart generator
        
        Args:
            output_dir: Directory to save chart images
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # Set style
        plt.style.use('default')
    
    def generate_severity_pie_chart(self, issues: List[Dict], document_id: str) -> str:
        """
        Generate pie chart showing issues by severity
        
        Args:
            issues: List of validation issues
            document_id: Document ID for filename
            
        Returns:
            Path to saved chart image
        """
        try:
            # Count by severity
            severity_counts = {
                'critical': 0,
                'warning': 0,
                'info': 0
            }
            
            for issue in issues:
                severity = issue.get('severity', 'info').lower()
                severity_counts[severity] = severity_counts.get(severity, 0) + 1
            
            # Filter out zeros
            labels = []
            sizes = []
            colors_list = []
            
            color_map = {
                'critical': '#dc3545',  # Red
                'warning': '#ffc107',   # Yellow
                'info': '#17a2b8'       # Blue
            }
            
            for severity, count in severity_counts.items():
                if count > 0:
                    labels.append(f'{severity.capitalize()} ({count})')
                    sizes.append(count)
                    colors_list.append(color_map[severity])
            
            if not sizes:
                # No issues - create empty placeholder
                fig, ax = plt.subplots(figsize=(6, 4))
                ax.text(0.5, 0.5, 'No Issues Found', 
                       ha='center', va='center', fontsize=16, color='green')
                ax.axis('off')
            else:
                # Create pie chart
                fig, ax = plt.subplots(figsize=(8, 6))
                wedges, texts, autotexts = ax.pie(
                    sizes, 
                    labels=labels, 
                    colors=colors_list,
                    autopct='%1.1f%%',
                    startangle=90
                )
                
                # Style
                for autotext in autotexts:
                    autotext.set_color('white')
                    autotext.set_fontweight('bold')
                
                ax.set_title('Issues by Severity', fontsize=14, fontweight='bold')
            
            # Save
            filename = f"{document_id}_severity_pie.png"
            filepath = os.path.join(self.output_dir, filename)
            plt.tight_layout()
            plt.savefig(filepath, dpi=150, bbox_inches='tight')
            plt.close()
            
            logger.info(f"Severity pie chart saved: {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"Error generating severity pie chart: {e}")
            return None
    
    def generate_validation_score_gauge(self, overall_score: float, document_id: str) -> str:
        """
        Generate gauge chart for overall validation score
        
        Args:
            overall_score: Score between 0-1
            document_id: Document ID
            
        Returns:
            Path to saved chart
        """
        try:
            fig, ax = plt.subplots(figsize=(8, 4), subplot_kw={'projection': 'polar'})
            
            # Convert score to angle (0-180 degrees)
            theta = np.radians(180 * overall_score)
            
            # Draw gauge background
            theta_bg = np.linspace(0, np.pi, 100)
            r = np.ones_like(theta_bg)
            
            # Color sections (red, yellow, green)
            ax.fill_between(theta_bg[:33], 0, r[:33], alpha=0.3, color='red', label='Poor (0-33%)')
            ax.fill_between(theta_bg[33:66], 0, r[33:66], alpha=0.3, color='yellow', label='Fair (33-66%)')
            ax.fill_between(theta_bg[66:], 0, r[66:], alpha=0.3, color='green', label='Good (66-100%)')
            
            # Draw needle
            ax.plot([theta, theta], [0, 1], 'k-', linewidth=3)
            ax.plot(theta, 1, 'ko', markersize=10)
            
            # Configure plot
            ax.set_ylim(0, 1)
            ax.set_theta_zero_location('W')
            ax.set_theta_direction(1)
            ax.set_xticks([0, np.pi/2, np.pi])
            ax.set_xticklabels(['0%', '50%', '100%'])
            ax.set_yticks([])
            ax.spines['polar'].set_visible(False)
            ax.grid(False)
            
            # Title
            score_pct = overall_score * 100
            ax.set_title(f'Overall Validation Score: {score_pct:.1f}%', 
                        fontsize=14, fontweight='bold', pad=20)
            
            # Legend
            ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0))
            
            # Save
            filename = f"{document_id}_score_gauge.png"
            filepath = os.path.join(self.output_dir, filename)
            plt.tight_layout()
            plt.savefig(filepath, dpi=150, bbox_inches='tight')
            plt.close()
            
            logger.info(f"Score gauge saved: {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"Error generating score gauge: {e}")
            return None
    
    def generate_checks_bar_chart(self, checks_passed: int, checks_failed: int, 
                                  checks_warning: int, document_id: str) -> str:
        """
        Generate bar chart for validation checks
        
        Args:
            checks_passed: Number of passed checks
            checks_failed: Number of failed checks
            checks_warning: Number of warnings
            document_id: Document ID
            
        Returns:
            Path to saved chart
        """
        try:
            categories = ['Passed', 'Warnings', 'Failed']
            values = [checks_passed, checks_warning, checks_failed]
            colors = ['#28a745', '#ffc107', '#dc3545']  # Green, Yellow, Red
            
            fig, ax = plt.subplots(figsize=(8, 5))
            bars = ax.bar(categories, values, color=colors, edgecolor='black', linewidth=1.5)
            
            # Add value labels on bars
            for bar in bars:
                height = bar.get_height()
                if height > 0:
                    ax.text(bar.get_x() + bar.get_width()/2., height,
                           f'{int(height)}',
                           ha='center', va='bottom', fontsize=12, fontweight='bold')
            
            ax.set_ylabel('Number of Checks', fontsize=12, fontweight='bold')
            ax.set_title('Validation Checks Summary', fontsize=14, fontweight='bold')
            ax.grid(axis='y', alpha=0.3)
            
            # Save
            filename = f"{document_id}_checks_bar.png"
            filepath = os.path.join(self.output_dir, filename)
            plt.tight_layout()
            plt.savefig(filepath, dpi=150, bbox_inches='tight')
            plt.close()
            
            logger.info(f"Checks bar chart saved: {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"Error generating checks bar chart: {e}")
            return None
    
    def generate_all_charts(self, validation_report: Dict[str, Any], 
                           document_id: str) -> Dict[str, str]:
        """
        Generate all charts for a report
        
        Args:
            validation_report: Validation report data
            document_id: Document ID
            
        Returns:
            Dict with chart paths
        """
        charts = {}
        
        # Severity pie chart
        issues = validation_report.get('issues', [])
        charts['severity_pie'] = self.generate_severity_pie_chart(issues, document_id)
        
        # Score gauge
        overall_score = validation_report.get('overall_score', 0)
        charts['score_gauge'] = self.generate_validation_score_gauge(overall_score, document_id)
        
        # Checks bar chart
        checks_passed = validation_report.get('checks_passed', 0)
        checks_failed = validation_report.get('checks_failed', 0)
        checks_warning = validation_report.get('checks_warning', 0)
        charts['checks_bar'] = self.generate_checks_bar_chart(
            checks_passed, checks_failed, checks_warning, document_id
        )
        
        return charts