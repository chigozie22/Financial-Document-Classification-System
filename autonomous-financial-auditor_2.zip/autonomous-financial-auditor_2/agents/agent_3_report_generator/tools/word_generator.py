"""
Word Document Generator using python-docx
"""
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from datetime import datetime
import os
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class WordGenerator:
    """Generate professional Word (.docx) audit reports"""
    
    def __init__(self, output_dir: str = "data/reports"):
        """
        Initialize Word generator
        
        Args:
            output_dir: Directory to save Word documents
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def generate_report(self,
                       extracted_data: Dict[str, Any],
                       validation_report: Dict[str, Any],
                       executive_summary: str,
                       recommendations: str,
                       charts: Dict[str, str],
                       document_id: str) -> str:
        """
        Generate complete Word audit report
        
        Args:
            extracted_data: Data from Agent 1
            validation_report: Report from Agent 2
            executive_summary: LLM-generated summary
            recommendations: LLM-generated recommendations
            charts: Dict of chart file paths
            document_id: Document ID
            
        Returns:
            Path to generated Word document
        """
        try:
            # Create document
            doc = Document()
            
            # Set document properties
            doc.core_properties.title = f"Audit Report - {document_id}"
            doc.core_properties.author = "Autonomous Financial Auditor"
            doc.core_properties.created = datetime.now()
            
            # Cover page
            self._create_cover_page(doc, extracted_data, validation_report)
            doc.add_page_break()
            
            # Executive summary
            self._create_executive_summary(doc, executive_summary)
            
            # Document information
            self._create_document_info(doc, extracted_data)
            
            # Validation results
            self._create_validation_results(doc, validation_report, charts)
            doc.add_page_break()
            
            # Issues breakdown
            self._create_issues_section(doc, validation_report)
            
            # Anomalies
            if validation_report.get('anomalies'):
                self._create_anomalies_section(doc, validation_report)
            
            # Arithmetic checks
            if validation_report.get('arithmetic_checks'):
                self._create_arithmetic_section(doc, validation_report)
            
            # Recommendations
            self._create_recommendations_section(doc, recommendations)
            
            # Save document
            filename = f"{document_id}_audit_report.docx"
            filepath = os.path.join(self.output_dir, filename)
            doc.save(filepath)
            
            logger.info(f"Word report generated: {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"Error generating Word report: {e}", exc_info=True)
            raise
    
    def _add_heading(self, doc: Document, text: str, level: int = 1, 
                    color: RGBColor = RGBColor(31, 71, 136)):
        """Add styled heading"""
        heading = doc.add_heading(text, level=level)
        heading.runs[0].font.color.rgb = color
        return heading
    
    def _add_colored_paragraph(self, doc: Document, text: str, 
                               bg_color: str = None, text_color: str = None):
        """Add paragraph with background color"""
        para = doc.add_paragraph(text)
        
        if text_color:
            run = para.runs[0]
            if text_color == 'white':
                run.font.color.rgb = RGBColor(255, 255, 255)
            elif text_color == 'red':
                run.font.color.rgb = RGBColor(220, 53, 69)
            elif text_color == 'green':
                run.font.color.rgb = RGBColor(40, 167, 69)
        
        if bg_color:
            # Add shading
            shading = OxmlElement('w:shd')
            if bg_color == 'red':
                shading.set(qn('w:fill'), 'DC3545')
            elif bg_color == 'yellow':
                shading.set(qn('w:fill'), 'FFC107')
            elif bg_color == 'green':
                shading.set(qn('w:fill'), '28A745')
            elif bg_color == 'gray':
                shading.set(qn('w:fill'), 'F8F9FA')
            
            para._p.get_or_add_pPr().append(shading)
        
        return para
    
    def _create_cover_page(self, doc: Document, extracted_data: Dict, 
                          validation_report: Dict):
        """Create cover page"""
        
        # Title
        title = doc.add_paragraph()
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title_run = title.add_run("FINANCIAL DOCUMENT\nAUDIT REPORT")
        title_run.font.size = Pt(28)
        title_run.font.bold = True
        title_run.font.color.rgb = RGBColor(31, 71, 136)
        
        doc.add_paragraph()  # Spacer
        
        # Status badge
        status = validation_report.get('validation_status', 'unknown').upper()
        status_para = doc.add_paragraph()
        status_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        status_run = status_para.add_run(f"  STATUS: {status}  ")
        status_run.font.size = Pt(14)
        status_run.font.bold = True
        
        if status == 'FAILED':
            status_run.font.color.rgb = RGBColor(255, 255, 255)
            self._add_colored_paragraph(doc, f"STATUS: {status}", bg_color='red', text_color='white')
        elif status == 'WARNING':
            self._add_colored_paragraph(doc, f"STATUS: {status}", bg_color='yellow')
        else:
            status_run.font.color.rgb = RGBColor(255, 255, 255)
            self._add_colored_paragraph(doc, f"STATUS: {status}", bg_color='green', text_color='white')
        
        doc.add_paragraph()  # Spacer
        
        # Document info table
        table = doc.add_table(rows=9, cols=2)
        table.style = 'Light Grid Accent 1'
        
        # Get document type safely
        doc_type = extracted_data.get('document_type', 'unknown')
        if doc_type:
            doc_type_display = str(doc_type).upper()
        else:
            doc_type_display = 'UNKNOWN'
        
        info_items = [
            ('Document ID:', extracted_data.get('document_id', 'N/A')),
            ('Document Type:', doc_type_display),
            ('Vendor:', extracted_data.get('vendor', 'N/A')),
            ('Total Amount:', f"${extracted_data.get('total_amount', 0):,.2f}"),
            ('Document Date:', extracted_data.get('document_date', 'N/A')),
            ('', ''),
            ('Report Generated:', datetime.now().strftime('%B %d, %Y %H:%M')),
            ('Validation Score:', f"{validation_report.get('overall_score', 0)*100:.1f}%"),
            ('Risk Level:', validation_report.get('risk_level', 'N/A').upper())
        ]
        
        for i, (label, value) in enumerate(info_items):
            row = table.rows[i]
            row.cells[0].text = label
            row.cells[1].text = str(value)
            
            # Bold labels
            if label:
                row.cells[0].paragraphs[0].runs[0].font.bold = True
    
    def _create_executive_summary(self, doc: Document, summary: str):
        """Create executive summary section"""
        
        self._add_heading(doc, "EXECUTIVE SUMMARY", level=1)
        
        paragraphs = summary.split('\n\n') if summary else ["No summary available."]
        for para_text in paragraphs:
            if para_text.strip():
                para = doc.add_paragraph(para_text.strip())
                para.paragraph_format.space_after = Pt(10)
        
        doc.add_paragraph()  # Spacer
    
    def _create_document_info(self, doc: Document, extracted_data: Dict):
        """Create document information section"""
        
        self._add_heading(doc, "DOCUMENT INFORMATION", level=1)
        
        # Create table
        table = doc.add_table(rows=11, cols=2)
        table.style = 'Light Grid Accent 1'
        
        info_items = [
            ('Vendor Name', extracted_data.get('vendor', 'N/A')),
            ('Vendor Email', extracted_data.get('vendor_email', 'N/A')),
            ('Vendor Phone', extracted_data.get('vendor_phone', 'N/A')),
            ('Invoice Number', extracted_data.get('invoice_number', 'N/A')),
            ('Document Date', extracted_data.get('document_date', 'N/A')),
            ('Due Date', extracted_data.get('due_date', 'N/A')),
            ('Subtotal', f"${extracted_data.get('subtotal', 0) or 0:,.2f}"),
            ('Tax Amount', f"${extracted_data.get('tax_amount', 0) or 0:,.2f}"),
            ('Total Amount', f"${extracted_data.get('total_amount', 0):,.2f}"),
            ('Currency', extracted_data.get('currency', 'USD')),
            ('Extraction Confidence', f"{extracted_data.get('extraction_confidence', 0)*100:.1f}%"),
        ]
        
        for i, (label, value) in enumerate(info_items):
            row = table.rows[i]
            row.cells[0].text = label
            row.cells[1].text = str(value)
            row.cells[0].paragraphs[0].runs[0].font.bold = True
        
        doc.add_paragraph()  # Spacer
    
    def _create_validation_results(self, doc: Document, validation_report: Dict, 
                                   charts: Dict):
        """Create validation results section"""
        
        self._add_heading(doc, "VALIDATION RESULTS", level=1)
        
        # Summary table
        table = doc.add_table(rows=8, cols=2)
        table.style = 'Light Grid Accent 1'
        
        metrics = [
            ('Overall Score', f"{validation_report.get('overall_score', 0)*100:.1f}%"),
            ('Confidence Score', f"{validation_report.get('confidence_score', 0)*100:.1f}%"),
            ('Checks Performed', str(validation_report.get('checks_performed', 0))),
            ('Checks Passed', str(validation_report.get('checks_passed', 0))),
            ('Checks Failed', str(validation_report.get('checks_failed', 0))),
            ('Warnings', str(validation_report.get('checks_warning', 0))),
            ('Risk Level', validation_report.get('risk_level', 'N/A').upper()),
            ('Manual Review Required', 'YES' if validation_report.get('requires_manual_review') else 'NO')
        ]
        
        for i, (label, value) in enumerate(metrics):
            row = table.rows[i]
            row.cells[0].text = label
            row.cells[1].text = value
            row.cells[0].paragraphs[0].runs[0].font.bold = True
        
        doc.add_paragraph()  # Spacer
        
        # Add charts
        if charts:
            if charts.get('score_gauge') and os.path.exists(charts['score_gauge']):
                doc.add_picture(charts['score_gauge'], width=Inches(5))
                doc.add_paragraph()
            
            if charts.get('checks_bar') and os.path.exists(charts['checks_bar']):
                doc.add_picture(charts['checks_bar'], width=Inches(5))
                doc.add_paragraph()
    
    def _create_issues_section(self, doc: Document, validation_report: Dict):
        """Create issues breakdown section"""
        
        issues = validation_report.get('issues', [])
        
        self._add_heading(doc, f"ISSUES FOUND ({len(issues)})", level=1)
        
        if not issues:
            doc.add_paragraph("✓ No issues found")
            doc.add_paragraph()
            return
        
        # Create table
        table = doc.add_table(rows=len(issues) + 1, cols=4)
        table.style = 'Light Grid Accent 1'
        
        # Header row
        header_cells = table.rows[0].cells
        headers = ['Severity', 'Field', 'Issue', 'Suggestion']
        for i, header in enumerate(headers):
            header_cells[i].text = header
            header_cells[i].paragraphs[0].runs[0].font.bold = True
        
        # Data rows
        for i, issue in enumerate(issues):
            row = table.rows[i + 1]
            row.cells[0].text = issue.get('severity', 'info').upper()
            row.cells[1].text = issue.get('field', 'N/A')
            row.cells[2].text = issue.get('message', 'N/A')
            row.cells[3].text = issue.get('suggestion', '-') or '-'
        
        doc.add_paragraph()  # Spacer
    
    def _create_anomalies_section(self, doc: Document, validation_report: Dict):
        """Create anomalies section"""
        
        anomalies = validation_report.get('anomalies', [])
        
        self._add_heading(doc, f"ANOMALIES DETECTED ({len(anomalies)})", level=1)
        
        # Create table
        table = doc.add_table(rows=len(anomalies) + 1, cols=4)
        table.style = 'Light Grid Accent 1'
        
        # Header
        header_cells = table.rows[0].cells
        headers = ['Type', 'Field', 'Reason', 'Score']
        for i, header in enumerate(headers):
            header_cells[i].text = header
            header_cells[i].paragraphs[0].runs[0].font.bold = True
        
        # Data
        for i, anomaly in enumerate(anomalies):
            row = table.rows[i + 1]
            row.cells[0].text = anomaly.get('type', 'N/A').replace('_', ' ').title()
            row.cells[1].text = anomaly.get('field', 'N/A')
            row.cells[2].text = anomaly.get('reason', 'N/A')
            row.cells[3].text = f"{anomaly.get('anomaly_score', 0):.2f}"
        
        doc.add_paragraph()  # Spacer
    
    def _create_arithmetic_section(self, doc: Document, validation_report: Dict):
        """Create arithmetic checks section"""
        
        checks = validation_report.get('arithmetic_checks', {})
        
        if not checks:
            return
        
        self._add_heading(doc, "ARITHMETIC VALIDATION", level=1)
        
        # Create table
        table = doc.add_table(rows=len(checks) + 1, cols=5)
        table.style = 'Light Grid Accent 1'
        
        # Header
        header_cells = table.rows[0].cells
        headers = ['Check', 'Result', 'Expected', 'Actual', 'Difference']
        for i, header in enumerate(headers):
            header_cells[i].text = header
            header_cells[i].paragraphs[0].runs[0].font.bold = True
        
        # Data
        for i, (check_name, check_data) in enumerate(checks.items()):
            row = table.rows[i + 1]
            row.cells[0].text = check_data.get('check_name', check_name)
            row.cells[1].text = '✓ PASS' if check_data.get('passed') else '✗ FAIL'
            row.cells[2].text = f"${check_data.get('expected', 0):,.2f}" if check_data.get('expected') else 'N/A'
            row.cells[3].text = f"${check_data.get('actual', 0):,.2f}" if check_data.get('actual') else 'N/A'
            row.cells[4].text = f"${abs(check_data.get('difference', 0)):,.2f}" if check_data.get('difference') else 'N/A'
        
        doc.add_paragraph()  # Spacer
    
    def _create_recommendations_section(self, doc: Document, recommendations: str):
        """Create recommendations section"""
        
        self._add_heading(doc, "RECOMMENDATIONS", level=1)
        
        lines = recommendations.split('\n') if recommendations else ["No recommendations available."]
        for line in lines:
            if line.strip():
                doc.add_paragraph(line.strip())
        
        doc.add_paragraph()  # Spacer