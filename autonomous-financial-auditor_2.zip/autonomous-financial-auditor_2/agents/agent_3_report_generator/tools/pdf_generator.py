"""
PDF Report Generator using ReportLab
"""
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image, KeepTogether
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from datetime import datetime
import os
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)


class PDFGenerator:
    """Generate professional PDF audit reports"""
    
    def __init__(self, output_dir: str = "data/reports"):
        """
        Initialize PDF generator
        
        Args:
            output_dir: Directory to save PDF reports
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # Initialize styles
        self.styles = getSampleStyleSheet()
        self._create_custom_styles()
    
    def _create_custom_styles(self):
        """Create custom paragraph styles"""
        
        # Title style
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1f4788'),
            spaceAfter=30,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        ))
        
        # Section heading
        self.styles.add(ParagraphStyle(
            name='SectionHeading',
            parent=self.styles['Heading2'],
            fontSize=16,
            textColor=colors.HexColor('#1f4788'),
            spaceAfter=12,
            spaceBefore=12,
            fontName='Helvetica-Bold'
        ))
        
        # Body text
        self.styles.add(ParagraphStyle(
            name='CustomBody',
            parent=self.styles['Normal'],
            fontSize=11,
            leading=14,
            alignment=TA_JUSTIFY,
            spaceAfter=10
        ))
        
        # Status - Critical
        self.styles.add(ParagraphStyle(
            name='Critical',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.white,
            backColor=colors.HexColor('#dc3545'),
            borderPadding=5
        ))
        
        # Status - Warning
        self.styles.add(ParagraphStyle(
            name='Warning',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.black,
            backColor=colors.HexColor('#ffc107'),
            borderPadding=5
        ))
        
        # Status - Success
        self.styles.add(ParagraphStyle(
            name='Success',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.white,
            backColor=colors.HexColor('#28a745'),
            borderPadding=5
        ))
    
    def generate_report(self,
                       extracted_data: Dict[str, Any],
                       validation_report: Dict[str, Any],
                       executive_summary: str,
                       recommendations: str,
                       charts: Dict[str, str],
                       document_id: str) -> str:
        """
        Generate complete PDF audit report
        
        Args:
            extracted_data: Data from Agent 1
            validation_report: Report from Agent 2
            executive_summary: LLM-generated summary
            recommendations: LLM-generated recommendations
            charts: Dict of chart file paths
            document_id: Document ID
            
        Returns:
            Path to generated PDF
        """
        try:
            # Create PDF filename
            filename = f"{document_id}_audit_report.pdf"
            filepath = os.path.join(self.output_dir, filename)
            
            # Create document
            doc = SimpleDocTemplate(
                filepath,
                pagesize=letter,
                rightMargin=0.75*inch,
                leftMargin=0.75*inch,
                topMargin=0.75*inch,
                bottomMargin=0.75*inch
            )
            
            # Build content
            story = []
            
            # Cover page
            story.extend(self._create_cover_page(extracted_data, validation_report))
            story.append(PageBreak())
            
            # Executive summary
            story.extend(self._create_executive_summary(executive_summary))
            story.append(Spacer(1, 0.3*inch))
            
            # Document information
            story.extend(self._create_document_info(extracted_data))
            story.append(Spacer(1, 0.3*inch))
            
            # Validation results with charts
            story.extend(self._create_validation_results(validation_report, charts))
            story.append(PageBreak())
            
            # Issues breakdown
            story.extend(self._create_issues_section(validation_report))
            story.append(Spacer(1, 0.3*inch))
            
            # Anomalies
            if validation_report.get('anomalies'):
                story.extend(self._create_anomalies_section(validation_report))
                story.append(Spacer(1, 0.3*inch))
            
            # Arithmetic checks
            if validation_report.get('arithmetic_checks'):
                story.extend(self._create_arithmetic_section(validation_report))
                story.append(Spacer(1, 0.3*inch))
            
            # Recommendations
            story.extend(self._create_recommendations_section(recommendations))
            
            # Build PDF
            doc.build(story)
            
            logger.info(f"PDF report generated: {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"Error generating PDF report: {e}", exc_info=True)
            raise
    
    def _create_cover_page(self, extracted_data: Dict, validation_report: Dict) -> List:
        """Create report cover page"""
        elements = []
        
        # Title
        elements.append(Spacer(1, 1.5*inch))
        elements.append(Paragraph("FINANCIAL DOCUMENT", self.styles['CustomTitle']))
        elements.append(Paragraph("AUDIT REPORT", self.styles['CustomTitle']))
        elements.append(Spacer(1, 0.5*inch))
        
        # Status badge
        status = validation_report.get('validation_status', 'unknown').upper()
        if status == 'FAILED':
            status_style = self.styles['Critical']
        elif status == 'WARNING':
            status_style = self.styles['Warning']
        else:
            status_style = self.styles['Success']
        
        status_text = Paragraph(f"<para align=center><b>STATUS: {status}</b></para>", status_style)
        elements.append(status_text)
        elements.append(Spacer(1, 0.5*inch))
        
        # Document info table
        # Get document type safely
        doc_type = extracted_data.get('document_type', 'unknown')
        if doc_type:
            doc_type_display = str(doc_type).upper()
        else:
            doc_type_display = 'UNKNOWN'
            
        info_data = [
            ['Document ID:', extracted_data.get('document_id', 'N/A')],
            ['Document Type:', doc_type_display],
            ['Vendor:', extracted_data.get('vendor', 'N/A')],
            ['Total Amount:', f"${extracted_data.get('total_amount', 0):,.2f}"],
            ['Document Date:', extracted_data.get('document_date', 'N/A')],
            ['', ''],
            ['Report Generated:', datetime.now().strftime('%B %d, %Y %H:%M')],
            ['Validation Score:', f"{validation_report.get('overall_score', 0)*100:.1f}%"],
            ['Risk Level:', validation_report.get('risk_level', 'N/A').upper()]
        ]
        
        info_table = Table(info_data, colWidths=[2*inch, 4*inch])
        info_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 11),
            ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
            ('ALIGN', (1, 0), (1, -1), 'LEFT'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))
        
        elements.append(info_table)
        
        return elements
    
    def _create_executive_summary(self, summary: str) -> List:
        """Create executive summary section"""
        elements = []
        
        elements.append(Paragraph("EXECUTIVE SUMMARY", self.styles['SectionHeading']))
        elements.append(Spacer(1, 0.1*inch))
        
        # Split summary into paragraphs
        paragraphs = summary.split('\n\n') if summary else ["No summary available."]
        for para in paragraphs:
            if para.strip():
                elements.append(Paragraph(para, self.styles['CustomBody']))
        
        return elements
    
    def _create_document_info(self, extracted_data: Dict) -> List:
        """Create document information section"""
        elements = []
        
        elements.append(Paragraph("DOCUMENT INFORMATION", self.styles['SectionHeading']))
        
        data = [
            ['Field', 'Value'],
            ['Vendor Name', extracted_data.get('vendor', 'N/A')],
            ['Vendor Email', extracted_data.get('vendor_email', 'N/A')],
            ['Vendor Phone', extracted_data.get('vendor_phone', 'N/A')],
            ['Invoice Number', extracted_data.get('invoice_number', 'N/A')],
            ['Document Date', extracted_data.get('document_date', 'N/A')],
            ['Due Date', extracted_data.get('due_date', 'N/A')],
            ['Subtotal', f"${extracted_data.get('subtotal', 0) or 0:,.2f}"],
            ['Tax Amount', f"${extracted_data.get('tax_amount', 0) or 0:,.2f}"],
            ['Total Amount', f"${extracted_data.get('total_amount', 0):,.2f}"],
            ['Currency', extracted_data.get('currency', 'USD')],
        ]
        
        table = Table(data, colWidths=[2.5*inch, 4*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1f4788')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 11),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9fa')])
        ]))
        
        elements.append(table)
        
        return elements
    
    def _create_validation_results(self, validation_report: Dict, charts: Dict) -> List:
        """Create validation results section with charts"""
        elements = []
        
        elements.append(Paragraph("VALIDATION RESULTS", self.styles['SectionHeading']))
        elements.append(Spacer(1, 0.1*inch))
        
        # Summary stats
        summary_data = [
            ['Metric', 'Value'],
            ['Overall Score', f"{validation_report.get('overall_score', 0)*100:.1f}%"],
            ['Confidence Score', f"{validation_report.get('confidence_score', 0)*100:.1f}%"],
            ['Checks Performed', str(validation_report.get('checks_performed', 0))],
            ['Checks Passed', str(validation_report.get('checks_passed', 0))],
            ['Checks Failed', str(validation_report.get('checks_failed', 0))],
            ['Warnings', str(validation_report.get('checks_warning', 0))],
            ['Risk Level', validation_report.get('risk_level', 'N/A').upper()],
        ]
        
        summary_table = Table(summary_data, colWidths=[2.5*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1f4788')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9fa')])
        ]))
        
        elements.append(summary_table)
        elements.append(Spacer(1, 0.3*inch))
        
        # Add charts
        if charts:
            # Score gauge
            if charts.get('score_gauge') and os.path.exists(charts['score_gauge']):
                elements.append(Image(charts['score_gauge'], width=5*inch, height=2.5*inch))
                elements.append(Spacer(1, 0.2*inch))
            
            # Checks bar chart
            if charts.get('checks_bar') and os.path.exists(charts['checks_bar']):
                elements.append(Image(charts['checks_bar'], width=5*inch, height=3*inch))
        
        return elements
    
    def _create_issues_section(self, validation_report: Dict) -> List:
        """Create issues breakdown section"""
        elements = []
        
        issues = validation_report.get('issues', [])
        
        if not issues:
            elements.append(Paragraph("ISSUES FOUND", self.styles['SectionHeading']))
            elements.append(Paragraph("✓ No issues found", self.styles['CustomBody']))
            return elements
        
        elements.append(Paragraph(f"ISSUES FOUND ({len(issues)})", self.styles['SectionHeading']))
        
        # Create table
        table_data = [['Severity', 'Field', 'Issue', 'Suggestion']]
        
        for issue in issues:
            severity = issue.get('severity', 'info').upper()
            field = issue.get('field', 'N/A')
            message = issue.get('message', 'N/A')
            suggestion = issue.get('suggestion', '-')
            
            # Truncate long messages
            if len(message) > 50:
                message = message[:47] + "..."
            if suggestion and len(suggestion) > 50:
                suggestion = suggestion[:47] + "..."
            
            table_data.append([severity, field, message, suggestion or '-'])
        
        table = Table(table_data, colWidths=[1*inch, 1.5*inch, 2.5*inch, 1.5*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1f4788')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9fa')])
        ]))
        
        elements.append(table)
        
        return elements
    
    def _create_anomalies_section(self, validation_report: Dict) -> List:
        """Create anomalies section"""
        elements = []
        
        anomalies = validation_report.get('anomalies', [])
        
        elements.append(Paragraph(f"ANOMALIES DETECTED ({len(anomalies)})", self.styles['SectionHeading']))
        
        table_data = [['Type', 'Field', 'Reason', 'Score']]
        
        for anomaly in anomalies:
            anom_type = anomaly.get('type', 'N/A').replace('_', ' ').title()
            field = anomaly.get('field', 'N/A')
            reason = anomaly.get('reason', 'N/A')
            score = f"{anomaly.get('anomaly_score', 0):.2f}"
            
            if len(reason) > 60:
                reason = reason[:57] + "..."
            
            table_data.append([anom_type, field, reason, score])
        
        table = Table(table_data, colWidths=[1.2*inch, 1.2*inch, 3.5*inch, 0.6*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1f4788')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9fa')])
        ]))
        
        elements.append(table)
        
        return elements
    
    def _create_arithmetic_section(self, validation_report: Dict) -> List:
        """Create arithmetic checks section"""
        elements = []
        
        checks = validation_report.get('arithmetic_checks', {})
        
        if not checks:
            return elements
        
        elements.append(Paragraph("ARITHMETIC VALIDATION", self.styles['SectionHeading']))
        
        table_data = [['Check', 'Result', 'Expected', 'Actual', 'Difference']]
        
        for check_name, check_data in checks.items():
            name = check_data.get('check_name', check_name)
            passed = '✓ PASS' if check_data.get('passed') else '✗ FAIL'
            expected = f"${check_data.get('expected', 0):,.2f}" if check_data.get('expected') else 'N/A'
            actual = f"${check_data.get('actual', 0):,.2f}" if check_data.get('actual') else 'N/A'
            diff = f"${abs(check_data.get('difference', 0)):,.2f}" if check_data.get('difference') else 'N/A'
            
            table_data.append([name, passed, expected, actual, diff])
        
        table = Table(table_data, colWidths=[2*inch, 1*inch, 1*inch, 1*inch, 1*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1f4788')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9fa')])
        ]))
        
        elements.append(table)
        
        return elements
    
    def _create_recommendations_section(self, recommendations: str) -> List:
        """Create recommendations section"""
        elements = []
        
        elements.append(Paragraph("RECOMMENDATIONS", self.styles['SectionHeading']))
        elements.append(Spacer(1, 0.1*inch))
        
        # Split into lines
        lines = recommendations.split('\n') if recommendations else ["No recommendations available."]
        for line in lines:
            if line.strip():
                elements.append(Paragraph(line, self.styles['CustomBody']))
        
        return elements
    