"""
Prompts for LLM-based contextual validation
"""

VALIDATION_SYSTEM_PROMPT = """You are a financial auditing expert specializing in document validation.

Your task is to review extracted financial data and provide contextual validation that goes beyond simple rules.

Focus on:
1. Contextual reasonableness (does the data make logical sense?)
2. Inconsistencies that might not be caught by rules
3. Industry-standard expectations
4. Red flags in vendor/customer information
5. Overall document coherence

Be specific and actionable in your findings. Return ONLY valid JSON."""


CONTEXTUAL_VALIDATION_PROMPT = """Review this extracted financial document data for contextual issues:

**Document Type:** {document_type}
**Vendor:** {vendor}
**Total Amount:** ${total_amount}
**Date:** {document_date}

**Full Extracted Data:**
{extracted_data_json}

**OCR Confidence:** {ocr_confidence}
**Extraction Confidence:** {extraction_confidence}

**Validation Tasks:**
1. Does the vendor name look legitimate? (not gibberish, not OCR errors)
2. Is the document type classification correct based on the content?
3. Do the amounts seem reasonable for this type of document?
4. Are there any logical inconsistencies in the data?
5. Does the extracted information coherently represent a real financial document?

Return a JSON object with this structure:
{{
  "is_contextually_valid": true/false,
  "confidence": 0.0-1.0,
  "issues": [
    {{
      "field": "field_name",
      "severity": "warning" or "critical" or "info",
      "issue": "description of the issue",
      "suggestion": "how to fix or what to check"
    }}
  ],
  "document_type_suggestion": "suggested document type if current is wrong, else null",
  "overall_assessment": "brief summary of validation"
}}

Return ONLY the JSON object, no markdown formatting."""


VENDOR_VALIDATION_PROMPT = """Validate this vendor information:

**Vendor Name:** {vendor}
**Vendor Address:** {vendor_address}
**Vendor Email:** {vendor_email}
**Vendor Phone:** {vendor_phone}

**Context:**
- Total Amount: ${total_amount}
- Document Type: {document_type}

Questions to answer:
1. Does this vendor name look real or like an OCR error?
2. Is the vendor information complete enough for this transaction amount?
3. Are there any red flags (missing contact info for high-value transactions)?
4. Does the vendor name match common business naming patterns?

Return JSON:
{{
  "vendor_looks_legitimate": true/false,
  "confidence": 0.0-1.0,
  "issues": ["list of issues found"],
  "risk_level": "low" or "medium" or "high",
  "reasoning": "brief explanation"
}}

Return ONLY the JSON object."""


AMOUNT_REASONABLENESS_PROMPT = """Assess if these amounts are reasonable:

**Document Type:** {document_type}
**Vendor:** {vendor}
**Subtotal:** ${subtotal}
**Tax Amount:** ${tax_amount}
**Tax Rate:** {tax_rate}%
**Total Amount:** ${total_amount}
**Line Items Count:** {line_items_count}

Context:
- Is the total amount reasonable for this type of document?
- Is the tax rate typical for common jurisdictions?
- Do the line items count make sense for this total?

Return JSON:
{{
  "amounts_seem_reasonable": true/false,
  "confidence": 0.0-1.0,
  "concerns": ["list of concerns if any"],
  "expected_range": "what would be a typical range for this",
  "reasoning": "brief explanation"
}}

Return ONLY the JSON object."""


def format_contextual_validation_prompt(data: dict) -> str:
    """Format the contextual validation prompt with actual data"""
    import json
    
    return CONTEXTUAL_VALIDATION_PROMPT.format(
        document_type=data.get("document_type", "unknown"),
        vendor=data.get("vendor", "N/A"),
        total_amount=data.get("total_amount", 0),
        document_date=data.get("document_date", "N/A"),
        extracted_data_json=json.dumps(data, indent=2)[:2000],  # Limit size
        ocr_confidence=data.get("ocr_confidence", 0),
        extraction_confidence=data.get("extraction_confidence", 0)
    )


def format_vendor_validation_prompt(data: dict) -> str:
    """Format vendor validation prompt"""
    return VENDOR_VALIDATION_PROMPT.format(
        vendor=data.get("vendor", "N/A"),
        vendor_address=data.get("vendor_address", "N/A"),
        vendor_email=data.get("vendor_email", "N/A"),
        vendor_phone=data.get("vendor_phone", "N/A"),
        total_amount=data.get("total_amount", 0),
        document_type=data.get("document_type", "unknown")
    )


def format_amount_reasonableness_prompt(data: dict) -> str:
    """Format amount reasonableness prompt"""
    return AMOUNT_REASONABLENESS_PROMPT.format(
        document_type=data.get("document_type", "unknown"),
        vendor=data.get("vendor", "N/A"),
        subtotal=data.get("subtotal", 0) or 0,
        tax_amount=data.get("tax_amount", 0) or 0,
        tax_rate=data.get("tax_rate", 0) or 0,
        total_amount=data.get("total_amount", 0),
        line_items_count=len(data.get("line_items", []))
    )