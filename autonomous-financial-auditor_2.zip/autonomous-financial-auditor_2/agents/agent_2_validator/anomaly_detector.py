"""
Anomaly Detection Engine for financial documents
Uses ML models (Isolation Forest) and statistical methods
"""
from typing import Dict, Any, List, Optional
import numpy as np
from sklearn.ensemble import IsolationForest
from collections import Counter
import logging
import re

from models.validation_schemas import (
    AnomalyResult,
    AnomalyType,
    ValidationSeverity
)

logger = logging.getLogger(__name__)


class AnomalyDetector:
    """Detect anomalies and fraud patterns in financial data"""
    
    def __init__(self, contamination: float = 0.1):
        """
        Initialize anomaly detector
        
        Args:
            contamination: Expected proportion of outliers (default 10%)
        """
        self.contamination = contamination
        self.isolation_forest = None
        self.historical_data = []  # Store for training
        
    def detect_all_anomalies(self, data: Dict[str, Any], 
                            historical_data: Optional[List[Dict]] = None) -> List[AnomalyResult]:
        """
        Run all anomaly detection checks
        
        Args:
            data: Extracted data from Agent 1
            historical_data: Optional historical documents for comparison
            
        Returns:
            List of detected anomalies
        """
        anomalies = []
        
        # Statistical outlier detection
        if historical_data:
            anomalies.extend(self.detect_statistical_outliers(data, historical_data))
        else:
            # Use basic statistical checks without historical data
            anomalies.extend(self.detect_basic_anomalies(data))
        
        # Duplicate detection
        anomalies.extend(self.detect_duplicates(data, historical_data or []))
        
        # Fraud pattern detection
        anomalies.extend(self.detect_fraud_patterns(data))
        
        # Suspicious amount patterns
        anomalies.extend(self.detect_suspicious_amounts(data))
        
        return anomalies
    
    def detect_statistical_outliers(self, data: Dict[str, Any], 
                                   historical_data: List[Dict]) -> List[AnomalyResult]:
        """
        Use Isolation Forest to detect statistical outliers
        
        Args:
            data: Current document data
            historical_data: Historical documents for training
            
        Returns:
            List of anomaly results
        """
        anomalies = []
        
        try:
            # Extract numerical features for ML
            features = self._extract_numerical_features(data)
            historical_features = [self._extract_numerical_features(doc) for doc in historical_data]
            
            if not historical_features or len(historical_features) < 5:
                logger.warning("Not enough historical data for ML outlier detection")
                return anomalies
            
            # Prepare training data
            X_train = np.array(historical_features)
            X_current = np.array([features])
            
            # Train Isolation Forest
            iso_forest = IsolationForest(
                contamination=self.contamination,
                random_state=42,
                n_estimators=100
            )
            iso_forest.fit(X_train)
            
            # Predict anomaly
            prediction = iso_forest.predict(X_current)[0]
            anomaly_score = iso_forest.score_samples(X_current)[0]
            
            # If anomaly detected (prediction = -1)
            if prediction == -1:
                # Determine which feature is most anomalous
                total_amount = data.get("total_amount")
                
                if total_amount:
                    historical_amounts = [doc.get("total_amount", 0) for doc in historical_data if doc.get("total_amount")]
                    
                    if historical_amounts:
                        avg_amount = np.mean(historical_amounts)
                        std_amount = np.std(historical_amounts)
                        
                        anomalies.append(AnomalyResult(
                            type=AnomalyType.OUTLIER,
                            severity=ValidationSeverity.WARNING if abs(anomaly_score) < 0.5 else ValidationSeverity.CRITICAL,
                            field="total_amount",
                            value=total_amount,
                            reason=f"Amount is statistically unusual compared to historical data (avg: ${avg_amount:.2f}, std: ${std_amount:.2f})",
                            anomaly_score=abs(anomaly_score),
                            context={
                                "historical_avg": round(avg_amount, 2),
                                "historical_std": round(std_amount, 2),
                                "z_score": round((total_amount - avg_amount) / std_amount, 2) if std_amount > 0 else 0
                            }
                        ))
        
        except Exception as e:
            logger.error(f"Error in statistical outlier detection: {e}")
        
        return anomalies
    
    def detect_basic_anomalies(self, data: Dict[str, Any]) -> List[AnomalyResult]:
        """
        Detect basic anomalies without historical data
        Uses simple statistical rules
        """
        anomalies = []
        
        # Check for unusually round numbers (potential fraud)
        total_amount = data.get("total_amount")
        if total_amount and total_amount > 1000:
            # Check if it's a very round number (e.g., 10000, 50000)
            if total_amount % 1000 == 0 or total_amount % 500 == 0:
                anomalies.append(AnomalyResult(
                    type=AnomalyType.SUSPICIOUS,
                    severity=ValidationSeverity.INFO,
                    field="total_amount",
                    value=total_amount,
                    reason="Amount is a very round number, which is uncommon in invoices",
                    anomaly_score=0.6,
                    context={"pattern": "round_number"}
                ))
        
        # Check for extremely low OCR confidence
        ocr_confidence = data.get("ocr_confidence", 1.0)
        if ocr_confidence < 0.3:
            anomalies.append(AnomalyResult(
                type=AnomalyType.SUSPICIOUS,
                severity=ValidationSeverity.WARNING,
                field="ocr_confidence",
                value=ocr_confidence,
                reason="Very low OCR confidence suggests poor document quality",
                anomaly_score=1.0 - ocr_confidence
            ))
        
        # Check for extremely low extraction confidence
        extraction_confidence = data.get("extraction_confidence", 1.0)
        if extraction_confidence < 0.5:
            anomalies.append(AnomalyResult(
                type=AnomalyType.SUSPICIOUS,
                severity=ValidationSeverity.WARNING,
                field="extraction_confidence",
                value=extraction_confidence,
                reason="Low extraction confidence suggests uncertain data quality",
                anomaly_score=1.0 - extraction_confidence
            ))
        
        return anomalies
    
    def detect_duplicates(self, data: Dict[str, Any], 
                         historical_data: List[Dict]) -> List[AnomalyResult]:
        """
        Detect potential duplicate transactions
        
        Args:
            data: Current document
            historical_data: Historical documents
            
        Returns:
            List of duplicate anomalies
        """
        anomalies = []
        
        if not historical_data:
            return anomalies
        
        current_invoice = data.get("invoice_number")
        current_amount = data.get("total_amount")
        current_date = data.get("document_date")
        current_vendor = data.get("vendor")
        
        if not current_invoice or not current_amount:
            return anomalies
        
        # Check for exact invoice number match
        for doc in historical_data:
            hist_invoice = doc.get("invoice_number")
            
            if hist_invoice and current_invoice == hist_invoice:
                anomalies.append(AnomalyResult(
                    type=AnomalyType.DUPLICATE,
                    severity=ValidationSeverity.CRITICAL,
                    field="invoice_number",
                    value=current_invoice,
                    reason="Invoice number matches existing document - possible duplicate",
                    anomaly_score=1.0,
                    context={"matching_document_id": doc.get("document_id")}
                ))
                break
        
        # Check for similar amount, vendor, and date (fuzzy duplicate)
        for doc in historical_data:
            hist_amount = doc.get("total_amount")
            hist_vendor = doc.get("vendor")
            hist_date = doc.get("document_date")
            
            # Check if amount, vendor, and date are similar
            amount_match = hist_amount and abs(current_amount - hist_amount) < 0.01
            vendor_match = hist_vendor and current_vendor and self._similar_strings(current_vendor, hist_vendor)
            date_match = hist_date and current_date == hist_date
            
            if amount_match and vendor_match and date_match:
                anomalies.append(AnomalyResult(
                    type=AnomalyType.DUPLICATE,
                    severity=ValidationSeverity.WARNING,
                    field="transaction",
                    value=f"{current_vendor} - ${current_amount}",
                    reason="Similar transaction found (same vendor, amount, date) - possible duplicate",
                    anomaly_score=0.85,
                    context={"matching_document_id": doc.get("document_id")}
                ))
                break
        
        return anomalies
    
    def detect_fraud_patterns(self, data: Dict[str, Any]) -> List[AnomalyResult]:
        """
        Detect known fraud patterns
        
        Args:
            data: Document data
            
        Returns:
            List of fraud pattern anomalies
        """
        anomalies = []
        
        # Pattern 1: Missing vendor information (ghost vendor)
        if not data.get("vendor") or not data.get("vendor_address"):
            if data.get("total_amount", 0) > 1000:
                anomalies.append(AnomalyResult(
                    type=AnomalyType.FRAUD_PATTERN,
                    severity=ValidationSeverity.WARNING,
                    field="vendor",
                    value=data.get("vendor"),
                    reason="High-value transaction with missing vendor details",
                    anomaly_score=0.7,
                    context={"pattern": "ghost_vendor"}
                ))
        
        # Pattern 2: Repeated amounts (split invoicing fraud)
        line_items = data.get("line_items", [])
        if line_items and len(line_items) > 3:
            amounts = [item.get("total", 0) for item in line_items]
            amount_counts = Counter(amounts)
            
            # If any amount appears more than twice
            for amount, count in amount_counts.items():
                if count > 2 and amount > 0:
                    anomalies.append(AnomalyResult(
                        type=AnomalyType.FRAUD_PATTERN,
                        severity=ValidationSeverity.INFO,
                        field="line_items",
                        value=amount,
                        reason=f"Same amount (${amount}) appears {count} times in line items - unusual pattern",
                        anomaly_score=0.6,
                        context={"pattern": "repeated_amounts", "count": count}
                    ))
                    break
        
        # Pattern 3: Invoice number format anomaly
        invoice_number = data.get("invoice_number")
        if invoice_number:
            # Check for suspicious patterns
            suspicious_patterns = [
                r"test",
                r"sample",
                r"xxx",
                r"000",
                r"dummy"
            ]
            
            for pattern in suspicious_patterns:
                if re.search(pattern, str(invoice_number), re.IGNORECASE):
                    anomalies.append(AnomalyResult(
                        type=AnomalyType.FRAUD_PATTERN,
                        severity=ValidationSeverity.WARNING,
                        field="invoice_number",
                        value=invoice_number,
                        reason=f"Invoice number contains suspicious pattern: '{pattern}'",
                        anomaly_score=0.75,
                        context={"pattern": "suspicious_invoice_format"}
                    ))
                    break
        
        return anomalies
    
    def detect_suspicious_amounts(self, data: Dict[str, Any]) -> List[AnomalyResult]:
        """
        Detect suspicious amount patterns
        
        Args:
            data: Document data
            
        Returns:
            List of suspicious amount anomalies
        """
        anomalies = []
        
        total_amount = data.get("total_amount")
        
        if not total_amount:
            return anomalies
        
        # Check for amounts just below common thresholds (splitting)
        thresholds = [1000, 5000, 10000, 25000, 50000]
        
        for threshold in thresholds:
            # If amount is 95-99% of threshold (e.g., $990 for $1000 threshold)
            if threshold * 0.95 <= total_amount < threshold:
                anomalies.append(AnomalyResult(
                    type=AnomalyType.SUSPICIOUS,
                    severity=ValidationSeverity.INFO,
                    field="total_amount",
                    value=total_amount,
                    reason=f"Amount (${total_amount}) is just below common threshold (${threshold}) - possible splitting",
                    anomaly_score=0.65,
                    context={"threshold": threshold, "pattern": "threshold_splitting"}
                ))
                break
        
        # Check for unusual decimal patterns (e.g., $1234.56 is more natural than $1234.00)
        if total_amount > 100:
            decimal_part = total_amount - int(total_amount)
            if decimal_part == 0:
                # Whole number amounts are slightly suspicious for large invoices
                if total_amount > 5000:
                    anomalies.append(AnomalyResult(
                        type=AnomalyType.SUSPICIOUS,
                        severity=ValidationSeverity.INFO,
                        field="total_amount",
                        value=total_amount,
                        reason="Large invoice with exact dollar amount (no cents) is unusual",
                        anomaly_score=0.55,
                        context={"pattern": "round_amount"}
                    ))
        
        return anomalies
    
    # Helper methods
    
    def _extract_numerical_features(self, data: Dict[str, Any]) -> List[float]:
        """
        Extract numerical features for ML model
        
        Returns:
            List of numerical features
        """
        features = [
            data.get("total_amount", 0),
            data.get("subtotal", 0),
            data.get("tax_amount", 0),
            data.get("tax_rate", 0),
            len(data.get("line_items", [])),
            data.get("extraction_confidence", 0),
            data.get("ocr_confidence", 0)
        ]
        
        return features
    
    def _similar_strings(self, str1: str, str2: str, threshold: float = 0.8) -> bool:
        """
        Check if two strings are similar using simple similarity
        
        Args:
            str1: First string
            str2: Second string
            threshold: Similarity threshold (0-1)
            
        Returns:
            True if strings are similar
        """
        if not str1 or not str2:
            return False
        
        # Simple case-insensitive comparison
        str1_clean = str1.lower().strip()
        str2_clean = str2.lower().strip()
        
        # Exact match
        if str1_clean == str2_clean:
            return True
        
        # Check if one contains the other
        if str1_clean in str2_clean or str2_clean in str1_clean:
            return True
        
        # Simple character overlap ratio
        set1 = set(str1_clean)
        set2 = set(str2_clean)
        
        overlap = len(set1.intersection(set2))
        total = len(set1.union(set2))
        
        similarity = overlap / total if total > 0 else 0
        
        return similarity >= threshold