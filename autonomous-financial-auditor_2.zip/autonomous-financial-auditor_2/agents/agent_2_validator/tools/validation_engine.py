"""
Validation Engine for financial document data
Handles schema validation, business rules, and arithmetic checks
"""
from typing import Dict, Any, List, Optional
from datetime import datetime
import re
import logging

from models.validation_schemas import (
    ValidationIssue,
    ValidationSeverity,
    ValidationCategory,
    ArithmeticCheck
)

logger = logging.getLogger(__name__)


class ValidationEngine:
    """Engine for validating extracted financial data"""
    
    # Required fields by document type
    REQUIRED_FIELDS = {
        "invoice": ["vendor", "invoice_number", "document_date", "total_amount"],
        "receipt": ["vendor", "document_date", "total_amount"],
        "bank_statement": ["account_number", "document_date"],
        "financial_report": ["document_date"],
        "unknown": ["document_date"]  # Minimal requirements
    }
    
    def __init__(self, tolerance: float = 0.01):
        """
        Initialize validation engine
        
        Args:
            tolerance: Tolerance for arithmetic comparisons (default $0.01)
        """
        self.tolerance = tolerance
        self.issues: List[ValidationIssue] = []
    
    def validate_all(self, extracted_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run all validation checks
        
        Args:
            extracted_data: Data from Agent 1
            
        Returns:
            Dict with issues and arithmetic_checks
        """
        self.issues = []  # Reset
        
        # Run all validation checks
        schema_issues = self.validate_schema(extracted_data)
        business_issues = self.validate_business_rules(extracted_data)
        format_issues = self.validate_formats(extracted_data)
        arithmetic_checks = self.validate_arithmetic(extracted_data)
        
        # Combine all issues
        all_issues = schema_issues + business_issues + format_issues
        
        return {
            "issues": all_issues,
            "arithmetic_checks": arithmetic_checks
        }
    
    def validate_schema(self, data: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate required fields are present and non-empty"""
        issues = []
        doc_type = data.get("document_type", "unknown")
        
        required_fields = self.REQUIRED_FIELDS.get(doc_type, self.REQUIRED_FIELDS["unknown"])
        
        for field in required_fields:
            value = data.get(field)
            
            # Check if field is missing or empty
            if value is None or value == "" or (isinstance(value, str) and value.strip() == ""):
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.CRITICAL,
                    category=ValidationCategory.MISSING_DATA,
                    field=field,
                    message=f"Required field '{field}' is missing or empty",
                    expected="Non-empty value",
                    actual=value
                ))
        
        return issues
    
    def validate_business_rules(self, data: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate business logic and rules"""
        issues = []
        
        # Rule 1: Due date must be after document date
        doc_date = data.get("document_date")
        due_date = data.get("due_date")
        
        if doc_date and due_date:
            try:
                doc_dt = self._parse_date(doc_date)
                due_dt = self._parse_date(due_date)
                
                if due_dt and doc_dt and due_dt < doc_dt:
                    issues.append(ValidationIssue(
                        severity=ValidationSeverity.CRITICAL,
                        category=ValidationCategory.LOGIC,
                        field="due_date",
                        message="Due date is before document date",
                        expected=f"Date after {doc_date}",
                        actual=due_date
                    ))
            except:
                pass  # Date parsing handled in format validation
        
        # Rule 2: Amounts should be positive
        amount_fields = ["total_amount", "subtotal", "tax_amount", "amount_paid"]
        for field in amount_fields:
            amount = data.get(field)
            if amount is not None and amount < 0:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    category=ValidationCategory.BUSINESS_RULE,
                    field=field,
                    message=f"{field} is negative",
                    expected="Positive number",
                    actual=amount
                ))
        
        # Rule 3: Tax rate should be reasonable (0-100%)
        tax_rate = data.get("tax_rate")
        if tax_rate is not None:
            if tax_rate < 0 or tax_rate > 100:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    category=ValidationCategory.BUSINESS_RULE,
                    field="tax_rate",
                    message="Tax rate is outside reasonable range",
                    expected="0-100%",
                    actual=f"{tax_rate}%"
                ))
        
        # Rule 4: Check for suspicious patterns (OCR errors)
        suspicious_patterns = ["erred", "error", "???", "###", "N/A", "null"]
        for field, value in data.items():
            if isinstance(value, str):
                for pattern in suspicious_patterns:
                    if pattern.lower() in value.lower():
                        issues.append(ValidationIssue(
                            severity=ValidationSeverity.CRITICAL,
                            category=ValidationCategory.FORMAT,
                            field=field,
                            message=f"Field contains suspicious text: '{pattern}'",
                            actual=value,
                            suggestion="Manual review required - likely OCR error"
                        ))
                        break
        
        # Rule 5: Document type should not be unknown if we have enough data
        if data.get("document_type") == "unknown":
            # Check if we have invoice indicators
            has_invoice_indicators = (
                data.get("invoice_number") or 
                data.get("line_items") or
                "invoice" in str(data.get("raw_text", "")).lower()
            )
            
            if has_invoice_indicators:
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    category=ValidationCategory.CLASSIFICATION,
                    field="document_type",
                    message="Document type is 'unknown' but appears to be an invoice",
                    suggestion="invoice"
                ))
        
        return issues
    
    def validate_formats(self, data: Dict[str, Any]) -> List[ValidationIssue]:
        """Validate data formats (email, phone, dates, etc)"""
        issues = []
        
        # Validate email format
        email = data.get("vendor_email")
        if email and not self._is_valid_email(email):
            issues.append(ValidationIssue(
                severity=ValidationSeverity.WARNING,
                category=ValidationCategory.FORMAT,
                field="vendor_email",
                message="Invalid email format",
                actual=email
            ))
        
        # Validate phone format
        phone = data.get("vendor_phone")
        if phone and not self._is_valid_phone(phone):
            issues.append(ValidationIssue(
                severity=ValidationSeverity.INFO,
                category=ValidationCategory.FORMAT,
                field="vendor_phone",
                message="Phone number format may be invalid",
                actual=phone
            ))
        
        # Validate date formats
        date_fields = ["document_date", "due_date"]
        for field in date_fields:
            date_value = data.get(field)
            if date_value and not self._is_valid_date(date_value):
                issues.append(ValidationIssue(
                    severity=ValidationSeverity.WARNING,
                    category=ValidationCategory.FORMAT,
                    field=field,
                    message="Invalid date format",
                    expected="YYYY-MM-DD or valid date string",
                    actual=date_value
                ))
        
        return issues
    
    def validate_arithmetic(self, data: Dict[str, Any]) -> Dict[str, ArithmeticCheck]:
        """Validate arithmetic consistency"""
        checks = {}
        
        # Check 1: Subtotal + Tax = Total
        subtotal = data.get("subtotal")
        tax = data.get("tax_amount")
        total = data.get("total_amount")
        
        if subtotal is not None and tax is not None and total is not None:
            expected_total = subtotal + tax
            difference = abs(total - expected_total)
            passed = difference <= self.tolerance
            
            checks["subtotal_plus_tax_equals_total"] = ArithmeticCheck(
                check_name="Subtotal + Tax = Total",
                passed=passed,
                expected=expected_total,
                actual=total,
                difference=difference,
                message=None if passed else f"Total should be {expected_total} but is {total}"
            )
        
        # Check 2: Line items sum to subtotal
        line_items = data.get("line_items", [])
        if line_items and subtotal is not None:
            line_items_sum = sum(item.get("total", 0) for item in line_items)
            difference = abs(subtotal - line_items_sum)
            passed = difference <= self.tolerance
            
            checks["line_items_sum_equals_subtotal"] = ArithmeticCheck(
                check_name="Line items sum = Subtotal",
                passed=passed,
                expected=line_items_sum,
                actual=subtotal,
                difference=difference,
                message=None if passed else f"Line items sum to {line_items_sum} but subtotal is {subtotal}"
            )
        
        # Check 3: Amount paid + Balance due = Total
        amount_paid = data.get("amount_paid")
        balance_due = data.get("balance_due")
        
        if amount_paid is not None and balance_due is not None and total is not None:
            expected_total = amount_paid + balance_due
            difference = abs(total - expected_total)
            passed = difference <= self.tolerance
            
            checks["paid_plus_balance_equals_total"] = ArithmeticCheck(
                check_name="Amount Paid + Balance = Total",
                passed=passed,
                expected=expected_total,
                actual=total,
                difference=difference,
                message=None if passed else f"Paid + Balance should equal {expected_total} but total is {total}"
            )
        
        return checks
    
    # Helper methods
    
    def _is_valid_email(self, email: str) -> bool:
        """Check if email format is valid"""
        pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
        return bool(re.match(pattern, email))
    
    def _is_valid_phone(self, phone: str) -> bool:
        """Check if phone format is valid"""
        # Remove common formatting characters
        cleaned = re.sub(r'[\s\-\(\)\.]', '', phone)
        # Check if it's 10-15 digits
        return bool(re.match(r'^\+?\d{10,15}$', cleaned))
    
    def _is_valid_date(self, date_str: str) -> bool:
        """Check if date string is valid"""
        if not date_str:
            return False
        
        # Try parsing with common formats
        formats = [
            "%Y-%m-%d",
            "%m/%d/%Y",
            "%d/%m/%Y",
            "%Y/%m/%d",
            "%B %d, %Y",
            "%d %B %Y"
        ]
        
        for fmt in formats:
            try:
                datetime.strptime(str(date_str), fmt)
                return True
            except:
                continue
        
        return False
    
    def _parse_date(self, date_str: str) -> Optional[datetime]:
        """Parse date string to datetime object"""
        formats = [
            "%Y-%m-%d",
            "%m/%d/%Y",
            "%d/%m/%Y",
            "%Y/%m/%d"
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(str(date_str), fmt)
            except:
                continue
        
        return None