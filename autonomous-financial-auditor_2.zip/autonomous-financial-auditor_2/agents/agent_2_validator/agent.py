"""
Agent 2: Financial Document Validator
Orchestrates validation engine, anomaly detection, and LLM validation
"""
import os
import sys
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
import json

# Add parent directories to path
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from agents.agent_2_validator.tools.validation_engine import ValidationEngine
from agents.agent_2_validator.anomaly_detector import AnomalyDetector
from agents.agent_2_validator.prompts.validation_prompts import (
    VALIDATION_SYSTEM_PROMPT,
    format_contextual_validation_prompt,
    format_vendor_validation_prompt,
    format_amount_reasonableness_prompt
)
from backend.app.utils.gemini_client import GeminiClient
from models.validation_schemas import (
    ValidationReport,
    ValidationStatus,
    ValidationIssue,
    ValidationSeverity,
    ValidationCategory,
    AnomalyResult,
    AnomalyType
)

logger = logging.getLogger(__name__)


class Agent2Validator:
    """
    Agent 2: Validation & Anomaly Detection
    
    Pipeline:
    1. Schema & business rules validation
    2. Arithmetic validation
    3. Anomaly detection (ML-based)
    4. LLM contextual validation
    5. Generate comprehensive validation report
    """
    
    def __init__(self,
                 validation_engine: ValidationEngine,
                 anomaly_detector: AnomalyDetector,
                 gemini_client: Optional[GeminiClient] = None,
                 use_llm: bool = True):
        """
        Initialize Agent 2
        
        Args:
            validation_engine: Validation engine for rules
            anomaly_detector: Anomaly detector for ML-based detection
            gemini_client: Gemini client for LLM validation
            use_llm: Whether to use LLM validation (default True)
        """
        self.validation_engine = validation_engine
        self.anomaly_detector = anomaly_detector
        self.gemini_client = gemini_client
        self.use_llm = use_llm and gemini_client is not None
        
        logger.info("Agent 2 (Validator) initialized")
    
    def validate_document(self, 
                         extracted_data: Dict[str, Any],
                         historical_data: Optional[List[Dict]] = None) -> ValidationReport:
        """
        Main validation pipeline
        
        Args:
            extracted_data: Output from Agent 1
            historical_data: Optional historical documents for comparison
            
        Returns:
            Comprehensive validation report
        """
        start_time = datetime.now()
        document_id = extracted_data.get("document_id", "unknown")
        
        logger.info(f"Starting validation for document: {document_id}")
        
        try:
            # Step 1: Schema & Business Rules Validation
            logger.info("Step 1: Schema and business rules validation...")
            validation_result = self.validation_engine.validate_all(extracted_data)
            issues = validation_result["issues"]
            arithmetic_checks = validation_result["arithmetic_checks"]
            
            logger.info(f"Found {len(issues)} validation issues")
            
            # Step 2: Anomaly Detection
            logger.info("Step 2: Anomaly detection...")
            anomalies = self.anomaly_detector.detect_all_anomalies(
                extracted_data,
                historical_data
            )
            
            logger.info(f"Detected {len(anomalies)} anomalies")
            
            # Step 3: LLM Contextual Validation (optional)
            llm_issues = []
            llm_suggestions = {}
            
            if self.use_llm:
                logger.info("Step 3: LLM contextual validation...")
                llm_result = self._llm_contextual_validation(extracted_data)
                llm_issues = llm_result.get("issues", [])
                llm_suggestions = llm_result.get("suggestions", {})
                logger.info(f"LLM found {len(llm_issues)} additional issues")
            else:
                logger.info("Step 3: LLM validation skipped")
            
            # Step 4: Combine all issues
            all_issues = issues + llm_issues
            
            # Step 5: Calculate scores and status
            validation_report = self._build_validation_report(
                document_id=document_id,
                issues=all_issues,
                anomalies=anomalies,
                arithmetic_checks=arithmetic_checks,
                llm_suggestions=llm_suggestions,
                extracted_data=extracted_data
            )
            
            # Calculate processing time
            processing_time = (datetime.now() - start_time).total_seconds()
            validation_report.processing_time = processing_time
            
            logger.info(f"Validation completed in {processing_time:.2f}s. Status: {validation_report.validation_status}")
            
            # Step 6: Save validation report
            self._save_validation_report(validation_report)
            
            return validation_report
            
        except Exception as e:
            logger.error(f"Error during validation: {e}", exc_info=True)
            
            # Return error report
            return ValidationReport(
                document_id=document_id,
                validation_status=ValidationStatus.ERROR,
                overall_score=0.0,
                confidence_score=0.0,
                recommendation=f"Validation failed with error: {str(e)}",
                requires_manual_review=True,
                risk_level="critical"
            )
    
    def _llm_contextual_validation(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Use Gemini LLM for contextual validation
        
        Args:
            data: Extracted data
            
        Returns:
            Dict with issues and suggestions
        """
        llm_issues = []
        suggestions = {}
        
        try:
            # Contextual validation
            prompt = format_contextual_validation_prompt(data)
            result = self.gemini_client.generate_json(
                prompt=prompt,
                system_instruction=VALIDATION_SYSTEM_PROMPT
            )
            
            if result:
                # Parse LLM response
                for issue in result.get("issues", []):
                    llm_issues.append(ValidationIssue(
                        severity=ValidationSeverity(issue.get("severity", "info")),
                        category=ValidationCategory.LOGIC,
                        field=issue.get("field", "general"),
                        message=issue.get("issue", "LLM detected issue"),
                        suggestion=issue.get("suggestion")
                    ))
                
                # Store document type suggestion
                if result.get("document_type_suggestion"):
                    suggestions["document_type"] = result["document_type_suggestion"]
                
                # Store overall assessment
                if result.get("overall_assessment"):
                    suggestions["llm_assessment"] = result["overall_assessment"]
        
        except Exception as e:
            logger.error(f"LLM contextual validation failed: {e}")
        
        return {
            "issues": llm_issues,
            "suggestions": suggestions
        }
    
    def _build_validation_report(self,
                                 document_id: str,
                                 issues: List[ValidationIssue],
                                 anomalies: List[AnomalyResult],
                                 arithmetic_checks: Dict,
                                 llm_suggestions: Dict,
                                 extracted_data: Dict[str, Any]) -> ValidationReport:
        """
        Build comprehensive validation report
        
        Args:
            document_id: Document ID
            issues: All validation issues
            anomalies: All detected anomalies
            arithmetic_checks: Arithmetic check results
            llm_suggestions: Suggestions from LLM
            extracted_data: Original extracted data
            
        Returns:
            Complete validation report
        """
        # Count issues by severity
        critical_count = sum(1 for i in issues if i.severity == ValidationSeverity.CRITICAL)
        warning_count = sum(1 for i in issues if i.severity == ValidationSeverity.WARNING)
        info_count = sum(1 for i in issues if i.severity == ValidationSeverity.INFO)
        
        # Count anomalies by severity
        critical_anomalies = sum(1 for a in anomalies if a.severity == ValidationSeverity.CRITICAL)
        warning_anomalies = sum(1 for a in anomalies if a.severity == ValidationSeverity.WARNING)
        
        # Calculate checks
        total_checks = len(issues) + len(arithmetic_checks)
        failed_checks = critical_count + sum(1 for c in arithmetic_checks.values() if not c.passed)
        passed_checks = total_checks - failed_checks - warning_count
        
        # Determine validation status
        if critical_count > 0 or critical_anomalies > 0:
            validation_status = ValidationStatus.FAILED
        elif warning_count > 0 or warning_anomalies > 0:
            validation_status = ValidationStatus.WARNING
        else:
            validation_status = ValidationStatus.PASSED
        
        # Calculate overall score (0-1)
        # Base score from extraction confidence
        base_score = extracted_data.get("extraction_confidence", 0.5)
        
        # Penalties
        penalty = 0.0
        penalty += critical_count * 0.2  # -20% per critical issue
        penalty += critical_anomalies * 0.15  # -15% per critical anomaly
        penalty += warning_count * 0.05  # -5% per warning
        penalty += warning_anomalies * 0.05  # -5% per warning anomaly
        
        overall_score = max(0.0, min(1.0, base_score - penalty))
        
        # Calculate confidence score
        confidence_score = extracted_data.get("extraction_confidence", 0.5) * 0.7 + \
                          extracted_data.get("ocr_confidence", 0.5) * 0.3
        
        # Determine risk level
        if critical_count > 0 or critical_anomalies > 0:
            risk_level = "critical"
        elif overall_score < 0.5:
            risk_level = "high"
        elif overall_score < 0.7:
            risk_level = "medium"
        else:
            risk_level = "low"
        
        # Generate recommendation
        recommendation = self._generate_recommendation(
            validation_status,
            critical_count,
            warning_count,
            anomalies,
            overall_score
        )
        
        # Determine if manual review needed
        requires_manual_review = (
            critical_count > 0 or
            critical_anomalies > 0 or
            overall_score < 0.7 or
            extracted_data.get("extraction_confidence", 0) < 0.5
        )
        
        # Extract fraud indicators
        fraud_indicators = [
            a.reason for a in anomalies 
            if a.type == AnomalyType.FRAUD_PATTERN
        ]
        
        # Generate summary
        summary = self._generate_summary(
            validation_status,
            len(issues),
            len(anomalies),
            overall_score,
            llm_suggestions
        )
        
        # Build report
        report = ValidationReport(
            document_id=document_id,
            validation_status=validation_status,
            overall_score=round(overall_score, 3),
            confidence_score=round(confidence_score, 3),
            checks_performed=total_checks,
            checks_passed=passed_checks,
            checks_failed=failed_checks,
            checks_warning=warning_count,
            issues=issues,
            anomalies=anomalies,
            fraud_indicators=fraud_indicators,
            arithmetic_checks=arithmetic_checks,
            recommendation=recommendation,
            requires_manual_review=requires_manual_review,
            risk_level=risk_level,
            summary=summary
        )
        
        return report
    
    def _generate_recommendation(self,
                                status: ValidationStatus,
                                critical_count: int,
                                warning_count: int,
                                anomalies: List[AnomalyResult],
                                overall_score: float) -> str:
        """Generate actionable recommendation"""
        
        if status == ValidationStatus.FAILED:
            return f"REJECT - Document has {critical_count} critical issues and cannot be processed automatically. Manual review required."
        
        elif status == ValidationStatus.WARNING:
            if warning_count > 3:
                return f"REVIEW - Document has {warning_count} warnings. Recommend manual review before approval."
            else:
                return f"ACCEPT WITH CAUTION - {warning_count} minor issues found. Review flagged fields."
        
        else:
            if overall_score > 0.9:
                return "APPROVE - All validations passed. Document looks good."
            else:
                return "APPROVE - Validations passed but verify extraction confidence."
    
    def _generate_summary(self,
                         status: ValidationStatus,
                         issue_count: int,
                         anomaly_count: int,
                         overall_score: float,
                         llm_suggestions: Dict) -> str:
        """Generate human-readable summary"""
        
        summary_parts = []
        
        # Status
        summary_parts.append(f"Validation Status: {status.value.upper()}")
        summary_parts.append(f"Overall Score: {overall_score:.1%}")
        
        # Issues
        if issue_count > 0:
            summary_parts.append(f"Found {issue_count} validation issue(s)")
        
        # Anomalies
        if anomaly_count > 0:
            summary_parts.append(f"Detected {anomaly_count} anomaly/anomalies")
        
        # LLM assessment
        if llm_suggestions.get("llm_assessment"):
            summary_parts.append(f"AI Assessment: {llm_suggestions['llm_assessment']}")
        
        return ". ".join(summary_parts)
    
    def _save_validation_report(self, report: ValidationReport) -> None:
        """Save validation report to JSON file"""
        try:
            output_dir = "data/processed"
            os.makedirs(output_dir, exist_ok=True)
            
            output_path = os.path.join(output_dir, f"{report.document_id}_validation.json")
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(report.model_dump(), f, indent=2, default=str)
            
            logger.info(f"Saved validation report to: {output_path}")
            
        except Exception as e:
            logger.error(f"Failed to save validation report: {e}")