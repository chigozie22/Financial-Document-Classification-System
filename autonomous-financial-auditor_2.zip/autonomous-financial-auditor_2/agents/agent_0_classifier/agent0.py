"""
Financial Document Classifier using LangGraph
A production-ready agent for classifying financial documents with human-in-the-loop review.
"""

from typing import TypedDict, Literal, Optional, List, Annotated
from langgraph.graph import StateGraph, END
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_google_genai import ChatGoogleGenerativeAI
import json
import base64
from datetime import datetime
from enum import Enum


# ============================================================================
# ENUMS & CONSTANTS
# ============================================================================

# Import DocumentType from shared schemas for consistency
try:
    from models.schemas import DocumentType
except ImportError:
    # Fallback enum if import fails
    class DocumentType(str, Enum):
        INVOICE = "invoice"
        RECEIPT = "receipt"
        BANK_STATEMENT = "bank_statement"
        FINANCIAL_REPORT = "financial_report"
        PURCHASE_ORDER = "purchase_order"
        CREDIT_NOTE = "credit_note"
        UNKNOWN = "unknown"


class ConfidenceLevel(str, Enum):
    HIGH = "high"  # >= 0.85
    MEDIUM = "medium"  # 0.70 - 0.85
    LOW = "low"  # < 0.70


# Confidence thresholds
HIGH_CONFIDENCE_THRESHOLD = 0.85
MEDIUM_CONFIDENCE_THRESHOLD = 0.70


# ============================================================================
# PROMPTS
# ============================================================================

CLASSIFIER_SYSTEM_PROMPT = """You are a Senior Financial Document Analyst with expertise in auditing and forensic accounting.

TASK: Analyze the provided document and classify it into exactly ONE category.

ANALYSIS FRAMEWORK:
1. Document Structure Analysis
   - Layout patterns (tabular vs. linear)
   - Header/footer content
   - Section organization
   
2. Content Verification
   - Key terminology and field labels
   - Numerical patterns (currencies, dates, account numbers)
   - Legal/regulatory markers

3. Contextual Signals
   - Issuer/recipient information
   - Time period indicators
   - Transaction flow direction

ALLOWED CATEGORIES (Choose exactly ONE - must be one of):
invoice, receipt, bank_statement, financial_report, purchase_order, credit_note, unknown

CATEGORY DEFINITIONS:

• invoice: Itemized billing with due dates, vendor details, line items with quantities/prices
  Key markers: "Invoice #", "Due Date", "Bill To", itemized charges, payment terms
  
• receipt: Proof of completed payment, typically post-transaction
  Key markers: "Receipt #", "Paid", "Thank you", payment method details, timestamp
  
• bank_statement: Financial institution's record of account activity
  Key markers: Bank logo, account number, beginning/ending balance, deposits/withdrawals
  
• financial_report: Balance sheet, income statement, or cash flow statement
  Key markers: "Assets", "Liabilities", "Revenue", "Expenses", "Net Income", "Cash Flow"
  
• purchase_order: Pre-approval for vendor purchase
  Key markers: "PO #", "Ship To", "Requested Delivery Date", NOT yet paid
  
• credit_note: Adjustment for returns/refunds
  Key markers: "Credit Note", "Credit Memo", negative amounts, reference to original invoice
  
• unknown: Document type cannot be reliably determined

CRITICAL DISAMBIGUATION RULES:
- Receipt vs Invoice: Receipt shows payment COMPLETED; Invoice requests payment
- Purchase Order vs Invoice: PO is buyer's REQUEST; Invoice is seller's BILL
- Bank Statement vs Statement of Account: Bank statements are from FINANCIAL INSTITUTIONS only
- Credit Note vs Negative Invoice: Credit Note REFERENCES original document number

OUTPUT FORMAT (JSON only, no other text):
{
  "document_type": "string (must be one of: invoice, receipt, bank_statement, financial_report, purchase_order, credit_note, unknown)",
  "confidence_score": 0.95,
  "detected_keys": ["Invoice Number", "Due Date", "Total Amount"],
  "reasoning": "One clear sentence explaining the PRIMARY reason for classification",
  "alternative_types": ["other types considered if confidence < 0.95"],
  "extracted_metadata": {
    "document_number": "extracted number if present",
    "date": "extracted date if present",
    "total_amount": "extracted amount if present",
    "currency": "extracted currency if present"
  }
}

IMPORTANT: Return ONLY the JSON object. No markdown, no explanations, no preamble."""


VERIFICATION_PROMPT = """You are performing a VERIFICATION check on a document classification.

ORIGINAL CLASSIFICATION:
{original_classification}

Your task is to VERIFY or CHALLENGE this classification by:
1. Looking for CONTRADICTORY evidence
2. Checking for MISSED key indicators
3. Validating the reasoning logic

Return your analysis in JSON format:
{
  "verification_result": "CONFIRMED" or "CHALLENGED",
  "confidence_adjustment": 0.0 to 1.0,
  "issues_found": ["list any problems with original classification"],
  "recommended_type": "string (if you disagree with original)",
  "verification_reasoning": "your analysis"
}

Be critical and thorough. Only return CONFIRMED if you're certain the classification is correct."""


# ============================================================================
# STATE DEFINITION
# ============================================================================

class DocumentState(TypedDict):
    """State for the document classification workflow"""
    # Input
    document_content: str  # Base64 encoded image or text
    document_type_input: Literal["image", "text"]
    
    # Classification results
    classification_result: Optional[dict]
    verification_result: Optional[dict]
    
    # Workflow control
    confidence_level: Optional[ConfidenceLevel]
    requires_human_review: bool
    human_review_completed: bool
    human_override: Optional[dict]
    
    # Metadata
    processing_steps: List[str]
    error_message: Optional[str]
    timestamp: str


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def determine_confidence_level(score: float) -> ConfidenceLevel:
    """Determine confidence level from score"""
    if score >= HIGH_CONFIDENCE_THRESHOLD:
        return ConfidenceLevel.HIGH
    elif score >= MEDIUM_CONFIDENCE_THRESHOLD:
        return ConfidenceLevel.MEDIUM
    return ConfidenceLevel.LOW


def parse_llm_response(response: str) -> dict:
    """Safely parse LLM JSON response"""
    try:
        # Remove markdown code blocks if present
        if "```json" in response:
            response = response.split("```json")[1].split("```")[0]
        elif "```" in response:
            response = response.split("```")[1].split("```")[0]
        
        response = response.strip()
        return json.loads(response)
    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse LLM response as JSON: {e}\nResponse: {response}")


def validate_classification_result(result: dict) -> bool:
    """Validate that classification result has required fields"""
    required_fields = ["document_type", "confidence_score", "detected_keys", "reasoning"]
    return all(field in result for field in required_fields)


# ============================================================================
# NODE FUNCTIONS
# ============================================================================

def classify_document(state: DocumentState) -> DocumentState:
    """Initial classification of the document"""
    print("🔍 Classifying document...")
    
    try:
        # Initialize Gemini LLM
        llm = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash-exp",  # or "gemini-1.5-pro", "gemini-1.5-flash"
            temperature=0.1,  # Low temperature for consistent classification
            convert_system_message_to_human=True  # Gemini doesn't support system messages natively
        )
        
        # Prepare messages based on input type
        if state["document_type_input"] == "image":
            # For image input with Gemini
            messages = [
                HumanMessage(
                    content=[
                        {
                            "type": "text",
                            "text": CLASSIFIER_SYSTEM_PROMPT + "\n\nClassify this financial document according to the instructions above."
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{state['document_content']}"
                            }
                        }
                    ]
                )
            ]
        else:
            # For text input
            messages = [
                HumanMessage(
                    content=f"{CLASSIFIER_SYSTEM_PROMPT}\n\nClassify this financial document:\n\n{state['document_content']}"
                )
            ]
        
        # Get classification
        response = llm.invoke(messages)
        result = parse_llm_response(response.content)
        
        # Validate result
        if not validate_classification_result(result):
            raise ValueError("Classification result missing required fields")
        
        # Update state
        state["classification_result"] = result
        state["confidence_level"] = determine_confidence_level(result["confidence_score"])
        state["processing_steps"].append(f"Initial classification: {result['document_type']} (confidence: {result['confidence_score']:.2f})")
        
        print(f"✅ Classified as: {result['document_type']} (confidence: {result['confidence_score']:.2f})")
        
    except Exception as e:
        state["error_message"] = f"Classification error: {str(e)}"
        state["processing_steps"].append(f"Error during classification: {str(e)}")
        print(f"❌ Classification failed: {str(e)}")
    
    return state


def verify_classification(state: DocumentState) -> DocumentState:
    """Verify classification for medium confidence cases"""
    print("🔎 Verifying classification...")
    
    try:
        llm = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash-exp",
            temperature=0.2,
            convert_system_message_to_human=True
        )
        
        original_classification = json.dumps(state["classification_result"], indent=2)
        
        # Prepare verification prompt
        verification_prompt = VERIFICATION_PROMPT.format(
            original_classification=original_classification
        )
        
        # Include document content again for verification
        if state["document_type_input"] == "image":
            messages = [
                HumanMessage(
                    content=[
                        {
                            "type": "text",
                            "text": verification_prompt + "\n\nVerify the classification of this document."
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{state['document_content']}"
                            }
                        }
                    ]
                )
            ]
        else:
            messages = [
                HumanMessage(
                    content=f"{verification_prompt}\n\nDocument content:\n\n{state['document_content']}"
                )
            ]
        
        response = llm.invoke(messages)
        verification = parse_llm_response(response.content)
        
        state["verification_result"] = verification
        
        # Adjust confidence if verification suggests changes
        if verification["verification_result"] == "CHALLENGED":
            if verification.get("recommended_type") != state["classification_result"]["document_type"]:
                # Significant disagreement - flag for human review
                state["requires_human_review"] = True
                state["processing_steps"].append("Verification CHALLENGED classification - flagged for human review")
                print("⚠️ Verification challenged classification - requires human review")
            else:
                # Adjust confidence
                adjusted_score = min(
                    state["classification_result"]["confidence_score"],
                    verification["confidence_adjustment"]
                )
                state["classification_result"]["confidence_score"] = adjusted_score
                state["confidence_level"] = determine_confidence_level(adjusted_score)
                state["processing_steps"].append(f"Confidence adjusted to {adjusted_score:.2f} after verification")
                print(f"📊 Confidence adjusted to {adjusted_score:.2f}")
        else:
            state["processing_steps"].append("Verification CONFIRMED classification")
            print("✅ Classification verified")
        
    except Exception as e:
        state["error_message"] = f"Verification error: {str(e)}"
        state["processing_steps"].append(f"Error during verification: {str(e)}")
        print(f"❌ Verification failed: {str(e)}")
    
    return state


def flag_for_human_review(state: DocumentState) -> DocumentState:
    """Flag document for human review"""
    print("👤 Flagging for human review...")
    
    state["requires_human_review"] = True
    state["processing_steps"].append("Flagged for human review due to low confidence")
    
    # In a real system, this would:
    # - Send notification to review queue
    # - Create ticket in task management system
    # - Log to database for tracking
    
    print("📋 Document added to human review queue")
    return state


def process_human_review(state: DocumentState) -> DocumentState:
    """Process human review decision"""
    print("👤 Processing human review...")
    
    # In a real system, this would wait for human input
    # For now, we'll simulate it being reviewed
    
    # This would typically be called by a separate API endpoint
    # when a human reviewer makes a decision
    
    state["human_review_completed"] = True
    state["processing_steps"].append("Awaiting human review")
    
    print("⏳ Waiting for human reviewer decision...")
    return state


def finalize_classification(state: DocumentState) -> DocumentState:
    """Finalize the classification result"""
    print("✅ Finalizing classification...")
    
    # Use human override if provided, otherwise use classification result
    final_result = state.get("human_override") or state["classification_result"]
    
    state["processing_steps"].append(f"Final classification: {final_result['document_type']}")
    
    # In a real system, this would:
    # - Save to database
    # - Trigger downstream workflows
    # - Send notifications
    # - Update audit logs
    
    print(f"🎯 Final classification: {final_result['document_type']}")
    return state


# ============================================================================
# ROUTING LOGIC
# ============================================================================

def should_verify(state: DocumentState) -> Literal["verify", "skip_verification"]:
    """Determine if verification is needed"""
    if state.get("error_message"):
        return "skip_verification"
    
    confidence_level = state.get("confidence_level")
    
    # Verify medium confidence cases
    if confidence_level == ConfidenceLevel.MEDIUM:
        return "verify"
    
    return "skip_verification"


def route_after_classification(state: DocumentState) -> Literal["human_review", "finalize"]:
    """Route based on confidence level after initial classification"""
    if state.get("error_message"):
        return "human_review"
    
    confidence_level = state.get("confidence_level")
    
    # Low confidence -> human review
    if confidence_level == ConfidenceLevel.LOW:
        return "human_review"
    
    # High confidence -> finalize
    if confidence_level == ConfidenceLevel.HIGH:
        return "finalize"
    
    # Medium confidence will go to verification first
    return "finalize"


def route_after_verification(state: DocumentState) -> Literal["human_review", "finalize"]:
    """Route after verification step"""
    if state.get("requires_human_review"):
        return "human_review"
    
    # Check adjusted confidence level
    confidence_level = state.get("confidence_level")
    
    if confidence_level == ConfidenceLevel.LOW:
        return "human_review"
    
    return "finalize"


# ============================================================================
# GRAPH CONSTRUCTION
# ============================================================================

def create_classifier_graph():
    """Create the LangGraph workflow"""
    
    # Initialize graph
    workflow = StateGraph(DocumentState)
    
    # Add nodes
    workflow.add_node("classify", classify_document)
    workflow.add_node("verify", verify_classification)
    workflow.add_node("flag_for_review", flag_for_human_review)
    workflow.add_node("human_review", process_human_review)
    workflow.add_node("finalize", finalize_classification)
    
    # Set entry point
    workflow.set_entry_point("classify")
    
    # Add conditional edges
    workflow.add_conditional_edges(
        "classify",
        should_verify,
        {
            "verify": "verify",
            "skip_verification": END  # Will be routed by route_after_classification
        }
    )
    
    # Route after initial classification (for high/low confidence)
    workflow.add_conditional_edges(
        "classify",
        route_after_classification,
        {
            "human_review": "flag_for_review",
            "finalize": "finalize"
        }
    )
    
    # Route after verification
    workflow.add_conditional_edges(
        "verify",
        route_after_verification,
        {
            "human_review": "flag_for_review",
            "finalize": "finalize"
        }
    )
    
    # Connect human review flow
    workflow.add_edge("flag_for_review", "human_review")
    workflow.add_edge("human_review", END)
    workflow.add_edge("finalize", END)
    
    return workflow.compile()


# ============================================================================
# USAGE EXAMPLE
# ============================================================================

def classify_document_workflow(
    document_content: str,
    document_type: Literal["image", "text"] = "text"
) -> dict:
    """
    Main function to classify a document
    
    Args:
        document_content: Base64 encoded image or raw text
        document_type: "image" or "text"
    
    Returns:
        Final classification result
    """
    
    # Initialize state
    initial_state: DocumentState = {
        "document_content": document_content,
        "document_type_input": document_type,
        "classification_result": None,
        "verification_result": None,
        "confidence_level": None,
        "requires_human_review": False,
        "human_review_completed": False,
        "human_override": None,
        "processing_steps": [],
        "error_message": None,
        "timestamp": datetime.now().isoformat()
    }
    
    # Create and run graph
    graph = create_classifier_graph()
    final_state = graph.invoke(initial_state)
    
    # Return comprehensive result
    return {
        "classification": final_state.get("human_override") or final_state.get("classification_result"),
        "verification": final_state.get("verification_result"),
        "confidence_level": final_state.get("confidence_level"),
        "requires_human_review": final_state.get("requires_human_review"),
        "processing_steps": final_state.get("processing_steps"),
        "error": final_state.get("error_message"),
        "timestamp": final_state.get("timestamp")
    }


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    # Example with text document
    sample_invoice = """
    INVOICE
    
    Invoice Number: INV-2024-001
    Date: January 15, 2024
    Due Date: February 15, 2024
    
    Bill To:
    Acme Corporation
    123 Business St
    New York, NY 10001
    
    Description                 Quantity    Price       Total
    ---------------------------------------------------------
    Consulting Services         40 hrs      $150/hr     $6,000
    Software License            1           $500        $500
    ---------------------------------------------------------
    
    Subtotal:                                           $6,500
    Tax (10%):                                          $650
    Total:                                              $7,150
    
    Payment Terms: Net 30
    """
    
    print("=" * 80)
    print("FINANCIAL DOCUMENT CLASSIFIER - DEMO")
    print("=" * 80)
    
    result = classify_document_workflow(sample_invoice, "text")
    
    print("\n" + "=" * 80)
    print("CLASSIFICATION RESULT")
    print("=" * 80)
    print(json.dumps(result, indent=2))