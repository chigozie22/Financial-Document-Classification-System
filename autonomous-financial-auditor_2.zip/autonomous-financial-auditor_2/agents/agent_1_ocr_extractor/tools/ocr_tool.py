"""
OCR Tool for extracting text from documents using Tesseract OCR.
"""

import pytesseract
import fitz 
from PIL import Image 
import cv2
import numpy as np
from typing import Tuple, Optional 
import os 
import logging 

logger = logging.getLogger(__name__) 

class OCRTool:
    """Tool for OCR extraction from various document formats."""

    def __init__(self, tesseract_cmd: Optional[str] = None, lang: str = 'eng', config: str = '--psm 6'):
        """
        Initialize the OCR tool.

        Args:
            tesseract_cmd (Optional[str]): Path to the Tesseract executable. If None, uses default.
            lang (str): Language(s) for Tesseract OCR.
            config: Tesseract configuration  
        """
        if tesseract_cmd:
            pytesseract.pytesseract.tesseract_cmd = tesseract_cmd

        self.lang = lang
        self.config = config

    def preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """Preprocess the image for better OCR results.

        Args:
          image:  Input image as a numpy array.
        
        Returns:
            Preprocessed image as a numpy array.
        Returns:
        """

        # Convert to grayscale and apply thresholding

        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image

        # Apply binary thresholding to get white text on black background
        _, thresh = cv2.threshold(gray, 0, 255, cv2.threshold + cv2.THRESH_OTSU)

        # denoise 
        denoised = cv2.fastNlMeansDenoising(thresh, None, 10, 7, 21)

        # dilation and erosion to remoive noise
        kernel = np.ones((1, 1), np.uint8)
        processed = cv2.dilate(denoised, kernel, iterations=1)
        processed = cv2.erode(processed, kernel, iterations=1)

        return processed
    
    def extract_text_from_image(self, image_path: str) -> Tuple[str, float]:
        """Extract text from an image file.

        Args:
            image_path (str): Path to the image file.

        Returns: 
            Tuple of (extracted text, confidence score).
        """
        try: 
            # load image 
            img = cv2.imread(image_path)
            if img is None:
                logger.error(f"Failed to load image from {image_path}")

                return "", 0.0
            
            # Preprocess image
            processed_img = self.preprocess_image(img)

            # Extract text with confidence 
            data = pytesseract.image_to_data(
                processed_img, 
                lang=self.lang, 
                config=self.config, 
                output_type=pytesseract.Output.DICT
                )
            
            # Calculate average confidence
            confidences = [float(conf) for conf in data['conf'] if conf != '-1']
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0

            # Extract text 
            text = pytesseract.image_to_string(
                processed_img, 
                lang=self.lang, 
                config=self.config
                )
            
            return text.strip(), avg_confidence / 100.0  # Normalize to [0, 1]
        
        except Exception as e:
            logger.error(f"Error extracting text from image: {e}")
            return "", 0.0
        
    def extract_text_from_pdf(self, pdf_path: str) -> Tuple[str, float]:
      """Extract text from a PDF file.

      Args:
          pdf_path (str): Path to the PDF file.
      
      Returns:
          Tuple of (extracted text, confidence score).
      """
      try: 
          doc = fitz.open(pdf_path)
          all_text = []
          all_confidences = []

          for page_num in range(len(doc)):
              page = doc[page_num]

              # Try to extract embedded text first
              text = page.get_text()

              if text.strip():
                  all_text.append(text)
                  #For embedded text, add high confidence for each "word"
                  # Estimate word count for proper weighting
                  word_count = len(text.split())
                  all_confidences.extend([1.0] * word_count)  # Assume high confidence for embedded text
              
              else: 
                  # If no embedded text, use OCR on page image
                  pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))  # High-res image
                  img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                  
                  # Convert to numpy array 
                  img_array = np.array(img)

                  # Preprocess image 
                  processed = self.preprocess_image(img_array)

                  # Extract text with confidence
                  data = pytesseract.image_to_data(
                      processed, 
                      lang=self.lang, 
                      config=self.config, 
                      output_type=pytesseract.Output.DICT
                      )
                  
                  page_confidences = [float(conf) for conf in data['conf'] if conf != '-1']
                  all_confidences.extend(page_confidences)

                  text = pytesseract.image_to_string(
                      processed, 
                      lang=self.lang, 
                      config=self.config
                      )
                  all_text.append(text)
                 
          doc.close()
          
          combined_text = "\n".join(all_text).strip()
          avg_confidence = sum(all_confidences) / len(all_confidences) if all_confidences else 0.0

          return combined_text, avg_confidence
      
      except Exception as e:
          logger.error(f"Error extracting text from PDF: {e}")
          return "", 0.0
      
    def extract_text(self, file_path: str) -> Tuple[str, float]:
        """Extract text from a document (auto-detect the format).

        Args:
            file_path (str): Path to the document file.

        Returns: 
            Tuple of (extracted text, confidence score).
        """
        if not os.path.exists(file_path):
            logger.error(f"File not found: {file_path}")
            return "", 0.0
        
        ext = os.path.splitext(file_path)[1].lower()

        if ext == '.pdf':
            return self.extract_text_from_pdf(file_path)
        elif ext in ['.png', '.jpg', '.jpeg', '.tiff', '.bmp']:
            return self.extract_text_from_image(file_path)
        else: 
            logger.error(f"Unsupported file format: {ext}")
            return "", 0.0