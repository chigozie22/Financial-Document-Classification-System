"""
Agent 1: OCR & NER Extraction Agent
Responsible for converting raw documents to structured JSON

"""
import os 
import sys
import json 
import logging
from typing import Dict, Any, Optional
from datetime import datetime
import uuid 

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from agents.agent_1_ocr_extractor.processing_tools.ocr_tool import OCRTool
from agents.agent_1_ocr_extractor.processing_tools.ner_tool import NERTool
from agents.agent_1_ocr_extractor.prompts.extraction_prompts import (
    EXTRACTION_SYSTEM_PROMPT,
    format_extraction_prompt
)
from backend.app.utils.gemini_client import GeminiClient
from models.schemas import ExtractedData, DocumentType

logger = logging.getLogger(__name__)


class Agent1OCRExtractor:
    """
    Agent for extracting structured data from OCR text using Gemini model.
    
    Pipeline:
    1. OCR extraction from document 
    2. NER entity extraction
    3. LLM normalization and structuring 
    4. Confidence Scoring 
    5. JSON ouput generation
    
    """

    def __init__(self, 
                 ocr_tool: OCRTool,
                 ner_tool: NERTool,
                 gemini_client: GeminiClient,
                 confidence_threshold: float=0.7):
        
        """
        Initialize Agent 1
        
        Args:
            ocr_tool: OCR extraction tool
            ner_tool: NER extraction tool
            gemini_client: Gemini LLM client
            confidence_threshold: Minimum confidence for extraction
        """

        self.ocr_tool = ocr_tool
        self.ner_tool = ner_tool
        self.gemini_client = gemini_client
        self.confidence_threshold = confidence_threshold

        logger.info("Agent 1 OCR (Extractor) initialized.")

    def extract_from_document(self, 
                              file_path: str,
                              document_id: Optional[str] = None) -> Dict[str, Any]:
        
        """
        Main extraction pipeline for a single document
        
        Args:
            file_path: Path to document file
            document_id: Optional document ID (generated if not provided)
            
        Returns:
            Extracted data as dictionary
        """

        start_time = datetime.now()

        # Generate document ID if not provided
        if not document_id:
            document_id = f"doc_{uuid.uuid4().hex[:12]}"

        file_name = os.path.basename(file_path)
        logger.info(f"Starting extraction for document {document_id} ({file_name})")


        try: 
            # Step 1: OCR Extraction
            logger.info("Step 1: OCR text Extraction")
            raw_text, ocr_confidence = self.ocr_tool.extract_text(file_path)

            if not raw_text or len(raw_text.strip()) == 0:
                logger.warning(f"OCR extraction failed or returned empty text for document {document_id}")
                return self._create_failed_response(document_id, file_name, "OCR extraction failed: no text extracted")
            
            logger.info(f"OCR extraction completed with confidence {ocr_confidence:.2f}, Text length: {len(raw_text)} chars")


            # Step 2: NER Entity Extraction
            logger.info("Step 2: NER Entity Extraction")
            entities = self.ner_tool.extract_all_entities(raw_text)

            logger.info(f"Entities extracted: {entities['document_type']} document.")

            # Step 3: LLM Normalization & Structuring
            logger.info("Step 3: LLM Normalization & Structuring")
            structured_data = self._normalize_with_llm(raw_text, entities)

            if not structured_data:
                logger.warning(f"LLM normalization failed, using fallback method")
                structured_data = self._fallback_extraction(entities)

            # Step 4 Build final extracted data
            logger.info("Step 4: Building final extracted result")
            extracted_data = self._build_extraction_result(
                document_id=document_id,
                file_name=file_name,
                raw_text=raw_text,
                ocr_confidence=ocr_confidence,
                entities=entities,
                structured_data=structured_data

            )


            # Step 5: Calculate processing time
            processing_time = (datetime.now() - start_time).total_seconds()

            logger.info(f"Extraction completed for document {document_id} in {processing_time:.2f}secs. Confidence: {extracted_data['extraction_confidence']:.2f}")

            # Step 6: Save to JSON FILE
            self._save_to_json(extracted_data)

            return {
                "status": "success",
                "document_id": document_id,
                "extracted_data": extracted_data,
                "processing_time": processing_time
            }
        
        except Exception as e:
            logger.error(f"Error extracting from document {document_id}: {e}, exc_info=True")
            return self._create_failed_response(document_id, file_name, str(e))

    def _normalize_with_llm(self, raw_text: str, entities: Dict[str, Any]) -> Dict[str, Any]:
        """
        Use Gemini LLM to normalize and structure extracted entities
        
        Args:
            raw_text: Raw OCR text
            entities: Extracted entities from NER
            
        Returns:
            Structured data dictionary
        """   
        try:
            # format prompt with extracted entities
            prompt = format_extraction_prompt(raw_text, entities)

            # Generate structured JSON with Gemini 
            structured_data = self.gemini_client.generate_json(
                prompt=prompt,
                system_instruction=EXTRACTION_SYSTEM_PROMPT 
            )

            logger.info(f"LLM returned: {structured_data}")
            logger.info(f"LLM document_type: {structured_data.get('document_type', 'MISSING')}")
            
            # ============================================================================
            # 🔧 IMPROVED DOCUMENT TYPE HANDLING
            # ============================================================================
            
            llm_doc_type = structured_data.get('document_type', '').lower().strip()
            ner_doc_type = entities.get('document_type', 'unknown').lower().strip()
            
            logger.info(f"Document type comparison - LLM: '{llm_doc_type}', NER: '{ner_doc_type}'")
            
            # Case 1: LLM didn't return document_type at all
            if not llm_doc_type:
                structured_data['document_type'] = ner_doc_type
                logger.warning(f"LLM didn't return document_type! Using NER: {ner_doc_type}")
            
            # Case 2: LLM returned "unknown" but NER has a specific type
            elif llm_doc_type in ['unknown', 'unknown document type', 'unknown document', '']:
                if ner_doc_type and ner_doc_type not in ['unknown', 'unknown document type', '']:
                    # NER has useful information - use it!
                    structured_data['document_type'] = ner_doc_type
                    logger.info(f"✅ LLM uncertain ('{llm_doc_type}'), using NER classification: {ner_doc_type}")
                else:
                    # Both are uncertain
                    structured_data['document_type'] = 'unknown'
                    logger.warning(f"⚠️ Both LLM and NER are uncertain about document type")
            
            # Case 3: LLM has a specific type - trust it
            else:
                # LLM is confident, but validate against NER if possible
                if ner_doc_type and ner_doc_type != 'unknown':
                    # Check if they're compatible
                    if self._are_doc_types_compatible(llm_doc_type, ner_doc_type):
                        logger.info(f"✅ LLM and NER agree: {llm_doc_type}")
                    else:
                        logger.warning(f"⚠️ LLM ({llm_doc_type}) and NER ({ner_doc_type}) disagree - using LLM")
                else:
                    logger.info(f"✅ Using LLM classification: {llm_doc_type}")
            
            logger.info(f"Final structured_data document_type: {structured_data.get('document_type')}")
            return structured_data
        
        except Exception as e:
            logger.error(f"LLM normalization failed: {e}", exc_info=True)
            return {}

    def _are_doc_types_compatible(self, llm_type: str, ner_type: str) -> bool:
        """
        Check if LLM and NER document types are compatible
        
        Args:
            llm_type: Document type from LLM (normalized lowercase)
            ner_type: Document type from NER (normalized lowercase)
            
        Returns:
            True if types are compatible/related
        """
        # Define compatible type groups
        compatibility_groups = [
            {'invoice', 'invoices'},
            {'receipt', 'receipts'},
            {'bank_statement', 'bank statement', 'statement'},
            {'financial_report', 'financial report', 'balance sheet', 'income statement', 'cash flow statement'},
            {'purchase_order', 'purchase order', 'po'},
            {'credit_note', 'credit note', 'credit memo'},
            {'tax_document', 'tax document', 'tax form', 'tax_form'},
        ]
        
        # Check if both types are in the same compatibility group
        for group in compatibility_groups:
            if llm_type in group and ner_type in group:
                return True
        
        # Exact match
        if llm_type == ner_type:
            return True
        
        return False

    def _fallback_extraction(self, entities: Dict[str, Any]) -> Dict[str, Any]:
        """
        Fallback extraction using only regex/NER results (no LLM)
        
        Args:
            entities: Extracted entities from NER
            
        Returns:
            Basic structured data
        """

        # Get first/most confident values
        vendor = entities['organizations'][0] if entities['organizations'] else None
        invoice_number = entities['invoice_numbers'][0] if entities['invoice_numbers'] else None
        document_date = entities['dates'][0] if entities['dates'] else None

        # Get largest amount as total
        amounts = entities.get('amounts', [])
        total_amount = max([a['value'] for a in amounts], default=None) if amounts else None

        return {
            "vendor": vendor,
            "invoice_number": invoice_number,
            "document_type": entities.get('document_type', 'unknown'),
            "document_date": document_date,
            "total_amount": total_amount,
            "extraction_confidence": 0.5  # lower confidence for fallback
        }
    
    def _build_extraction_result(
            self,
            document_id: str,
            file_name: str,
            raw_text: str,
            ocr_confidence: float,
            entities: Dict[str, Any],
            structured_data: Dict[str, Any]) -> Dict[str, Any]: 
        
        """
        Build final extraction result combining all data
        
        Args:
            document_id: Document ID
            file_name: Original file name
            raw_text: Raw OCR text
            ocr_confidence: OCR confidence score
            entities: NER extracted entities
            structured_data: LLM structured data
            
        Returns:
            Complete extraction result
        """


        # Map the document type - normalize to lowercase for comparison
        doc_type_str = structured_data.get('document_type', entities.get('document_type', 'unknown')).lower().strip()
        
        logger.info(f"Building extraction result - document_type sources:")
        logger.info(f"  structured_data.document_type: {structured_data.get('document_type')}")
        logger.info(f"  entities.document_type: {entities.get('document_type')}")
        logger.info(f"  doc_type_str (normalized): '{doc_type_str}'")
        
        # Comprehensive document type mapping
        doc_type_map = {
            "invoice": DocumentType.INVOICE,
            "invoices": DocumentType.INVOICE,
            "receipt": DocumentType.RECEIPT,
            "receipts": DocumentType.RECEIPT,
            "bank_statement": DocumentType.BANK_STATEMENT,
            "bank statement": DocumentType.BANK_STATEMENT,
            "statement": DocumentType.BANK_STATEMENT,
            "financial_report": DocumentType.FINANCIAL_REPORT,
            "financial report": DocumentType.FINANCIAL_REPORT,
            "purchase_order": DocumentType.PURCHASE_ORDER,
            "purchase order": DocumentType.PURCHASE_ORDER,
            "po": DocumentType.PURCHASE_ORDER,
            "credit_note": DocumentType.CREDIT_NOTE,
            "credit note": DocumentType.CREDIT_NOTE,
            "credit memo": DocumentType.CREDIT_NOTE,
            "unknown": DocumentType.UNKNOWN,
            "unknown document type": DocumentType.UNKNOWN,
            "unknown document": DocumentType.UNKNOWN,
            "": DocumentType.UNKNOWN,
            "tax_document": DocumentType.UNKNOWN,
            "tax document": DocumentType.UNKNOWN,
            "pay_stub": DocumentType.UNKNOWN,
            "pay stub": DocumentType.UNKNOWN,
            "contract": DocumentType.UNKNOWN,
        }
        
        doc_type = doc_type_map.get(doc_type_str, DocumentType.UNKNOWN)
        logger.info(f"  doc_type_map lookup for '{doc_type_str}': {doc_type} (value: {doc_type.value})")

        # Calculate extraction confidence 
        llm_confidence = structured_data.get('extraction_confidence', 0.0)
        extraction_confidence = (ocr_confidence + llm_confidence) / 2.0

        result = {
            "document_id": document_id,
            "document_type": doc_type.value,
            "file_name": file_name,
            
            # Vendor info
            "vendor": structured_data.get('vendor'),
            "vendor_address": structured_data.get('vendor_address'),
            "vendor_phone": structured_data.get('vendor_phone'),
            "vendor_email": structured_data.get('vendor_email'),
            
            # Customer info
            "customer": structured_data.get('customer'),
            
            # Document identifiers
            "invoice_number": structured_data.get('invoice_number'),
            "account_number": structured_data.get('account_number'),
            
            # Dates
            "document_date": structured_data.get('document_date'),
            "due_date": structured_data.get('due_date'),
            
            # Financial amounts
            "subtotal": structured_data.get('subtotal'),
            "tax_amount": structured_data.get('tax_amount'),
            "tax_rate": structured_data.get('tax_rate'),
            "total_amount": structured_data.get('total_amount'),
            "currency": structured_data.get('currency', 'USD'),
            
            # Line items
            "line_items": structured_data.get('line_items', []),
            
            # Payment info
            "payment_method": structured_data.get('payment_method'),
            
            # Confidence scores
            "extraction_confidence": round(extraction_confidence, 3),
            "ocr_confidence": round(ocr_confidence, 3),
            
            # Raw data
            "raw_text": raw_text[:5000],  # Limit size
            
            # Metadata
            "extracted_at": datetime.utcnow().isoformat(),
            "extraction_method": "agent_1_ocr_ner_llm"
        }
        
        return result
    

    def _save_to_json(self, extracted_data: Dict[str, Any]) -> None:
        """
        Save extracted data to JSON file
        
        Args:
            extracted_data: Extracted data to save
        """

        try: 
            output_dir = "data/processed"
            os.makedirs(output_dir, exist_ok=True)

            document_id = extracted_data['document_id']
            output_path = os.path.join(output_dir, f"{document_id}_extracted.json")

            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(extracted_data, f, ensure_ascii=False, indent=2)

            logger.info(f"Saved extraction result to: {output_path}")

        except Exception as e:
            logger.error(f"Failed to save extraction to JSON: {e}")

    def _create_failed_response(self, document_id: str, file_name, error_message: str) -> Dict[str, Any]:
        """
        Create a failed extraction response
        
        Args:
            document_id: Document ID
            file_name: File name
            error_message: Error message
            
        Returns:
            Failed response dictionary
        """

        return {
            "status": "failed",
            "document_id": document_id,
            "file_name": file_name,
            "error_message": error_message,
            "extracted_data": None
        }
