"""
Promts for LLM-based entity extraction and normalization.
"""

EXTRACTION_SYSTEM_PROMPT = """You are a financial document analysis expert. Your task is to extract and normalize structured financial data from OCR text.

CRITICAL: You MUST return a JSON object with ALL required fields, especially:
- "document_type": This field is MANDATORY and must be one of: invoice, receipt, bank_statement, financial_report, purchase_order, credit_note, unknown
- "total_amount": Total value or amount due
- "document_date": Date in YYYY-MM-DD format
- "extraction_confidence": Your confidence (0.0 to 1.0)

You will receive:
1. Raw OCR text from a financial document
2. Preliminary entity extractions (dates, amounts, organizations, etc.)

Your job is to:
1. Validate and correct the extracted entities
2. Identify missing key information
3. Normalize dates to ISO format (YYYY-MM-DD)
4. Clean and structure monetary amounts
5. Identify the primary vendor/customer
6. Extract line items if present
7. Calculate totals if needed
8. CLASSIFY the document type (MUST be one of: invoice, receipt, bank_statement, financial_report, purchase_order, credit_note, unknown)

Be precise and conservative. If you're unsure about a value, mark confidence as low.
Return ONLY valid JSON - no markdown, no explanations. ALWAYS include the document_type field."""


EXTRACTION_USER_PROMPT = """Analyze this financial document and extract structured data.

**Preliminary Detection (use as starting point):**
- Document Type: {doc_type}
- Organizations: {organizations}
- Invoice/Receipt Numbers: {invoice_numbers}
- Dates Found: {dates}
- Amounts Found: {amounts}

**Raw OCR Text:**
{raw_text}

---

**REQUIRED: Extract and return a JSON object with EXACT structure below:**

{{
  "document_type": "IMPORTANT: Must be EXACTLY one of: invoice, receipt, bank_statement, financial_report, purchase_order, credit_note, unknown",
  "vendor": "primary vendor/merchant name",
  "vendor_address": "full address if available",
  "vendor_phone": "phone number",
  "vendor_email": "email address",
  "customer": "customer name if applicable",
  "invoice_number": "invoice/receipt number",
  "document_date": "YYYY-MM-DD",
  "due_date": "YYYY-MM-DD or null",
  "subtotal": "float or null",
  "tax_amount": "float or null",
  "tax_rate": "float or null (e.g., 0.10 for 10%)",
  "total_amount": "float (main total amount)",
  "currency": "USD or other currency code",
  "line_items": [
    {{
      "description": "item description",
      "quantity": "float or null",
      "unit_price": "float or null",
      "total": "float or null"
    }}
  ],
  "payment_method": "cash/card/check/etc",
  "extraction_confidence": "float between 0.0 and 1.0"
}}

**CRITICAL REMINDERS:**
1. ALWAYS include "document_type" - it must be one of the allowed values
2. Return ONLY the JSON object. No markdown, no explanations, no extra text
3. Classify the document based on its characteristics, using the preliminary detection as a hint
4. If unsure, use "unknown" for document_type"""

VALIDATION_PROMPT = """Review this extracted financial data for accuracy and consistency.

**Extracted Data:**
{extracted_json}

**Original OCR Text:**
{raw_text}

Verify:
1. Do amounts add up correctly? (subtotal + tax = total)
2. Are dates in valid format?
3. Is vendor information consistent?
4. Are line items correctly parsed?
5. Is the document type correct?

Return a JSON object:
{{
  "is_valid": true/false,
  "issues": ["list of any problems found"],
  "corrections": {{"field": "corrected_value"}},
  "confidence_score": float between 0.0 and 1.0
}}

Return ONLY the JSON object."""

def format_extraction_prompt(raw_text: str, entities: dict) -> str:
    """Format the extraction prompt with actual data"""
    return EXTRACTION_USER_PROMPT.format(
        raw_text=raw_text[:3000],
        doc_type=entities.get('document_type', 'unknown'),
        organizations=', '.join(entities.get('organizations', [])[:5]),
        dates=', '.join(entities.get('dates', [])[:5]),
        amounts=', '.join([str(a['value']) for a in entities.get('amounts', [])[:10]]),
        invoice_numbers=', '.join(entities.get('invoice_numbers', [])),
        emails=', '.join(entities.get('emails', [])[:3]),
        phones=', '.join(entities.get('phones', [])[:3])
    )


def format_validation_prompt(extracted_json: str, raw_text: str) -> str:
    """Format the validation prompt with actual data"""
    return VALIDATION_PROMPT.format(
        extracted_json=extracted_json,
        raw_text=raw_text[:3000]
    )