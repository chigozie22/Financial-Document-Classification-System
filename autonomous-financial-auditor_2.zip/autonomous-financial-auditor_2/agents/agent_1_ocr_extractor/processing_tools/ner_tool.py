"""
NER Tool for extracting financial entities from text.
""" 
import spacy 
import re 
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging 

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class NERTool:
    """Tool for Named Entity Recognition in Financial documents."""

    def __init__(self, model_name: str = "en_core_web_sm"):
        """
       Initialize the NER tool with a specified spaCy model.


        Args:
            model_name: Name of spacy model to use
            
        """

        try: 
            self.nlp = spacy.load(model_name)
            logger.info(f"Loaded spaCy model: {model_name}")
        except Exception as e:
            logger.error(f"Error loading spaCy model: {e}")
            logger.info("Attempting to download model...")

            import subprocess
            subprocess.run(["python", "-m", "spacy", "download", model_name])
            self.nlp = spacy.load(model_name)

    def extract_dates(self, text: str) -> List[str]:
        """Extract dates from the text using regex and spaCy NER."""
        date_patterns = [
            r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}',  # MM/DD/YYYY or DD-MM-YYYY
            r'\d{4}[/-]\d{1,2}[/-]\d{1,2}',    # YYYY-MM-DD
            r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* \d{1,2},? \d{4}',  # Month DD, YYYY
            r'\d{1,2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* \d{4}'     # DD Month YYYY
        ]

        dates = []

        for pattern in date_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            dates.extend(matches)
        
        return dates
    
    def extract_amounts(self, text: str) -> List[str]:
        """Extract monetary amounts from the text using regex."""
        amount_patterns = [
            r'\$\s*\d{1,3}(?:,\d{3})*(?:\.\d{2})?',  # $1,234.56
            r'USD\s*\d{1,3}(?:,\d{3})*(?:\.\d{2})?', # USD 1,234.56
            r'\d{1,3}(?:,\d{3})*(?:\.\d{2})?\s*(?:USD|dollars?)', # 1,234.56 USD
            r'€\s*\d{1,3}(?:,\d{3})*(?:\.\d{2})?',   # €1,234.56
            r'£\s*\d{1,3}(?:,\d{3})*(?:\.\d{2})?',   # £1,234.56
        ]

        amounts = [] 

        for pattern in amount_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                amount_str = match
                # Extract numeric value
                numeric = re.sub(r'[^\d.]', '', amount_str)
                try: 
                    value = float(numeric)
                    amounts.append(
                        {
                        'raw': amount_str,
                        'value': value,
                        'position': text.find(amount_str)}
                        )
                except ValueError:
                    continue
        return amounts
    
    def extract_invoice_numbers(self, text: str) -> List[str]:
        """Extract invoice numbers from the text using regex."""
        patterns = [
            r'(?:invoice|receipt|ref|reference)[\s#:]*([A-Z0-9-]+)',
            r'(?:inv|rcpt)[\s#:]*([A-Z0-9-]+)',
            r'#([A-Z0-9-]{5,})'
        ]

        numbers = []

        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            numbers.extend(matches)
        
        return list(set(numbers)) # Remove duplicates
    
    def extract_account_numbers(self, text: str) -> List[str]:
        """Extract account numbers from the text using regex."""
        patterns = [
            r'(?:account|acct)[\s#:]*(\d{4,})',
            r'(?:card|credit)[\s#:]*(\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4})'
        ]

        account_numbers = []

        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            account_numbers.extend(matches)
        
        return account_numbers
    
    def extract_emails(self, text: str) -> List[str]:
        """Extract email addresses from the text using regex."""
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, text)
        return emails
    
    def extract_phones(self, text: str) -> List[str]:
        """Extract phone numbers from the text using regex."""
        patterns = [
            r'\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',
            r'\d{3}[-.\s]?\d{3}[-.\s]?\d{4}'
        ]

        phones = []

        for pattern in patterns: 
            matches = re.findall(pattern, text)
            phones.extend(matches)

        return phones
    
    def extract_entities_with_spacy(self, text: str) -> Dict[str, List[str]]:
        """Extract named entities using spaCy NER."""
        doc = self.nlp(text)
        
        entities = {
            'organizations': [],
            'persons': [],
            'locations': [],
            'money': [],
            'dates': []
        }
        
        for ent in doc.ents: 
            if ent.label_ == 'ORG':
                entities['organizations'].append(ent.text)
            elif ent.label_ == 'PERSON':
                entities['persons'].append(ent.text)
            elif ent.label_ in ['GPE', 'LOC']: 
                entities['locations'].append(ent.text)
            elif ent.label_ == 'MONEY':
                entities['money'].append(ent.text)
            elif ent.label_ ==  'DATE':
                entities['dates'].append(ent.text)

        return entities

    def identify_document_type(self, text: str) -> str: 
        """ Identify document based on keywords. Returns standardized document type."""
        text_lower = text.lower()

        # Check most specific patterns first to avoid false positives
        if any(word in text_lower for word in ['tax return', 'irs form', 'tax year', 'form 1040']):
            return 'tax_document'
        elif any(word in text_lower for word in ['pay stub', 'payroll', 'earnings', 'gross pay', 'net pay', 'deductions']):
            return 'pay_stub'
        elif any(word in text_lower for word in ['financial report', 'balance sheet', 'income statement', 'cash flow statement', 'statement of']):
            return 'financial_report'
        elif any(word in text_lower for word in ['contract', 'agreement', 'terms and conditions', 'signature', 'signed']):
            return 'contract'
        elif any(word in text_lower for word in ['purchase order', 'po number', 'purchase requisition']):
            return 'purchase_order'
        elif any(word in text_lower for word in ['credit note', 'credit memo', 'credit request']):
            return 'credit_note'
        elif any(word in text_lower for word in ['invoice', 'bill to', 'due date', 'amount due', 'invoice date', 'inv.']):
            return 'invoice'
        elif any(word in text_lower for word in ['receipt', 'purchase receipt', 'thank you for', 'sale receipt', 'rcpt']):
            return 'receipt'
        elif any(word in text_lower for word in ['bank statement', 'account statement', 'statement period', 'opening balance', 'closing balance']):
            return 'bank_statement'
        else:
            return 'unknown'
        
    def extract_all_entities(self, text: str) -> Dict[str, Any]:
        """
        Docstring for extract_all_entities
        
        Args: 
            text: Input text from OCR

        Returns:
            A dictionary containing all extracted entities.
        """

        # Extract with spaCy
        spacy_entities = self.extract_entities_with_spacy(text)

        # Extract with regex patterns 
        dates = self.extract_dates(text)
        amounts = self.extract_amounts(text)    
        invoice_numbers = self.extract_invoice_numbers(text)
        account_numbers = self.extract_account_numbers(text)
        emails = self.extract_emails(text)
        phones = self.extract_phones(text)
        doc_type = self.identify_document_type(text)

        # Combine all extractions with deduplication
        extracted = {
            'document_type': doc_type, 
            'organizations': list(set(spacy_entities['organizations'])),
            'persons': list(set(spacy_entities['persons'])),
            'locations': list(set(spacy_entities['locations'])),
            'dates': list(set(dates + spacy_entities['dates'])),
            'amounts': amounts,
            'invoice_numbers': invoice_numbers,
            'account_numbers': list(set(account_numbers)),
            'emails': list(set(emails)),
            'phones': list(set(phones)),
            'raw_text': text

        }

        logger.info(f"Extracted entities from document (type: {doc_type})")
        return extracted