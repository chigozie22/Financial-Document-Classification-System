"""
Debug Test for Document Classification Issue
Tests the flow from NER extraction to final classification
"""

import json
from typing import Dict, Any, Optional
from enum import Enum


# ============================================================================
# DOCUMENT TYPE MAPPINGS
# ============================================================================

class NERDocumentType(str, Enum):
    """NER extracted document types"""
    FINANCIAL_REPORT = "financial_report"
    INVOICE = "invoice"
    RECEIPT = "receipt"
    PURCHASE_ORDER = "purchase_order"
    BANK_STATEMENT = "bank_statement"
    TAX_DOCUMENT = "tax_document"
    UNKNOWN = "unknown"


class FinalDocumentType(str, Enum):
    """Final classification types"""
    INVOICE = "Invoice"
    RECEIPT = "Receipt"
    BALANCE_SHEET = "Balance Sheet"
    INCOME_STATEMENT = "Income Statement"
    CASH_FLOW_STATEMENT = "Cash Flow Statement"
    PURCHASE_ORDER = "Purchase Order"
    CREDIT_NOTE = "Credit Note"
    STATEMENT_OF_ACCOUNT = "Statement of Account"
    TAX_FORM = "Tax Form"
    BANK_STATEMENT = "Bank Statement"
    UNKNOWN = "Unknown"


# Mapping from NER types to possible Final types
NER_TO_FINAL_MAPPING = {
    NERDocumentType.FINANCIAL_REPORT: [
        FinalDocumentType.BALANCE_SHEET,
        FinalDocumentType.INCOME_STATEMENT,
        FinalDocumentType.CASH_FLOW_STATEMENT
    ],
    NERDocumentType.INVOICE: [FinalDocumentType.INVOICE],
    NERDocumentType.RECEIPT: [FinalDocumentType.RECEIPT],
    NERDocumentType.PURCHASE_ORDER: [FinalDocumentType.PURCHASE_ORDER],
    NERDocumentType.BANK_STATEMENT: [FinalDocumentType.BANK_STATEMENT],
    NERDocumentType.TAX_DOCUMENT: [FinalDocumentType.TAX_FORM],
    NERDocumentType.UNKNOWN: [FinalDocumentType.UNKNOWN]
}


# ============================================================================
# SIMULATION FUNCTIONS
# ============================================================================

def simulate_ner_extraction(document_text: str) -> Dict[str, Any]:
    """
    Simulates NER extraction from document
    This represents what your NER model returns
    """
    print("🔍 Running NER extraction...")
    
    # Simulate NER identifying document type
    ner_result = {
        "entities": [],
        "document_type": None,
        "confidence": 0.0
    }
    
    # Simple keyword detection (replace with your actual NER)
    text_lower = document_text.lower()
    
    if "balance sheet" in text_lower or "assets" in text_lower and "liabilities" in text_lower:
        ner_result["document_type"] = NERDocumentType.FINANCIAL_REPORT
        ner_result["confidence"] = 0.92
        ner_result["entities"] = ["balance sheet", "assets", "liabilities", "equity"]
        print(f"   ✅ NER identified: {ner_result['document_type']} (confidence: {ner_result['confidence']})")
    
    elif "invoice" in text_lower:
        ner_result["document_type"] = NERDocumentType.INVOICE
        ner_result["confidence"] = 0.88
        ner_result["entities"] = ["invoice", "due date", "total"]
        print(f"   ✅ NER identified: {ner_result['document_type']} (confidence: {ner_result['confidence']})")
    
    else:
        ner_result["document_type"] = NERDocumentType.UNKNOWN
        ner_result["confidence"] = 0.0
        print(f"   ⚠️ NER could not identify document type")
    
    return ner_result


def classify_with_llm(document_text: str, ner_hint: Optional[str] = None) -> Dict[str, Any]:
    """
    Simulates LLM classification
    This represents what Gemini returns
    """
    print("🤖 Running LLM classification...")
    
    # Simulate LLM response
    # In reality, this would call Gemini with the document
    
    text_lower = document_text.lower()
    
    # Check if NER hint helps narrow down
    if ner_hint == NERDocumentType.FINANCIAL_REPORT:
        # LLM should differentiate between Balance Sheet, Income Statement, Cash Flow
        if "balance sheet" in text_lower or "statement of financial position" in text_lower:
            llm_result = {
                "document_type": FinalDocumentType.BALANCE_SHEET,
                "confidence_score": 0.95,
                "detected_keys": ["Assets", "Liabilities", "Equity"],
                "reasoning": "Contains balance sheet structure with assets, liabilities, and equity"
            }
        elif "income statement" in text_lower or "profit and loss" in text_lower:
            llm_result = {
                "document_type": FinalDocumentType.INCOME_STATEMENT,
                "confidence_score": 0.93,
                "detected_keys": ["Revenue", "Expenses", "Net Income"],
                "reasoning": "Contains P&L structure with revenue and expenses"
            }
        else:
            # Fallback - couldn't determine specific type
            llm_result = {
                "document_type": FinalDocumentType.UNKNOWN,
                "confidence_score": 0.45,
                "detected_keys": [],
                "reasoning": "Document appears to be financial report but specific type unclear"
            }
    else:
        # Generic classification without NER hint
        if "balance sheet" in text_lower:
            llm_result = {
                "document_type": FinalDocumentType.BALANCE_SHEET,
                "confidence_score": 0.89,
                "detected_keys": ["Assets", "Liabilities"],
                "reasoning": "Identified as balance sheet from content"
            }
        else:
            llm_result = {
                "document_type": FinalDocumentType.UNKNOWN,
                "confidence_score": 0.30,
                "detected_keys": [],
                "reasoning": "Could not classify document with confidence"
            }
    
    print(f"   ✅ LLM classified: {llm_result['document_type']} (confidence: {llm_result['confidence_score']})")
    return llm_result


def merge_results_wrong_way(ner_result: Dict, llm_result: Dict) -> Dict[str, Any]:
    """
    WRONG WAY: This shows a common mistake
    Ignoring NER result and only using LLM, or using wrong logic
    """
    print("❌ Merging results (WRONG WAY)...")
    
    # MISTAKE 1: Only using LLM result, ignoring NER
    final_result = {
        "document_type": llm_result["document_type"],
        "confidence": llm_result["confidence_score"],
        "method": "llm_only"
    }
    
    # MISTAKE 2: Applying wrong threshold
    if final_result["confidence"] < 0.90:  # Too strict!
        final_result["document_type"] = FinalDocumentType.UNKNOWN
        print(f"   ⚠️ Confidence {final_result['confidence']} below threshold, setting to UNKNOWN")
    
    print(f"   Result: {final_result['document_type']}")
    return final_result


def merge_results_correct_way(ner_result: Dict, llm_result: Dict) -> Dict[str, Any]:
    """
    CORRECT WAY: Intelligently combine NER and LLM results
    """
    print("✅ Merging results (CORRECT WAY)...")
    
    # Step 1: Check if NER found something useful
    ner_type = ner_result.get("document_type")
    ner_confidence = ner_result.get("confidence", 0.0)
    
    llm_type = llm_result.get("document_type")
    llm_confidence = llm_result.get("confidence_score", 0.0)
    
    # Step 2: Validate LLM result against NER hint
    if ner_type and ner_type != NERDocumentType.UNKNOWN:
        possible_types = NER_TO_FINAL_MAPPING.get(ner_type, [])
        
        # Check if LLM result is consistent with NER
        if llm_type in possible_types:
            # Great! Both agree
            final_result = {
                "document_type": llm_type,
                "confidence": min(1.0, llm_confidence * 1.1),  # Boost confidence
                "method": "ner_llm_agreement",
                "ner_hint": ner_type,
                "validation": "passed"
            }
            print(f"   ✅ NER and LLM agree: {llm_type}")
        
        elif llm_type == FinalDocumentType.UNKNOWN:
            # LLM uncertain, but NER has a hint
            # Use NER to guide - pick the most likely option
            if len(possible_types) == 1:
                final_result = {
                    "document_type": possible_types[0],
                    "confidence": ner_confidence * 0.8,  # Reduced confidence
                    "method": "ner_fallback",
                    "ner_hint": ner_type,
                    "validation": "ner_override"
                }
                print(f"   🔄 LLM uncertain, using NER hint: {possible_types[0]}")
            else:
                # Multiple possibilities - need human review
                final_result = {
                    "document_type": FinalDocumentType.UNKNOWN,
                    "confidence": 0.5,
                    "method": "ambiguous",
                    "ner_hint": ner_type,
                    "possible_types": [str(t) for t in possible_types],
                    "validation": "requires_review"
                }
                print(f"   ⚠️ Multiple possibilities, needs human review")
        
        else:
            # LLM disagrees with NER - trust LLM if high confidence
            if llm_confidence > 0.85:
                final_result = {
                    "document_type": llm_type,
                    "confidence": llm_confidence * 0.9,  # Slight penalty
                    "method": "llm_override",
                    "ner_hint": ner_type,
                    "validation": "mismatch_llm_confident"
                }
                print(f"   🔄 LLM confident, overriding NER: {llm_type}")
            else:
                # Low confidence disagreement - flag for review
                final_result = {
                    "document_type": FinalDocumentType.UNKNOWN,
                    "confidence": 0.6,
                    "method": "conflict",
                    "ner_hint": ner_type,
                    "llm_suggestion": llm_type,
                    "validation": "requires_review"
                }
                print(f"   ⚠️ NER/LLM conflict with low confidence, needs review")
    
    else:
        # No NER hint - rely on LLM only
        final_result = {
            "document_type": llm_type,
            "confidence": llm_confidence,
            "method": "llm_only",
            "validation": "no_ner_hint"
        }
        print(f"   📝 No NER hint, using LLM: {llm_type}")
    
    print(f"   Final: {final_result['document_type']} (confidence: {final_result['confidence']:.2f})")
    return final_result


# ============================================================================
# TEST CASES
# ============================================================================

def test_case_1_balance_sheet():
    """Test Case 1: Balance Sheet document"""
    print("\n" + "="*80)
    print("TEST CASE 1: Balance Sheet Document")
    print("="*80)
    
    document = """
    BALANCE SHEET
    As of December 31, 2024
    
    ASSETS
    Current Assets:
        Cash and Cash Equivalents    $50,000
        Accounts Receivable          $30,000
        Inventory                    $20,000
        Total Current Assets         $100,000
    
    LIABILITIES
    Current Liabilities:
        Accounts Payable             $25,000
        Short-term Debt              $15,000
        Total Current Liabilities    $40,000
    
    EQUITY
        Common Stock                 $40,000
        Retained Earnings            $20,000
        Total Equity                 $60,000
    
    Total Liabilities + Equity       $100,000
    """
    
    # Run pipeline
    ner_result = simulate_ner_extraction(document)
    llm_result = classify_with_llm(document, ner_result.get("document_type"))
    
    print("\n--- WRONG WAY ---")
    wrong_result = merge_results_wrong_way(ner_result, llm_result)
    
    print("\n--- CORRECT WAY ---")
    correct_result = merge_results_correct_way(ner_result, llm_result)
    
    print("\n📊 COMPARISON:")
    print(f"   Wrong way result: {wrong_result['document_type']}")
    print(f"   Correct way result: {correct_result['document_type']}")
    
    return {
        "test": "balance_sheet",
        "ner": ner_result,
        "llm": llm_result,
        "wrong": wrong_result,
        "correct": correct_result
    }


def test_case_2_ambiguous_financial_report():
    """Test Case 2: Generic financial report without clear markers"""
    print("\n" + "="*80)
    print("TEST CASE 2: Ambiguous Financial Report")
    print("="*80)
    
    document = """
    FINANCIAL REPORT
    December 2024
    
    Assets: $100,000
    Liabilities: $40,000
    
    Some financial data here but unclear structure...
    """
    
    ner_result = simulate_ner_extraction(document)
    llm_result = classify_with_llm(document, ner_result.get("document_type"))
    
    print("\n--- WRONG WAY ---")
    wrong_result = merge_results_wrong_way(ner_result, llm_result)
    
    print("\n--- CORRECT WAY ---")
    correct_result = merge_results_correct_way(ner_result, llm_result)
    
    print("\n📊 COMPARISON:")
    print(f"   Wrong way result: {wrong_result['document_type']}")
    print(f"   Correct way result: {correct_result['document_type']}")
    print(f"   Correct way validation: {correct_result.get('validation')}")
    
    return {
        "test": "ambiguous",
        "ner": ner_result,
        "llm": llm_result,
        "wrong": wrong_result,
        "correct": correct_result
    }


def test_case_3_pdf_scenario():
    """Test Case 3: YOUR EXACT PDF SCENARIO
    NER correctly identifies 'financial_report' but final result is 'unknown'
    """
    print("\n" + "="*80)
    print("TEST CASE 3: YOUR PDF SCENARIO (NER works, Final = Unknown)")
    print("="*80)
    
    # Simulate a PDF where text extraction is poor
    # This is likely what's happening with your downloaded PDF
    document = """
    Balance Sheet
    
    Assets  Liabilities
    $100k   $40k
    
    [Some poorly extracted text from PDF]
    """
    
    # NER correctly identifies it
    print("🔍 Running NER extraction...")
    ner_result = {
        "document_type": NERDocumentType.FINANCIAL_REPORT,
        "confidence": 0.88,
        "entities": ["balance sheet", "assets", "liabilities"]
    }
    print(f"   ✅ NER identified: {ner_result['document_type']} (confidence: {ner_result['confidence']})")
    
    # BUT LLM fails due to poor text quality
    print("🤖 Running LLM classification...")
    llm_result = {
        "document_type": FinalDocumentType.UNKNOWN,
        "confidence_score": 0.35,  # Low confidence due to poor text
        "detected_keys": ["Assets"],
        "reasoning": "Poor text quality, cannot determine specific financial statement type"
    }
    print(f"   ⚠️ LLM classified: {llm_result['document_type']} (confidence: {llm_result['confidence_score']})")
    print(f"      Reason: {llm_result['reasoning']}")
    
    print("\n--- WRONG WAY (YOUR CURRENT CODE?) ---")
    wrong_result = merge_results_wrong_way(ner_result, llm_result)
    
    print("\n--- CORRECT WAY (WHAT YOU NEED) ---")
    correct_result = merge_results_correct_way(ner_result, llm_result)
    
    print("\n📊 COMPARISON:")
    print(f"   Wrong way result: {wrong_result['document_type']} ❌")
    print(f"   Correct way result: {correct_result['document_type']} ✅")
    print(f"   Correct way method: {correct_result['method']}")
    
    if correct_result.get('possible_types'):
        print(f"   Possible types suggested: {correct_result['possible_types']}")
    
    print("\n💡 THE ISSUE:")
    print("   Your code is probably ignoring the NER hint when LLM returns Unknown!")
    print("   Even though NER found 'financial_report', you're not using that information.")
    
    return {
        "test": "pdf_scenario",
        "ner": ner_result,
        "llm": llm_result,
        "wrong": wrong_result,
        "correct": correct_result
    }


def run_all_tests():
    """Run all test cases"""
    print("\n" + "="*80)
    print("DOCUMENT CLASSIFICATION DEBUG TESTS")
    print("="*80)
    
    results = []
    results.append(test_case_1_balance_sheet())
    results.append(test_case_2_ambiguous_financial_report())
    results.append(test_case_3_pdf_scenario())  # YOUR EXACT ISSUE
    
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    
    for result in results:
        print(f"\n{result['test'].upper()}:")
        print(f"  NER: {result['ner']['document_type']} (conf: {result['ner']['confidence']})")
        print(f"  LLM: {result['llm']['document_type']} (conf: {result['llm']['confidence_score']})")
        print(f"  Wrong way: {result['wrong']['document_type']}")
        print(f"  Correct way: {result['correct']['document_type']} (method: {result['correct']['method']})")
        
        if result['wrong']['document_type'] == FinalDocumentType.UNKNOWN and \
           result['correct']['document_type'] != FinalDocumentType.UNKNOWN:
            print(f"  ⚠️ ISSUE REPRODUCED: Wrong way returns Unknown when it shouldn't!")


# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    run_all_tests()
    
    print("\n" + "="*80)
    print("🔧 HOW TO FIX YOUR ACTUAL CODE")
    print("="*80)
    print("""
THE PROBLEM:
Your code is likely doing this:
    final_type = llm_classification_result["document_type"]
    
When LLM returns "Unknown", you're accepting it without checking NER!

THE FIX:
Replace your result merging logic with this:

```python
def merge_ner_and_llm_results(ner_result, llm_result):
    '''Intelligently combine NER and LLM classification'''
    
    ner_type = ner_result.get("document_type")
    ner_confidence = ner_result.get("confidence", 0.0)
    
    llm_type = llm_result.get("document_type") 
    llm_confidence = llm_result.get("confidence_score", 0.0)
    
    # Define mapping from NER to possible final types
    NER_MAPPING = {
        "financial_report": ["Balance Sheet", "Income Statement", "Cash Flow Statement"],
        "invoice": ["Invoice"],
        "receipt": ["Receipt"],
        # ... add your other mappings
    }
    
    # Case 1: LLM is confident and specific
    if llm_type != "Unknown" and llm_confidence > 0.75:
        return llm_result
    
    # Case 2: LLM uncertain BUT NER has a hint
    if llm_type == "Unknown" and ner_type and ner_type != "unknown":
        possible_types = NER_MAPPING.get(ner_type, [])
        
        if len(possible_types) == 1:
            # Only one possibility - use it!
            return {
                "document_type": possible_types[0],
                "confidence_score": ner_confidence * 0.8,
                "method": "ner_fallback",
                "reasoning": f"LLM uncertain, using NER classification: {ner_type}"
            }
        else:
            # Multiple possibilities - flag for review
            return {
                "document_type": "Unknown",
                "confidence_score": 0.6,
                "method": "requires_review",
                "possible_types": possible_types,
                "reasoning": f"NER suggests {ner_type}, needs human review"
            }
    
    # Case 3: No good info from either
    return {
        "document_type": "Unknown",
        "confidence_score": 0.0,
        "method": "no_classification",
        "reasoning": "Both NER and LLM uncertain"
    }
```

INTEGRATION INTO YOUR LANGGRAPH:
Add this to your classify_document node:

```python
def classify_document(state: DocumentState) -> DocumentState:
    # ... your existing code ...
    
    # Get NER result (if you have NER step)
    ner_result = state.get("ner_result")
    
    # Get LLM result
    llm_result = parse_llm_response(response.content)
    
    # 🔧 ADD THIS: Merge intelligently
    final_result = merge_ner_and_llm_results(ner_result, llm_result)
    
    state["classification_result"] = final_result
    # ... rest of your code ...
```
    """)
    
    print("\n" + "="*80)
    print("📋 QUICK CHECKLIST")
    print("="*80)
    print("""
✓ Do you have NER results stored in your state?
✓ Are you passing NER results to the merge function?
✓ Do you have a mapping from NER types to final types?
✓ Are you handling the "Unknown" case from LLM specially?
✓ Are you using NER as a fallback when LLM is uncertain?

If you answered NO to any of these, that's likely your bug!
    """)