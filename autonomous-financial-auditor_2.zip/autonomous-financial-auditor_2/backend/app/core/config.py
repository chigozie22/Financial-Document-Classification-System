"""
Configuration settings for the Autonomous Financial Auditor
"""

from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional 
import os 
from pathlib import Path 

# Get the project root directory (2 levels up from this file)
BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
ENV_FILE = BASE_DIR / ".env"

class Settings(BaseSettings):
    """
    Configuration settings for the Autonomous Financial Auditor application.
    """
    # API settings 
    API_V1_PREFIX: str = "/api/v1"
    PROJECT_NAME: str = "Autonomous Financial Auditor"
    VERSION: str = "1.0.0"
    DEBUG: bool = True 


    # CORS 
    BACKEND_CORS_ORIGINS: list = ["http://localhost:3000", "http://localhost:5173"]

    # MongoDB 
    MONGODB_URL: str = "mongodb://localhost:27017"
    MONGODB_DB_NAME: str = "financial_auditor_db"

    # REDIS (FOR Celery) 
    REDIS_URL: str = "redis://localhost:6379/0" 

    # File Upload Settings 
    UPLOAD_DIR: str = "data/raw_uploads"
    PROCESSED_DIR: str = "data/processed"
    MAX_UPLOAD_SIZE: int = 10 * 1024 * 1024  # 10 MB
    ALLOWED_EXTENSIONS: set = {".pdf", ".png", ".jpg", ".jpeg", ".csv", ".xlsx", ".xls", ".txt"}

    # OCR Settings 
    TESSERACT_CMD: Optional[str] = None
    OCR_LANG : str = "eng"
    OCR_CONFIG: str = "--psm 6"

    #Spacy Model 
    SPACY_MODEL: str = "en_core_web_sm" 

    #LLM SETTINGS - GOOGLE GEMINI
    GOOGLE_GEMINI_API_KEY: Optional[str] = None
    GOOGLE_API_KEY: Optional[str] = None
    LLM_MODEL: str = "gemini-2.0-flash-exp"
    LLM_TEMPERATURE: float = 0.1
    LLM_MAX_TOKENS: int = 4096

    @property
    def GEMINI_API_KEY(self) -> Optional[str]:  # ← ADD THIS PROPERTY
        """Get Gemini API key from either variable name"""
        return self.GOOGLE_GEMINI_API_KEY or self.GOOGLE_API_KEY

    #AGENT SETTINGS
    EXTRACTION_CONFIDENCE_THRESHOLD: float = 0.75


    #LOGGING 
    LOG_LEVEL: str = "INFO"
    LOG_DIR: str = "data/logs"

    class Config:
        env_file = str(ENV_FILE)
        env_file_encoding = 'utf-8'
        extra = 'ignore'
        case_sensitive = True

# create settings instance
settings = Settings()

# Create necessary directories 
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
os.makedirs(settings.PROCESSED_DIR, exist_ok=True)
os.makedirs(settings.LOG_DIR, exist_ok=True)
os.makedirs("data/reports", exist_ok=True)