"""
Google Gemini API Client for LLM operations
"""
import google.generativeai as genai
import json
import logging
from typing import Dict, Any, Optional
import re
from PIL import Image

logger = logging.getLogger(__name__)


class GeminiClient:
    """Client for interacting with Google Gemini API"""
    
    def __init__(self, api_key: str, model_name: str = "gemini-2.0-flash-exp", 
                 temperature: float = 0.1, max_tokens: int = 2000):
        """
        Initialize Gemini client
        
        Args:
            api_key: Google API key
            model_name: Model to use
            temperature: Sampling temperature
            max_tokens: Maximum output tokens
        """
        genai.configure(api_key=api_key)
        
        self.model_name = model_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        
        # Configure generation settings
        self.generation_config = {
            "temperature": temperature,
            "top_p": 0.95,
            "top_k": 40,
            "max_output_tokens": max_tokens,
        }
        
        # Safety settings (adjust as needed)
        self.safety_settings = [
            {
                "category": "HARM_CATEGORY_HARASSMENT",
                "threshold": "BLOCK_NONE"
            },
            {
                "category": "HARM_CATEGORY_HATE_SPEECH",
                "threshold": "BLOCK_NONE"
            },
            {
                "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                "threshold": "BLOCK_NONE"
            },
            {
                "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
                "threshold": "BLOCK_NONE"
            },
        ]
        
        self.model = genai.GenerativeModel(
            model_name=model_name,
            generation_config=self.generation_config,
            safety_settings=self.safety_settings
        )
        
        logger.info(f"Initialized Gemini client with model: {model_name}")
    
    def generate_text(self, prompt: str, system_instruction: Optional[str] = None) -> str:
        """
        Generate text from prompt
        
        Args:
            prompt: User prompt
            system_instruction: System instruction (optional)
            
        Returns:
            Generated text
        """
        try:
            logger.info(f"🤖 GEMINI API CALL - generate_text()")
            logger.info(f"   Model: {self.model_name}")
            logger.info(f"   Prompt length: {len(prompt)} chars")
            
            # Combine system instruction with prompt if provided
            if system_instruction:
                full_prompt = f"{system_instruction}\n\n{prompt}"
            else:
                full_prompt = prompt
            
            # Use the existing model instance
            response = self.model.generate_content(full_prompt)
            
            if response.candidates:
                response_text = response.text
                logger.info(f"   ✅ Response received: {len(response_text)} chars")
                return response_text
            else:
                logger.error("No response candidates from Gemini")
                return ""
                
        except Exception as e:
            logger.error(f"Error generating text with Gemini: {e}")
            import traceback
            traceback.print_exc()
            return ""
    
    def analyze_image(self, image_path: str, prompt: str) -> str:
        """
        Analyze image using Gemini Vision
        
        Args:
            image_path: Path to image file
            prompt: Analysis prompt
            
        Returns:
            Analysis text
        """
        try:
            logger.info(f"👁️ GEMINI VISION API CALL - analyze_image()")
            logger.info(f"   Model: {self.model_name}")
            logger.info(f"   Image: {image_path}")
            
            # Load image
            img = Image.open(image_path)
            
            # Generate content with image
            response = self.model.generate_content([prompt, img])
            
            if response.candidates:
                response_text = response.text
                logger.info(f"   ✅ Vision response received: {len(response_text)} chars")
                return response_text
            else:
                logger.error("No response candidates from Gemini Vision")
                return ""
                
        except Exception as e:
            logger.error(f"Error analyzing image with Gemini Vision: {e}")
            import traceback
            traceback.print_exc()
            return ""
    
    def classify_document_image(self, image_path: str, classification_prompt: str) -> Dict[str, Any]:
        """
        Classify financial document using Gemini Vision
        
        Args:
            image_path: Path to document image
            classification_prompt: Classification prompt
            
        Returns:
            Classification result as JSON
        """
        try:
            logger.info(f"📄 GEMINI DOCUMENT CLASSIFICATION - classify_document_image()")
            
            # Get response from vision model
            response_text = self.analyze_image(image_path, classification_prompt)
            
            if not response_text:
                return {}
            
            # Parse JSON response
            return self._parse_json_response(response_text)
            
        except Exception as e:
            logger.error(f"Error classifying document: {e}")
            return {}
    
    def generate_json(self, prompt: str, system_instruction: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate JSON response from prompt
        
        Args:
            prompt: User prompt
            system_instruction: System instruction
            
        Returns:
            Parsed JSON response
        """
        try:
            logger.info(f"🤖 GEMINI API CALL - generate_json()")
            logger.info(f"   Model: {self.model_name}")
            
            # Combine system instruction with prompt
            if system_instruction:
                full_prompt = f"{system_instruction}\n\n{prompt}"
            else:
                full_prompt = prompt
            
            response_text = self.generate_text(full_prompt)
            
            if not response_text:
                logger.warning("Empty response from Gemini")
                return {}
            
            return self._parse_json_response(response_text)
                
        except Exception as e:
            logger.error(f"Error generating JSON with Gemini: {e}")
            import traceback
            traceback.print_exc()
            return {}
    
    def _parse_json_response(self, response_text: str) -> Dict[str, Any]:
        """
        Parse JSON from Gemini response text
        
        Args:
            response_text: Raw response text
            
        Returns:
            Parsed JSON dict
        """
        # Log the raw response for debugging
        logger.info(f"   Raw response length: {len(response_text)}")
        logger.debug(f"   Raw response (first 500 chars): {response_text[:500]}")
        
        # Clean response - remove markdown formatting if present
        cleaned = response_text.strip()
        
        # Remove markdown code blocks
        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        elif cleaned.startswith("```"):
            cleaned = cleaned[3:]
        
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        
        cleaned = cleaned.strip()
        
        # Parse JSON
        try:
            parsed = json.loads(cleaned)
            logger.info(f"   ✅ JSON parsed successfully")
            logger.info(f"   Parsed keys: {list(parsed.keys())}")
            return parsed
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON response: {e}")
            logger.error(f"Response text: {cleaned[:500]}")
            
            # Try to extract JSON using regex as fallback
            json_match = re.search(r'\{.*\}', cleaned, re.DOTALL)
            if json_match:
                try:
                    logger.info("Attempting regex-based JSON extraction...")
                    parsed = json.loads(json_match.group())
                    logger.info("✅ Regex extraction succeeded")
                    return parsed
                except:
                    logger.error("Regex extraction also failed")
                    pass
            
            return {}
    
    def validate_extraction(self, extracted_data: Dict[str, Any], raw_text: str) -> Dict[str, Any]:
        """
        Validate extracted data against original text
        
        Args:
            extracted_data: Extracted structured data
            raw_text: Original OCR text
            
        Returns:
            Validation result with issues and corrections
        """
        validation_prompt = f"""Review this extracted financial data for accuracy and consistency.

**Extracted Data:**
{json.dumps(extracted_data, indent=2)}

**Original OCR Text (first 2000 chars):**
{raw_text[:2000]}

Verify:
1. Do amounts add up correctly? (subtotal + tax = total)
2. Are dates in valid format?
3. Is vendor information consistent?
4. Are line items correctly parsed?
5. Is the document type correct?

Return a JSON object:
{{
  "is_valid": true/false,
  "issues": ["list of any problems found"],
  "corrections": {{"field": "corrected_value"}},
  "confidence_score": float between 0.0 and 1.0
}}

Return ONLY the JSON object, no markdown formatting."""

        system_instruction = "You are a financial document validator. Return only valid JSON."
        
        return self.generate_json(validation_prompt, system_instruction)