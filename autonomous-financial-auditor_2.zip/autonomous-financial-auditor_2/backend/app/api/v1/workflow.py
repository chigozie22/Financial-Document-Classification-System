"""
FastAPI endpoints for LangGraph Audit Workflow
"""
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from typing import Optional
import os
import uuid
import shutil
import logging

from backend.app.services.workflow_service import workflow_service
from backend.app.core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workflow", tags=["workflow"])


def save_upload_file(upload_file: UploadFile) -> tuple[str, str]:
    """Save uploaded file and return document_id and file_path"""
    document_id = f"doc_{uuid.uuid4().hex[:12]}"
    file_extension = os.path.splitext(upload_file.filename)[1]
    file_path = os.path.join(settings.UPLOAD_DIR, f"{document_id}{file_extension}")
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(upload_file.file, buffer)
    
    return document_id, file_path


@router.post("/audit/complete")
async def complete_audit_workflow(
    file: UploadFile = File(...),
    report_format: str = "both"
):
    """
    🚀 COMPLETE AUDIT PIPELINE (LangGraph Orchestrated)
    
    Runs the full workflow: Agent 1 → Agent 2 → Agent 3
    
    - **file**: Document to audit (PDF, PNG, JPG, JPEG)
    - **report_format**: "pdf", "word", or "both" (default: both)
    
    Returns complete audit results with PDF/Word reports
    """
    try:
        logger.info(f"Received complete audit request for: {file.filename}")
        
        # Validate file type
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in settings.ALLOWED_EXTENSIONS:
            raise HTTPException(
                status_code=400,
                detail=f"File type not supported. Allowed: {settings.ALLOWED_EXTENSIONS}"
            )
        
        # Save uploaded file
        document_id, file_path = save_upload_file(file)
        logger.info(f"File saved: {document_id}")
        
        # Run LangGraph workflow
        logger.info("Starting LangGraph workflow...")
        result = await workflow_service.run_complete_audit(
            document_path=file_path,
            document_id=document_id,
            report_format=report_format
        )
        
        # Build response
        response = {
            "status": result.get("final_status"),
            "document_id": document_id,
            "workflow_summary": {
                "started_at": result.get("started_at"),
                "completed_at": result.get("completed_at"),
                "total_time": f"{result.get('total_processing_time', 0):.2f}s"
            },
            "agent_1_extraction": {
                "status": result.get("extraction_status"),
                "time": f"{result.get('extraction_time', 0):.2f}s",
                "error": result.get("extraction_error"),
                "data_extracted": result.get("extracted_data") is not None
            },
            "agent_2_validation": {
                "status": result.get("validation_status"),
                "time": f"{result.get('validation_time', 0):.2f}s",
                "error": result.get("validation_error"),
                "validation_score": result.get("validation_report", {}).get("overall_score") if result.get("validation_report") else None,
                "risk_level": result.get("validation_report", {}).get("risk_level") if result.get("validation_report") else None
            },
            "agent_3_report": {
                "status": result.get("report_status"),
                "time": f"{result.get('report_time', 0):.2f}s",
                "error": result.get("report_error"),
                "pdf_path": result.get("pdf_path"),
                "word_path": result.get("word_path")
            },
            "errors": result.get("errors", []),
            "extracted_data": result.get("extracted_data"),
            "validation_report": result.get("validation_report")
        }
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Workflow endpoint error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Workflow failed: {str(e)}")


@router.get("/status")
async def get_workflow_status():
    """
    Get LangGraph workflow status and configuration
    """
    try:
        status = workflow_service.get_workflow_status()
        return status
    except Exception as e:
        logger.error(f"Error getting workflow status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/download/pdf/{document_id}")
async def download_pdf_report(document_id: str):
    """
    Download PDF audit report
    
    - **document_id**: Document ID from workflow
    """
    try:
        pdf_path = os.path.join("data/reports", f"{document_id}_audit_report.pdf")
        
        if not os.path.exists(pdf_path):
            raise HTTPException(status_code=404, detail="PDF report not found")
        
        return FileResponse(
            pdf_path,
            media_type="application/pdf",
            filename=f"{document_id}_audit_report.pdf"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading PDF: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/download/word/{document_id}")
async def download_word_report(document_id: str):
    """
    Download Word audit report
    
    - **document_id**: Document ID from workflow
    """
    try:
        word_path = os.path.join("data/reports", f"{document_id}_audit_report.docx")
        
        if not os.path.exists(word_path):
            raise HTTPException(status_code=404, detail="Word report not found")
        
        return FileResponse(
            word_path,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            filename=f"{document_id}_audit_report.docx"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading Word: {e}")
        raise HTTPException(status_code=500, detail=str(e))