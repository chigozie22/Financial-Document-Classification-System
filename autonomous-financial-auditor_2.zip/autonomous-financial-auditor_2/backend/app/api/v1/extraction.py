"""
FastAPI endpoints for document extraction (Agent 1)
"""
from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
from typing import List, Optional 
import os 
import uuid 
import shutil 
import logging 

from backend.app.services.agent1_service import agent1_service 
from backend.app.core.config import settings 
from models.schemas import (
    ExtractionResponse,
    UploadResponse, 
    BatchExtractionRequest,
    BatchExtractionResponse,
    ExtractionStatus
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/extraction", tags=["extraction"])

def validate_file_extension(filename: str) -> bool:
    """Validate file extension"""
    ext = os.path.splitext(filename)[1].lower()
    return ext in settings.ALLOWED_EXTENSIONS

def save_upload_file(upload_file: UploadFile) -> tuple[str, str]:
    """
    Save uploaded file to disk
    
    Returns:
        Tuple of (document_id, file_path)
    """

    # Generate unique document ID 
    document_id = f"doc_{uuid.uuid4().hex[:12]}"

    # Create file path
    file_extension = os.path.splitext(upload_file.filename)[1]
    file_path = os.path.join(settings.UPLOAD_DIR, f"{document_id}{file_extension}")

    # Save file 
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(upload_file.file, buffer)
    
    return document_id, file_path 

@router.post("/upload", response_model=UploadResponse)
async def upload_document(file: UploadFile = File(...)):
    """
    Upload a financial document for processing
    
    - **file**: Document file (PDF, PNG, JPG, JPEG, XLSX, XLS)
    
    Returns document_id for tracking
    """
    try: 
        # Validate file
        if not file.filename:
            raise HTTPException(status_code=400, detail="No filename provided")
        
        if not validate_file_extension(file.filename):
            raise HTTPException(
                status_code=400,
                detail=f"File type not supported. Allowed: {settings.ALLOWED_EXTENSIONS}"
            )
        
        #check file size
        file.file.seek(0, 2) # seek to end 
        file_size = file.file.tell()
        file.file.seek(0) # reset to start

        if file_size > settings.MAX_UPLOAD_SIZE:
            raise HTTPException(
                status_code=400,
                detail=f"File too large. Max size: {settings.MAX_UPLOAD_SIZE / (1024*1024)}MB"

            )
        
        # sAVE FILE
        document_id, file_path = save_upload_file(file)

        logger.info(f"File uploaded: {file.filename} -> {document_id}")

        return UploadResponse(
            document_id=document_id,
            file_name = file.filename,
            file_size=file_size,
            upload_status="success",
            message="File Uploaded successfully. Use document_id to extract data."
        )

    except HTTPException: 
        raise 
    except Exception as e:
        logger.error(f"Upload error: {e}")

        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")
    

@router.post("/extract/{document_id}", response_model=ExtractionResponse)
async def extract_document(document_id: str):
    """
    Extract structured data from uploaded document
    
    - **document_id**: Document ID from upload endpoint
    
    Runs Agent 1 extraction pipeline
    """
    try:
        # Find document file
        file_path = None
        for ext in settings.ALLOWED_EXTENSIONS:
            potential_path = os.path.join(settings.UPLOAD_DIR, f"{document_id}{ext}")
            if os.path.exists(potential_path):
                file_path = potential_path
                break

        if not file_path:
            raise HTTPException(
                status_code=404,
                detail=f"Document not found: {document_id}"
            )
        
        logger.info(f"Starting extraction for document: {document_id}")

        # Run extraction
        result = await agent1_service.extract_from_file(file_path, document_id)

        if result["status"] == "failed":
            return ExtractionResponse(
                status=ExtractionStatus.FAILED,
                document_id=document_id,
                extracted_data=None,
                error_message=result.get("error_message"),
                processing_time=result.get("processing_time")
            )
        
        return ExtractionResponse(
            status=ExtractionStatus.COMPLETED,
            document_id=document_id,
            extracted_data=result["extracted_data"],
            error_message=None,
            processing_time=result.get("processing_time")
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Extraction error for {document_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Extraction failed: {str(e)}")
    
@router.post("/upload-and-extract", response_model=ExtractionResponse)
async def upload_and_extract(file: UploadFile = File(...)):
    """
    Upload and immediately extract in one step
    
    - **file**: Document file
    
    Combines upload + extraction for convenience
    """
    try:
        # Validate file
        if not file.filename:
            raise HTTPException(status_code=400, detail="No filename provided")
        
        if not validate_file_extension(file.filename):
            raise HTTPException(
                status_code=400,
                detail=f"File type not supported. Allowed: {settings.ALLOWED_EXTENSIONS}"
            )
        
        # Save file
        document_id, file_path = save_upload_file(file)
        
        logger.info(f"Upload and extract: {file.filename} -> {document_id}")
        
        # Run extraction
        result = await agent1_service.extract_from_file(file_path, document_id)
        
        if result["status"] == "failed":
            return ExtractionResponse(
                status=ExtractionStatus.FAILED,
                document_id=document_id,
                extracted_data=None,
                error_message=result.get("error_message"),
                processing_time=result.get("processing_time")
            )
        
        return ExtractionResponse(
            status=ExtractionStatus.COMPLETED,
            document_id=document_id,
            extracted_data=result["extracted_data"],
            error_message=None,
            processing_time=result.get("processing_time")
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Upload and extract error: {e}")
        raise HTTPException(status_code=500, detail=f"Operation failed: {str(e)}")
    
@router.post("/batch/extract", response_model=BatchExtractionResponse)
async def batch_extract(request: BatchExtractionRequest):
    """
    Extract multiple documents in batch
    
    - **document_ids**: List of document IDs to process
    
    Returns results for all documents
    """
    try:
        results = []
        successful = 0
        failed = 0
        
        for document_id in request.document_ids:
            # Find file
            file_path = None
            for ext in settings.ALLOWED_EXTENSIONS:
                potential_path = os.path.join(settings.UPLOAD_DIR, f"{document_id}{ext}")
                if os.path.exists(potential_path):
                    file_path = potential_path
                    break
            
            if not file_path:
                results.append(ExtractionResponse(
                    status=ExtractionStatus.FAILED,
                    document_id=document_id,
                    extracted_data=None,
                    error_message="Document not found"
                ))
                failed += 1
                continue
            
            # Extract
            result = await agent1_service.extract_from_file(file_path, document_id)
            
            if result["status"] == "success":
                results.append(ExtractionResponse(
                    status=ExtractionStatus.COMPLETED,
                    document_id=document_id,
                    extracted_data=result["extracted_data"],
                    processing_time=result.get("processing_time")
                ))
                successful += 1
            else:
                results.append(ExtractionResponse(
                    status=ExtractionStatus.FAILED,
                    document_id=document_id,
                    extracted_data=None,
                    error_message=result.get("error_message")
                ))
                failed += 1
        
        return BatchExtractionResponse(
            total_documents=len(request.document_ids),
            successful=successful,
            failed=failed,
            results=results
        )
        
    except Exception as e:
        logger.error(f"Batch extraction error: {e}")
        raise HTTPException(status_code=500, detail=f"Batch extraction failed: {str(e)}")

@router.get("/status/{document_id}")
async def get_extraction_status(document_id: str):
    """
    Get extraction status for a document
    
    - **document_id**: Document ID
    
    Returns processing status and results if available
    """
    try:
        # Check if processed JSON exists
        processed_path = os.path.join(settings.PROCESSED_DIR, f"{document_id}_extracted.json")
        
        if os.path.exists(processed_path):
            import json
            with open(processed_path, 'r') as f:
                data = json.load(f)
            
            return {
                "status": "completed",
                "document_id": document_id,
                "extracted_data": data
            }
        
        # Check if file exists in uploads
        file_exists = False
        for ext in settings.ALLOWED_EXTENSIONS:
            if os.path.exists(os.path.join(settings.UPLOAD_DIR, f"{document_id}{ext}")):
                file_exists = True
                break
        
        if file_exists:
            return {
                "status": "pending",
                "document_id": document_id,
                "message": "Document uploaded but not yet processed"
            }
        
        raise HTTPException(status_code=404, detail="Document not found")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Status check error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    
@router.get("/agent/status")
async def get_agent_status():
    """
    Get Agent 1 status and configuration
    
    Returns agent health and settings
    """
    try:
        status = agent1_service.get_agent_status()
        return status
    except Exception as e:
        logger.error(f"Agent status error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    

@router.delete("/document/{document_id}")
async def delete_document(document_id: str):
    """
    Delete a document and its extracted data
    
    - **document_id**: Document ID to delete
    """
    try:
        deleted_files = []
        
        # Delete uploaded file
        for ext in settings.ALLOWED_EXTENSIONS:
            upload_path = os.path.join(settings.UPLOAD_DIR, f"{document_id}{ext}")
            if os.path.exists(upload_path):
                os.remove(upload_path)
                deleted_files.append(upload_path)
        
        # Delete processed JSON
        processed_path = os.path.join(settings.PROCESSED_DIR, f"{document_id}_extracted.json")
        if os.path.exists(processed_path):
            os.remove(processed_path)
            deleted_files.append(processed_path)
        
        if not deleted_files:
            raise HTTPException(status_code=404, detail="Document not found")
        
        return {
            "status": "success",
            "document_id": document_id,
            "deleted_files": len(deleted_files),
            "message": "Document deleted successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Delete error: {e}")
        raise HTTPException(status_code=500, detail=str(e))