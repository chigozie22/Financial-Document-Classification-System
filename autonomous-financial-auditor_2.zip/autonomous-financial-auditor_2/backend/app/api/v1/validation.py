"""
FastAPI endpoints for document validation (Agent 2)
"""
from fastapi import APIRouter, HTTPException
from typing import List, Optional, Dict, Any
import logging

from backend.app.services.agent2_service import agent2_service
from models.validation_schemas import ValidationReport
from models.schemas import ExtractionStatus
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/validation", tags=["validation"])

class ValidationRequest(BaseModel):
    """Request model for document validation."""
    extracted_data: Dict[str, Any]
    historical_data: Optional[List[Dict[str, Any]]] = None

class BatchValidationRequest(BaseModel):
    """Request model for batch document validation."""
    validations: List[ValidationRequest]

class ValidationResponse(BaseModel):
    """Response model for document validation."""
    document_id: str
    status: str  # "success" or "error"
    validation_report: Optional[ValidationReport] = None
    error_message: Optional[str] = None
    processing_time: Optional[float] = None

class BatchValidationResponse(BaseModel):
    """Response for batch document validation."""
    total_documents: int
    successful: int
    failed: int
    results: List[ValidationResponse]

@router.post("/validate/{document_id}", response_model=ValidationResponse)
async def validate_document_from_file(document_id: str):
    """
    Validate extracted data from file

    - **document_id**: Document ID from extraction

    Runs Agent 2 validation pipeline on saved extracted data
    """
    try:
        logger.info(f"Starting validation for document: {document_id}")

        # Validate from file
        validation_report = await agent2_service.validate_from_file(document_id)

        if validation_report is None:
            raise HTTPException(
                status_code=404,
                detail=f"Extracted data not found for document: {document_id}"
            )

        return ValidationResponse(
            document_id=document_id,
            status="success",
            validation_report=validation_report,
            processing_time=getattr(validation_report, 'processing_time', None)
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Validation error for {document_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")

@router.post("/validate", response_model=ValidationResponse)
async def validate_document(request: ValidationRequest):
    """
    Validate provided extracted data

    - **extracted_data**: Extracted data dictionary
    - **historical_data**: Optional historical documents for comparison

    Runs Agent 2 validation pipeline
    """
    try:
        document_id = request.extracted_data.get("document_id", "unknown")
        logger.info(f"Starting validation for document: {document_id}")

        # Run validation
        validation_report = await agent2_service.validate_document(
            extracted_data=request.extracted_data,
            historical_data=request.historical_data
        )

        return ValidationResponse(
            document_id=document_id,
            status="success",
            validation_report=validation_report,
            processing_time=getattr(validation_report, 'processing_time', None)
        )

    except Exception as e:
        logger.error(f"Validation error: {e}")
        raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")

@router.post("/batch/validate", response_model=BatchValidationResponse)
async def batch_validate(request: BatchValidationRequest):
    """
    Validate multiple documents in batch

    - **validations**: List of validation requests

    Returns results for all documents
    """
    try:
        results = []
        successful = 0
        failed = 0

        for validation_req in request.validations:
            try:
                document_id = validation_req.extracted_data.get("document_id", "unknown")

                # Run validation
                validation_report = await agent2_service.validate_document(
                    extracted_data=validation_req.extracted_data,
                    historical_data=validation_req.historical_data
                )

                results.append(ValidationResponse(
                    document_id=document_id,
                    status="success",
                    validation_report=validation_report,
                    processing_time=getattr(validation_report, 'processing_time', None)
                ))
                successful += 1

            except Exception as e:
                logger.error(f"Batch validation error: {e}")
                results.append(ValidationResponse(
                    document_id=validation_req.extracted_data.get("document_id", "unknown"),
                    status="error",
                    error_message=str(e)
                ))
                failed += 1

        return BatchValidationResponse(
            total_documents=len(request.validations),
            successful=successful,
            failed=failed,
            results=results
        )

    except Exception as e:
        logger.error(f"Batch validation error: {e}")
        raise HTTPException(status_code=500, detail=f"Batch validation failed: {str(e)}")

@router.get("/report/{document_id}")
async def get_validation_report(document_id: str):
    """
    Get validation report for a document

    - **document_id**: Document ID

    Returns saved validation report
    """
    try:
        report = await agent2_service.get_validation_report(document_id)

        if report is None:
            raise HTTPException(
                status_code=404,
                detail=f"Validation report not found for document: {document_id}"
            )

        return report

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Report retrieval error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/stats")
async def get_validation_statistics(document_ids: Optional[List[str]] = None):
    """
    Get validation statistics

    - **document_ids**: Optional list of document IDs to analyze (default: all)

    Returns aggregate statistics
    """
    try:
        if document_ids is None:
            # If no specific IDs, we need to get all document IDs
            # For now, return empty stats or implement logic to get all IDs
            return {
                "message": "Please provide document_ids parameter",
                "example": "/validation/stats?document_ids=doc1,doc2,doc3"
            }

        stats = agent2_service.get_validation_statistics(document_ids)
        return stats

    except Exception as e:
        logger.error(f"Statistics error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/agent/status")
async def get_agent_status():
    """
    Get Agent 2 status and configuration

    Returns agent health and settings
    """
    try:
        status = agent2_service.get_agent_status()
        return status
    except Exception as e:
        logger.error(f"Agent status error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
