"""
API v1 Router
"""
from fastapi import APIRouter
from backend.app.api.v1 import extraction, validation, workflow

api_router = APIRouter()

# Include extraction endpoints (Agent 1)
api_router.include_router(extraction.router)

# Include validation endpoints (Agent 2)
api_router.include_router(validation.router)

# Include workflow endpoints (LangGraph orchestration)
api_router.include_router(workflow.router)