"""
Workflow Service - Manages LangGraph orchestration
"""
import logging
from datetime import datetime
from typing import Dict, Any
from backend.app.workflows.audit_workflow import audit_workflow
from backend.app.workflows.state import AuditState

logger = logging.getLogger(__name__)


class WorkflowService:
    """Service for managing LangGraph audit workflows"""
    
    _instance = None
    
    def __new__(cls):
        """Singleton pattern"""
        if cls._instance is None:
            cls._instance = super(WorkflowService, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize workflow service"""
        self.workflow = audit_workflow
        logger.info("Workflow service initialized")
    
    async def run_complete_audit(self,
                                 document_path: str,
                                 document_id: str,
                                 report_format: str = "both") -> Dict[str, Any]:
        """
        Run complete audit pipeline using LangGraph
        
        Args:
            document_path: Path to uploaded document
            document_id: Document ID
            report_format: "pdf", "word", or "both"
            
        Returns:
            Final workflow state
        """
        logger.info(f"Starting LangGraph audit workflow for: {document_id}")
        
        started_at = datetime.now().isoformat()
        
        # Initialize state
        initial_state: AuditState = {
            "document_id": document_id,
            "document_path": document_path,
            "report_format": report_format,
            
            # Agent 1
            "extracted_data": None,
            "extraction_status": "pending",
            "extraction_error": None,
            "extraction_time": None,
            
            # Agent 2
            "validation_report": None,
            "validation_status": "pending",
            "validation_error": None,
            "validation_time": None,
            
            # Agent 3
            "pdf_path": None,
            "word_path": None,
            "report_status": "pending",
            "report_error": None,
            "report_time": None,
            
            # Overall
            "current_step": "extract",
            "errors": [],
            "final_status": "pending",
            "total_processing_time": None,
            "started_at": started_at,
            "completed_at": None
        }
        
        try:
            # Run workflow
            logger.info("Invoking LangGraph workflow...")
            final_state = await self.workflow.ainvoke(initial_state)
            
            # Calculate total time
            completed_at = datetime.now().isoformat()
            total_time = (
                (final_state.get("extraction_time") or 0) +
                (final_state.get("validation_time") or 0) +
                (final_state.get("report_time") or 0)
            )
            
            # Update final state
            final_state["completed_at"] = completed_at
            final_state["total_processing_time"] = total_time
            
            logger.info(f"Workflow completed. Status: {final_state.get('final_status')}")
            logger.info(f"Total processing time: {total_time:.2f}s")
            
            return final_state
            
        except Exception as e:
            logger.error(f"Workflow execution error: {e}", exc_info=True)
            
            return {
                **initial_state,
                "final_status": "failed",
                "errors": [f"Workflow error: {str(e)}"],
                "completed_at": datetime.now().isoformat()
            }
    
    def get_workflow_status(self) -> Dict[str, Any]:
        """
        Get workflow service status
        
        Returns:
            Status information
        """
        return {
            "service_name": "LangGraph Audit Workflow",
            "status": "active",
            "workflow_nodes": ["extract", "validate", "report"],
            "agents": [
                "Agent 1 - OCR & Extraction",
                "Agent 2 - Validation & Anomaly Detection",
                "Agent 3 - Report Generation"
            ],
            "workflow_type": "Sequential Pipeline with Conditional Routing"
        }


# Global service instance
workflow_service = WorkflowService()