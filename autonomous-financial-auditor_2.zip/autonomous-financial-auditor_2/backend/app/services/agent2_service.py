"""
Service layer for Agent 2 operations
"""
import os
import sys
import logging
from typing import Dict, Any, List, Optional

# Add paths for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))

from agents.agent_2_validator.agent import Agent2Validator
from agents.agent_2_validator.tools.validation_engine import ValidationEngine
from agents.agent_2_validator.anomaly_detector import AnomalyDetector
from backend.app.utils.gemini_client import GeminiClient
from backend.app.core.config import settings
from models.validation_schemas import ValidationReport

logger = logging.getLogger(__name__)


class Agent2Service:
    """Service for managing Agent 2 validation operations"""
    
    _instance = None
    _agent = None
    
    def __new__(cls):
        """Singleton pattern"""
        if cls._instance is None:
            cls._instance = super(Agent2Service, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize service with Agent 2"""
        if self._agent is None:
            self._initialize_agent()
    
    def _initialize_agent(self):
        """Initialize Agent 2 with all required tools"""
        try:
            logger.info("Initializing Agent 2 Service...")
            
            # Initialize Validation Engine
            validation_engine = ValidationEngine(
                tolerance=0.01  # $0.01 tolerance for arithmetic
            )
            
            # Initialize Anomaly Detector
            anomaly_detector = AnomalyDetector(
                contamination=0.1  # Expect 10% anomalies
            )
            
            # Initialize Gemini Client (optional for LLM validation)
            gemini_client = None
            use_llm = False
            
            api_key = settings.GEMINI_API_KEY
            if api_key:
                try:
                    gemini_client = GeminiClient(
                        api_key=api_key,
                        model_name=settings.LLM_MODEL,
                        temperature=settings.LLM_TEMPERATURE,
                        max_tokens=settings.LLM_MAX_TOKENS
                    )
                    use_llm = True
                    logger.info("Gemini client initialized for LLM validation")
                except Exception as e:
                    logger.warning(f"Failed to initialize Gemini client: {e}")
                    logger.info("Agent 2 will run without LLM validation")
            else:
                logger.info("No Gemini API key found. Agent 2 will run without LLM validation")
            
            # Initialize Agent 2
            self._agent = Agent2Validator(
                validation_engine=validation_engine,
                anomaly_detector=anomaly_detector,
                gemini_client=gemini_client,
                use_llm=use_llm
            )
            
            logger.info("Agent 2 service initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize Agent 2 service: {e}")
            raise
    
    async def validate_document(self, 
                               extracted_data: Dict[str, Any],
                               historical_data: Optional[List[Dict]] = None) -> ValidationReport:
        """
        Validate extracted document data
        
        Args:
            extracted_data: Output from Agent 1
            historical_data: Optional historical documents for comparison
            
        Returns:
            Validation report
        """
        try:
            document_id = extracted_data.get("document_id", "unknown")
            logger.info(f"Starting validation for document: {document_id}")
            
            # Run validation (synchronous, wrapped in async)
            validation_report = self._agent.validate_document(
                extracted_data=extracted_data,
                historical_data=historical_data
            )
            
            return validation_report
            
        except Exception as e:
            logger.error(f"Error in validate_document: {e}", exc_info=True)
            raise
    
    async def validate_from_file(self, document_id: str) -> Optional[ValidationReport]:
        """
        Load extracted data from file and validate
        
        Args:
            document_id: Document ID to validate
            
        Returns:
            Validation report or None if file not found
        """
        try:
            import json
            
            # Load extracted data
            extracted_file = os.path.join(
                settings.PROCESSED_DIR, 
                f"{document_id}_extracted.json"
            )
            
            if not os.path.exists(extracted_file):
                logger.error(f"Extracted data file not found: {extracted_file}")
                return None
            
            with open(extracted_file, 'r', encoding='utf-8') as f:
                extracted_data = json.load(f)
            
            # Validate
            validation_report = await self.validate_document(extracted_data)
            
            return validation_report
            
        except Exception as e:
            logger.error(f"Error in validate_from_file: {e}")
            raise
    
    async def validate_batch(self, 
                           extracted_data_list: List[Dict[str, Any]]) -> List[ValidationReport]:
        """
        Validate multiple documents
        
        Args:
            extracted_data_list: List of extracted data dictionaries
            
        Returns:
            List of validation reports
        """
        results = []
        
        for extracted_data in extracted_data_list:
            try:
                report = await self.validate_document(extracted_data)
                results.append(report)
            except Exception as e:
                logger.error(f"Error validating document: {e}")
                # Create error report
                from models.validation_schemas import ValidationStatus
                error_report = ValidationReport(
                    document_id=extracted_data.get("document_id", "unknown"),
                    validation_status=ValidationStatus.ERROR,
                    overall_score=0.0,
                    confidence_score=0.0,
                    recommendation=f"Validation error: {str(e)}",
                    requires_manual_review=True,
                    risk_level="critical"
                )
                results.append(error_report)
        
        return results
    
    def get_agent_status(self) -> Dict[str, Any]:
        """
        Get Agent 2 status information
        
        Returns:
            Agent status
        """
        return {
            "agent_name": "Agent 2 - Validation & Anomaly Detection",
            "status": "active" if self._agent else "inactive",
            "llm_enabled": self._agent.use_llm if self._agent else False,
            "model": settings.LLM_MODEL if self._agent and self._agent.use_llm else "None",
            "validation_features": [
                "Schema Validation",
                "Business Rules",
                "Arithmetic Checks",
                "Anomaly Detection (ML)",
                "Fraud Pattern Detection",
                "LLM Contextual Validation" if self._agent and self._agent.use_llm else "LLM Disabled"
            ]
        }
    
    async def get_validation_report(self, document_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve saved validation report
        
        Args:
            document_id: Document ID
            
        Returns:
            Validation report dict or None
        """
        try:
            import json
            
            report_file = os.path.join(
                settings.PROCESSED_DIR,
                f"{document_id}_validation.json"
            )
            
            if not os.path.exists(report_file):
                return None
            
            with open(report_file, 'r', encoding='utf-8') as f:
                report = json.load(f)
            
            return report
            
        except Exception as e:
            logger.error(f"Error loading validation report: {e}")
            return None
    
    def get_validation_statistics(self, document_ids: List[str]) -> Dict[str, Any]:
        """
        Get aggregate validation statistics
        
        Args:
            document_ids: List of document IDs to analyze
            
        Returns:
            Statistics dictionary
        """
        try:
            import json
            
            stats = {
                "total_documents": len(document_ids),
                "validated": 0,
                "passed": 0,
                "warnings": 0,
                "failed": 0,
                "errors": 0,
                "avg_score": 0.0,
                "requires_review": 0,
                "fraud_indicators_found": 0
            }
            
            scores = []
            
            for doc_id in document_ids:
                report_file = os.path.join(
                    settings.PROCESSED_DIR,
                    f"{doc_id}_validation.json"
                )
                
                if not os.path.exists(report_file):
                    continue
                
                with open(report_file, 'r', encoding='utf-8') as f:
                    report = json.load(f)
                
                stats["validated"] += 1
                
                status = report.get("validation_status")
                if status == "passed":
                    stats["passed"] += 1
                elif status == "warning":
                    stats["warnings"] += 1
                elif status == "failed":
                    stats["failed"] += 1
                else:
                    stats["errors"] += 1
                
                if report.get("requires_manual_review"):
                    stats["requires_review"] += 1
                
                if report.get("fraud_indicators"):
                    stats["fraud_indicators_found"] += len(report["fraud_indicators"])
                
                scores.append(report.get("overall_score", 0))
            
            if scores:
                stats["avg_score"] = sum(scores) / len(scores)
            
            return stats
            
        except Exception as e:
            logger.error(f"Error calculating validation statistics: {e}")
            return {}


# Global service instance
agent2_service = Agent2Service()