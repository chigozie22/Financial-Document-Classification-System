"""
Service layer for Agent 3 operations
"""
import os
import sys
import logging
from typing import Dict, Any, Optional
import json

# Add paths for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))

from agents.agent_3_report_generator.agent import Agent3ReportGenerator
from agents.agent_3_report_generator.tools.pdf_generator import PDFGenerator
from agents.agent_3_report_generator.tools.word_generator import WordGenerator
from agents.agent_3_report_generator.tools.chart_generator import ChartGenerator
from backend.app.utils.gemini_client import GeminiClient
from backend.app.core.config import settings

logger = logging.getLogger(__name__)


class Agent3Service:
    """Service for managing Agent 3 report generation operations"""
    
    _instance = None
    _agent = None
    
    def __new__(cls):
        """Singleton pattern"""
        if cls._instance is None:
            cls._instance = super(Agent3Service, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize service with Agent 3"""
        if self._agent is None:
            self._initialize_agent()
    
    def _initialize_agent(self):
        """Initialize Agent 3 with all required tools"""
        try:
            logger.info("Initializing Agent 3 Service...")
            
            # Initialize PDF Generator
            pdf_generator = PDFGenerator(
                output_dir="data/reports"
            )
            
            # Initialize Word Generator
            word_generator = WordGenerator(
                output_dir="data/reports"
            )
            
            # Initialize Chart Generator
            chart_generator = ChartGenerator(
                output_dir="data/reports/charts"
            )
            
            # Initialize Gemini Client (optional for summaries)
            gemini_client = None
            use_llm = False
            
            api_key = settings.GEMINI_API_KEY
            if api_key:
                try:
                    gemini_client = GeminiClient(
                        api_key=api_key,
                        model_name=settings.LLM_MODEL,
                        temperature=settings.LLM_TEMPERATURE,
                        max_tokens=settings.LLM_MAX_TOKENS
                    )
                    use_llm = True
                    logger.info("Gemini client initialized for report summaries")
                except Exception as e:
                    logger.warning(f"Failed to initialize Gemini client: {e}")
                    logger.info("Agent 3 will use template-based summaries")
            else:
                logger.info("No Gemini API key found. Agent 3 will use template-based summaries")
            
            # Initialize Agent 3
            self._agent = Agent3ReportGenerator(
                pdf_generator=pdf_generator,
                word_generator=word_generator,
                chart_generator=chart_generator,
                gemini_client=gemini_client,
                use_llm=use_llm
            )
            
            logger.info("Agent 3 service initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize Agent 3 service: {e}")
            raise
    
    async def generate_report(self,
                             extracted_data: Dict[str, Any],
                             validation_report: Dict[str, Any],
                             format: str = "both") -> Dict[str, Any]:
        """
        Generate audit report
        
        Args:
            extracted_data: Output from Agent 1
            validation_report: Output from Agent 2
            format: "pdf", "word", or "both"
            
        Returns:
            Dict with report paths and status
        """
        try:
            document_id = extracted_data.get("document_id", "unknown")
            logger.info(f"Starting report generation for document: {document_id}")
            
            # Run report generation (synchronous, wrapped in async)
            report_paths = self._agent.generate_audit_report(
                extracted_data=extracted_data,
                validation_report=validation_report,
                format=format
            )
            
            return {
                "status": "success",
                "document_id": document_id,
                **report_paths
            }
            
        except Exception as e:
            logger.error(f"Error in generate_report: {e}", exc_info=True)
            return {
                "status": "failed",
                "error_message": str(e)
            }
    
    async def generate_from_files(self, document_id: str, 
                                 format: str = "both") -> Optional[Dict[str, Any]]:
        """
        Load data from files and generate report
        
        Args:
            document_id: Document ID
            format: Report format
            
        Returns:
            Report generation result or None
        """
        try:
            # Load extracted data
            extracted_file = os.path.join(
                settings.PROCESSED_DIR,
                f"{document_id}_extracted.json"
            )
            
            if not os.path.exists(extracted_file):
                logger.error(f"Extracted data file not found: {extracted_file}")
                return {
                    "status": "failed",
                    "error_message": f"Extracted data not found for {document_id}"
                }
            
            with open(extracted_file, 'r', encoding='utf-8') as f:
                extracted_data = json.load(f)
            
            # Load validation report
            validation_file = os.path.join(
                settings.PROCESSED_DIR,
                f"{document_id}_validation.json"
            )
            
            if not os.path.exists(validation_file):
                logger.error(f"Validation report not found: {validation_file}")
                return {
                    "status": "failed",
                    "error_message": f"Validation report not found for {document_id}"
                }
            
            with open(validation_file, 'r', encoding='utf-8') as f:
                validation_report = json.load(f)
            
            # Generate report
            result = await self.generate_report(
                extracted_data=extracted_data,
                validation_report=validation_report,
                format=format
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Error in generate_from_files: {e}")
            return {
                "status": "failed",
                "error_message": str(e)
            }
    
    async def regenerate_report(self, document_id: str, 
                               format: str = "both") -> Optional[Dict[str, Any]]:
        """
        Regenerate report for an existing document
        
        Args:
            document_id: Document ID
            format: Report format
            
        Returns:
            Report generation result
        """
        logger.info(f"Regenerating report for document: {document_id}")
        return await self.generate_from_files(document_id, format)
    
    def get_agent_status(self) -> Dict[str, Any]:
        """
        Get Agent 3 status information
        
        Returns:
            Agent status
        """
        return {
            "agent_name": "Agent 3 - Report Generator",
            "status": "active" if self._agent else "inactive",
            "llm_enabled": self._agent.use_llm if self._agent else False,
            "model": settings.LLM_MODEL if self._agent and self._agent.use_llm else "None",
            "supported_formats": ["pdf", "word", "both"],
            "features": [
                "PDF Report Generation",
                "Word Document Generation",
                "Chart Visualization (Matplotlib)",
                "Executive Summary (LLM)" if self._agent and self._agent.use_llm else "Executive Summary (Template)",
                "Recommendations (LLM)" if self._agent and self._agent.use_llm else "Recommendations (Template)"
            ]
        }
    
    def get_report_status(self, document_id: str) -> Optional[Dict[str, Any]]:
        """
        Check if reports exist for a document
        
        Args:
            document_id: Document ID
            
        Returns:
            Report status dict or None
        """
        try:
            if not self._agent:
                return None
            
            return self._agent.get_report_status(document_id)
            
        except Exception as e:
            logger.error(f"Error getting report status: {e}")
            return None
    
    def list_reports(self) -> Dict[str, Any]:
        """
        List all generated reports
        
        Returns:
            Dict with report lists
        """
        try:
            reports_dir = "data/reports"
            
            if not os.path.exists(reports_dir):
                return {
                    "total_reports": 0,
                    "pdf_reports": [],
                    "word_reports": []
                }
            
            pdf_reports = [
                f for f in os.listdir(reports_dir) 
                if f.endswith('_audit_report.pdf')
            ]
            
            word_reports = [
                f for f in os.listdir(reports_dir) 
                if f.endswith('_audit_report.docx')
            ]
            
            return {
                "total_reports": len(set([
                    f.replace('_audit_report.pdf', '').replace('_audit_report.docx', '')
                    for f in pdf_reports + word_reports
                ])),
                "pdf_reports": sorted(pdf_reports),
                "word_reports": sorted(word_reports),
                "reports_directory": os.path.abspath(reports_dir)
            }
            
        except Exception as e:
            logger.error(f"Error listing reports: {e}")
            return {
                "total_reports": 0,
                "error": str(e)
            }
    
    def delete_report(self, document_id: str) -> Dict[str, Any]:
        """
        Delete reports for a document
        
        Args:
            document_id: Document ID
            
        Returns:
            Deletion result
        """
        try:
            deleted_files = []
            
            # Delete PDF
            pdf_path = os.path.join("data/reports", f"{document_id}_audit_report.pdf")
            if os.path.exists(pdf_path):
                os.remove(pdf_path)
                deleted_files.append(pdf_path)
            
            # Delete Word
            word_path = os.path.join("data/reports", f"{document_id}_audit_report.docx")
            if os.path.exists(word_path):
                os.remove(word_path)
                deleted_files.append(word_path)
            
            # Delete charts
            charts_dir = "data/reports/charts"
            if os.path.exists(charts_dir):
                chart_files = [
                    f for f in os.listdir(charts_dir) 
                    if f.startswith(document_id)
                ]
                for chart_file in chart_files:
                    chart_path = os.path.join(charts_dir, chart_file)
                    os.remove(chart_path)
                    deleted_files.append(chart_path)
            
            if not deleted_files:
                return {
                    "status": "not_found",
                    "message": f"No reports found for document {document_id}"
                }
            
            return {
                "status": "success",
                "document_id": document_id,
                "deleted_files": len(deleted_files),
                "files": deleted_files
            }
            
        except Exception as e:
            logger.error(f"Error deleting report: {e}")
            return {
                "status": "failed",
                "error_message": str(e)
            }


# Global service instance
agent3_service = Agent3Service()