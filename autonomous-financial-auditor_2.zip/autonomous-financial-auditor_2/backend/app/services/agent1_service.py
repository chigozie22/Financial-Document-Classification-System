"""
Service layer for Agent 1 operations
"""
import os
import sys
import logging
from typing import Dict, Any, List

# Add paths for imports 
sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))

from agents.agent_1_ocr_extractor.agents import Agent1OCRExtractor
from agents.agent_1_ocr_extractor.processing_tools.ocr_tool import OCRTool
from agents.agent_1_ocr_extractor.processing_tools.ner_tool import NERTool
from backend.app.utils.gemini_client import GeminiClient
from backend.app.core.config import settings

logger = logging.getLogger(__name__)

class Agent1Service:
    """Service for managing Agent 1 extraction operations"""

    _instance = None
    _agent = None

    def __new__(cls):
        """Singleton pattern"""
        if cls._instance is None:
            cls._instance = super(Agent1Service, cls).__new__(cls)

        return cls._instance
    
    def __init__(self):
        """Initialize Service with Agent 1"""
        if self._agent is None:
            self._initialize_agent()
    
    def _initialize_agent(self):
        """Initialize Agent 1 with all required tools"""
        try: 
            logger.info("Initializing Agent 1 Service...")

            # initialize OCR TOOL 
            ocr_tool = OCRTool(
                tesseract_cmd=settings.TESSERACT_CMD,
                lang = settings.OCR_LANG,
                config=settings.OCR_CONFIG

            )

            # Initialize NER tool

            ner_tool = NERTool(model_name=settings.SPACY_MODEL)

            api_key = settings.GEMINI_API_KEY  # Use the property
            if not api_key:
                raise ValueError("GOOGLE_GEMINI_API_KEY not found in environment variables")

            gemini_client = GeminiClient(
                api_key=api_key,
                model_name=settings.LLM_MODEL,
                temperature=settings.LLM_TEMPERATURE,
                max_tokens=settings.LLM_MAX_TOKENS
            )

            # Initialize agent 1
            self._agent = Agent1OCRExtractor(
                ocr_tool=ocr_tool,
                ner_tool=ner_tool,
                gemini_client= gemini_client,
                confidence_threshold=settings.EXTRACTION_CONFIDENCE_THRESHOLD
            )

            logger.info("Agent 1 service initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize Agent 1 service: {e}")
            raise

    async def extract_from_file(self, file_path: str, document_id: str = None) -> Dict[str, Any]:
        """
        Extract structured data from a single document
        
        Args:
            file_path: Path to document file
            document_id: Optional document ID
            
        Returns:
            Extraction result
        """
        try: 
            if not os.path.exists(file_path):
                return {
                    "status": "failed",
                    "error_message": f"File not found: {file_path}"
                }
            
            # Run extraction {synchronous, but wrapped in async for consistence}

            result = self._agent.extract_from_document(file_path, document_id)


            return result 
        
        except Exception as e:
            logger.error(f"Error in extract_from_file: {e}")

            return {
                "status": "failed",
                "error_message": str(e)
            }
        
    async def extract_batch(self, file_paths: List[str]) -> List[Dict[str, Any]]:
        """
        Extract from multiple documents
        
        Args:
            file_paths: List of file paths
            
        Returns:
            List of extraction results
        """

        results = []

        for file_path in file_paths:
            result = await self.extract_from_file(file_path)
            results.append(result)


        return results
    
    def get_agent_status(self) -> Dict[str, Any]:
        """
        Get Agent 1 status information
        
        Returns:
            Agent status
        """

        return {
            "agent_name": "Agent 1 - OCR & Extraction",
            "status": "active" if self._agent else "inactive",
            "model": settings.LLM_MODEL,
            "confidence_threshold": settings.EXTRACTION_CONFIDENCE_THRESHOLD
        }
    


# Global service instance
agent1_service = Agent1Service()