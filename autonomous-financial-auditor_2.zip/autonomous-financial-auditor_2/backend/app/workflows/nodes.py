"""
LangGraph Workflow Nodes - Each agent as a node
"""
import logging
from datetime import datetime
from backend.app.workflows.state import AuditState
from backend.app.services.agent1_service import agent1_service
from backend.app.services.agent2_service import agent2_service
from backend.app.services.agent3_service import agent3_service

logger = logging.getLogger(__name__)


async def agent1_extraction_node(state: AuditState) -> AuditState:
    """
    Agent 1 Node: Extract data from document
    
    Args:
        state: Current workflow state
        
    Returns:
        Updated state with extraction results
    """
    logger.info(f"[Agent 1 Node] Starting extraction for: {state['document_id']}")
    
    start_time = datetime.now()
    
    try:
        # Call Agent 1 service
        result = await agent1_service.extract_from_file(
            file_path=state["document_path"],
            document_id=state["document_id"]
        )
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        # Check result
        if result.get("status") == "success":
            logger.info(f"[Agent 1 Node] Extraction successful")
            
            return {
                "extracted_data": result.get("extracted_data"),
                "extraction_status": "success",
                "extraction_error": None,
                "extraction_time": processing_time,
                "current_step": "validate",
                "errors": state.get("errors", [])
            }
        else:
            error_msg = result.get("error_message", "Unknown extraction error")
            logger.error(f"[Agent 1 Node] Extraction failed: {error_msg}")
            
            return {
                "extracted_data": None,
                "extraction_status": "failed",
                "extraction_error": error_msg,
                "extraction_time": processing_time,
                "current_step": "complete",
                "final_status": "failed",
                "errors": state.get("errors", []) + [f"Agent 1: {error_msg}"]
            }
            
    except Exception as e:
        processing_time = (datetime.now() - start_time).total_seconds()
        error_msg = str(e)
        logger.error(f"[Agent 1 Node] Exception: {error_msg}", exc_info=True)
        
        return {
            "extracted_data": None,
            "extraction_status": "failed",
            "extraction_error": error_msg,
            "extraction_time": processing_time,
            "current_step": "complete",
            "final_status": "failed",
            "errors": state.get("errors", []) + [f"Agent 1 Exception: {error_msg}"]
        }


async def agent2_validation_node(state: AuditState) -> AuditState:
    """
    Agent 2 Node: Validate extracted data
    
    Args:
        state: Current workflow state
        
    Returns:
        Updated state with validation results
    """
    logger.info(f"[Agent 2 Node] Starting validation for: {state['document_id']}")
    
    start_time = datetime.now()
    
    try:
        # Call Agent 2 service
        validation_report = await agent2_service.validate_document(
            extracted_data=state["extracted_data"]
        )
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        # Validation always succeeds (even if document fails validation)
        # The report contains the validation status
        logger.info(f"[Agent 2 Node] Validation completed")
        
        return {
            "validation_report": validation_report.model_dump() if hasattr(validation_report, 'model_dump') else validation_report,
            "validation_status": "success",
            "validation_error": None,
            "validation_time": processing_time,
            "current_step": "report",
            "errors": state.get("errors", [])
        }
        
    except Exception as e:
        processing_time = (datetime.now() - start_time).total_seconds()
        error_msg = str(e)
        logger.error(f"[Agent 2 Node] Exception: {error_msg}", exc_info=True)
        
        # Even if validation fails, try to generate report
        return {
            "validation_report": None,
            "validation_status": "failed",
            "validation_error": error_msg,
            "validation_time": processing_time,
            "current_step": "report",  # Still try to generate report
            "errors": state.get("errors", []) + [f"Agent 2 Exception: {error_msg}"]
        }


async def agent3_report_node(state: AuditState) -> AuditState:
    """
    Agent 3 Node: Generate audit report
    
    Args:
        state: Current workflow state
        
    Returns:
        Updated state with report paths
    """
    logger.info(f"[Agent 3 Node] Starting report generation for: {state['document_id']}")
    
    start_time = datetime.now()
    
    try:
        # Check if we have required data
        if not state.get("extracted_data"):
            logger.warning("[Agent 3 Node] No extracted data available")
            return {
                "pdf_path": None,
                "word_path": None,
                "report_status": "failed",
                "report_error": "No extracted data available",
                "report_time": 0,
                "current_step": "complete",
                "final_status": "failed",
                "errors": state.get("errors", []) + ["Agent 3: No extracted data"]
            }
        
        # Use empty validation report if validation failed
        validation_report = state.get("validation_report")
        if not validation_report:
            logger.warning("[Agent 3 Node] No validation report, using minimal report")
            validation_report = {
                "document_id": state["document_id"],
                "validation_status": "error",
                "overall_score": 0.0,
                "issues": [],
                "anomalies": [],
                "recommendation": "Validation failed - manual review required"
            }
        
        # Call Agent 3 service
        result = await agent3_service.generate_report(
            extracted_data=state["extracted_data"],
            validation_report=validation_report,
            format=state.get("report_format", "both")
        )
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        if result.get("status") == "success":
            logger.info(f"[Agent 3 Node] Report generation successful")
            
            return {
                "pdf_path": result.get("pdf"),
                "word_path": result.get("word"),
                "report_status": "success",
                "report_error": None,
                "report_time": processing_time,
                "current_step": "complete",
                "final_status": "completed",
                "errors": state.get("errors", [])
            }
        else:
            error_msg = result.get("error_message", "Unknown report generation error")
            logger.error(f"[Agent 3 Node] Report generation failed: {error_msg}")
            
            return {
                "pdf_path": None,
                "word_path": None,
                "report_status": "failed",
                "report_error": error_msg,
                "report_time": processing_time,
                "current_step": "complete",
                "final_status": "failed",
                "errors": state.get("errors", []) + [f"Agent 3: {error_msg}"]
            }
            
    except Exception as e:
        processing_time = (datetime.now() - start_time).total_seconds()
        error_msg = str(e)
        logger.error(f"[Agent 3 Node] Exception: {error_msg}", exc_info=True)
        
        return {
            "pdf_path": None,
            "word_path": None,
            "report_status": "failed",
            "report_error": error_msg,
            "report_time": processing_time,
            "current_step": "complete",
            "final_status": "failed",
            "errors": state.get("errors", []) + [f"Agent 3 Exception: {error_msg}"]
        }


def should_continue_to_validation(state: AuditState) -> str:
    """
    Conditional edge: Decide if we should continue to validation
    
    Args:
        state: Current state
        
    Returns:
        Next node name
    """
    if state.get("extraction_status") == "success":
        logger.info("[Router] Extraction successful → Proceeding to validation")
        return "validate"
    else:
        logger.info("[Router] Extraction failed → Ending workflow")
        return "end"


def should_continue_to_report(state: AuditState) -> str:
    """
    Conditional edge: Decide if we should continue to report generation
    
    Args:
        state: Current state
        
    Returns:
        Next node name
    """
    # Always try to generate report, even if validation had issues
    # The report will show the validation failures
    logger.info("[Router] Proceeding to report generation")
    return "report"