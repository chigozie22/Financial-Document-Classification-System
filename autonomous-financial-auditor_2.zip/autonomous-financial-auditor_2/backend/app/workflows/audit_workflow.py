"""
Langraph Audit workflow
Orchestrates Agent 1 -> Agent 2 -> Agent 3
"""
from langgraph.graph import StateGraph, END
from backend.app.workflows.state import AuditState
from backend.app.workflows.nodes import (
    agent1_extraction_node,
    agent2_validation_node,
    agent3_report_node,
    should_continue_to_validation,
    should_continue_to_report
)

import logging 

logger = logging.getLogger(__name__)


def create_audit_workflow():
    """
    Create the complete auditq workflow graph

    Workflow:
    START -> Agent 1 Extraction Node -> Agent 2 Validation Node -> Agent 3 Report Node -> END
    
    Returns:
        Compiled workflow
    """

    logger.info("Creating audit workflow graph...")

    # Initialize graph with state
    workflow = StateGraph(AuditState)

    # Add nodes (Agents)

    workflow.add_node("extract", agent1_extraction_node)
    workflow.add_node("validate", agent2_validation_node)
    workflow.add_node("report", agent3_report_node)

    #set entry point 
    workflow.set_entry_point("extract")

    # define edges (Flow)
    workflow.add_conditional_edges(
        "extract",
        should_continue_to_validation,
        {
            "validate": "validate",
            "end": END}
    )

    # after validation try to generate report
    workflow.add_conditional_edges(
        "validate",
        should_continue_to_report,
        {
            "report": "report",
        }
    )

    # after report end workflow 
    workflow.add_edge("report", END)

    #compile the workflow
    compiled_workflow = workflow.compile()

    logger.info("Audit workflow graph created successfully")

    return compiled_workflow

# Create global workflow instance
audit_workflow = create_audit_workflow()