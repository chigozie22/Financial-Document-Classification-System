"""
LangGraph State Definition for Audit Workflow
"""
from typing import TypedDict, Optional, List, Dict, Any
from typing_extensions import Annotated


class AuditState(TypedDict):
    """
    State passed between all agents in the audit workflow
    
    This state is passed from Agent 1 → Agent 2 → Agent 3
    """
    
    # Input
    document_id: str
    document_path: str
    report_format: str  # "pdf", "word", or "both"
    
    # Agent 1: OCR & Extraction
    extracted_data: Optional[Dict[str, Any]]
    extraction_status: str  # "pending", "success", "failed"
    extraction_error: Optional[str]
    extraction_time: Optional[float]
    
    # Agent 2: Validation
    validation_report: Optional[Dict[str, Any]]
    validation_status: str  # "pending", "success", "failed"
    validation_error: Optional[str]
    validation_time: Optional[float]
    
    # Agent 3: Report Generation
    pdf_path: Optional[str]
    word_path: Optional[str]
    report_status: str  # "pending", "success", "failed"
    report_error: Optional[str]
    report_time: Optional[float]
    
    # Overall workflow
    current_step: str  # "extract", "validate", "report", "complete"
    errors: List[str]
    final_status: str  # "pending", "completed", "failed"
    total_processing_time: Optional[float]
    
    # Metadata
    started_at: Optional[str]
    completed_at: Optional[str]